package com.ucprovpn.core.vpn

import android.app.Notification
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats as AndroidTrafficStats
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.os.Process
import android.os.SystemClock
import android.util.Log
import androidx.core.app.ServiceCompat
import com.ucprovpn.core.engine.EngineManager
import com.ucprovpn.core.engine.EngineState
import com.ucprovpn.core.engine.EngineType
import com.ucprovpn.core.engine.ProcessEngine
import com.ucprovpn.core.engine.TrafficStats
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.amnezia.awg.hevtunnel.TProxyService
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicBoolean
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory
import kotlin.concurrent.thread

class LumenVpnService : VpnService() {
    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    @Volatile private var vpnInterface: ParcelFileDescriptor? = null
    private val tunnelStarted = AtomicBoolean(false)
    // bringUpRuntime/stopRuntime are reachable from five independent coroutines;
    // without this they race on tunnelStarted and on vpnInterface.
    private val runtimeMutex = Mutex()
    // Async teardown must not cancel a start that arrived in the meantime.
    @Volatile private var lastStartId = 0
    private var stateJob: Job? = null
    private var trafficStatsJob: Job? = null
    private var startJob: Job? = null
    private var sessionUploaded = 0L
    private var sessionDownloaded = 0L

    private data class StartParams(
        val engineType: EngineType,
        val configJson: String,
        val configPath: String,
        val mtu: Int,
        val localSocksPort: Int,
        val proxyOnly: Boolean,
        val dnsMode: String,
        val splitConfig: SplitTunnelingConfig,
        val reconnectOnNetworkChange: Boolean,
        val obfsType: String = "",
        val obfsHost: String = "",
        val obfsPort: Int = 0
    )

    @Volatile private var activeParams: StartParams? = null
    @Volatile private var obfsRelay: ObfsRelay? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null
    private var restartJob: Job? = null
    @Volatile private var lastUnderlyingNetwork: Network? = null
    @Volatile private var pendingUnderlyingNetwork: Network? = null
    @Volatile private var networkRestartPending = false
    // Set while the runtime is deliberately torn down for a reconnect, so the engine exit
    // callback does not treat the planned shutdown as a crash and kill the service.
    @Volatile private var restartingForNetwork = false
    // Credentials of the running core's socks inbound, so the data-path probe can
    // authenticate exactly like the tunnel does.
    @Volatile private var activeSocksCredentials: Pair<String, String>? = null

    val engineManager: EngineManager by lazy {
        val nativeDir = File(applicationInfo.nativeLibraryDir)
        EngineManager(
            singboxEngine = ProcessEngine(
                EngineType.SINGBOX,
                File(nativeDir, "libsingbox.so"),
                File(cacheDir, "singbox-extended"),
                ::logEngine,
                { code -> onCoreExit("sing-box extended", code) }
            )
        )
    }

    /**
     * A tile or widget start brings this service up without the app ever being
     * created, so the persistent log has to be attached from here as well.
     */
    override fun onCreate() {
        super.onCreate()
        VpnLogBus.init(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lastStartId = startId
        if (intent == null) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        when (intent.action) {
            ACTION_START_VPN -> {
                val engineType = runCatching {
                    EngineType.valueOf(intent.getStringExtra(EXTRA_ENGINE_TYPE) ?: EngineType.SINGBOX.name)
                }.getOrDefault(EngineType.SINGBOX)
                val splitMode = runCatching {
                    SplitTunnelingMode.valueOf(
                        intent.getStringExtra(EXTRA_SPLIT_MODE) ?: SplitTunnelingMode.DISABLED.name
                    )
                }.getOrDefault(SplitTunnelingMode.DISABLED)
                startVpn(
                    StartParams(
                        engineType = engineType,
                        // Kept only for a PendingIntent built by an older install:
                        // the config travels as a path now, never as an extra.
                        configJson = intent.getStringExtra(EXTRA_CONFIG_JSON).orEmpty(),
                        configPath = intent.getStringExtra(EXTRA_CONFIG_PATH).orEmpty(),
                        mtu = intent.getIntExtra(EXTRA_MTU, DEFAULT_MTU).coerceIn(1280, 9000),
                        localSocksPort = intent.getIntExtra(EXTRA_LOCAL_SOCKS_PORT, LOCAL_SOCKS_PORT).coerceIn(1024, 65535),
                        proxyOnly = intent.getBooleanExtra(EXTRA_PROXY_ONLY, false),
                        dnsMode = intent.getStringExtra(EXTRA_DNS_MODE) ?: "automatic",
                        splitConfig = SplitTunnelingConfig(
                            splitMode,
                            (intent.getStringArrayListExtra(EXTRA_SPLIT_PACKAGES) ?: arrayListOf()).toSet()
                        ),
                        reconnectOnNetworkChange = intent.getBooleanExtra(
                            EXTRA_RECONNECT_ON_NETWORK_CHANGE,
                            true
                        ),
                        obfsType = intent.getStringExtra(EXTRA_OBFS_TYPE).orEmpty(),
                        obfsHost = intent.getStringExtra(EXTRA_OBFS_HOST).orEmpty(),
                        obfsPort = intent.getIntExtra(EXTRA_OBFS_PORT, 0)
                    )
                )
            }
            ACTION_STOP_VPN -> stopVpn()
            ACTION_PAUSE_VPN -> pauseVpn()
        }
        // Every start is explicit and carries the complete generated config.
        // Recreating this service without that intent can only create a stop/start loop.
        return START_NOT_STICKY
    }

    private fun startVpn(params: StartParams) {
        // Every caller uses startForegroundService(), which arms a watchdog that
        // kills the process unless startForeground() runs before anything tears the
        // service down. Claim the slot before any branch that can return.
        NotificationHelper.invalidate()
        startForegroundCompat(
            if (_isRunning.value) {
                NotificationHelper.buildNotification(this, isConnected = true)
            } else {
                NotificationHelper.buildConnectingNotification(this)
            }
        )
        reportNotificationVisibility()
        if (_isStarting.value) {
            VpnLogBus.warning("VPN", "Ignoring a duplicate start while a connection is already being established")
            return
        }
        if (_isRunning.value) {
            VpnLogBus.warning("VPN", "Ignoring a duplicate start while VPN is already connected")
            return
        }
        VpnLogBus.clearLastError()
        restartJob?.cancel()
        restartJob = null
        _isStarting.value = true
        startJob = serviceScope.launch {
            try {
                // An imported AUTO pool is hundreds of kilobytes, so the config is
                // never carried by the intent; reading it back is IO and belongs here.
                val resolved = if (params.configJson.isNotBlank()) {
                    params
                } else {
                    params.copy(
                        configJson = VpnConfigStore.read(this@LumenVpnService, params.configPath)
                    )
                }
                if (!VpnStartIntentFactory.isUsableConfig(resolved.configJson)) {
                    VpnLogBus.error("VPN", "Cannot start VPN: invalid or empty server configuration")
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    // Duplicate starts are deliberately ignored while this coroutine
                    // owns the startup. Stop their newer service ids too on failure,
                    // otherwise Android keeps a dead foreground-service instance alive.
                    stopSelf(lastStartId)
                    return@launch
                }
                VpnLogBus.beginSession("sing-box extended")
                VpnLogBus.info(
                    "VPN",
                    "Start requested; MTU=${resolved.mtu}, split mode=${resolved.splitConfig.mode}"
                )
                activeParams = resolved
                bringUpRuntime(resolved)
                // Watch the default network only once the tunnel is actually up.
                if (resolved.reconnectOnNetworkChange) {
                    registerNetworkMonitor()
                } else {
                    VpnLogBus.info("VPN", "Reconnect on network change is disabled in settings")
                }
            } catch (cancelled: CancellationException) {
                VpnLogBus.info("VPN", "Connection attempt cancelled")
                throw cancelled
            } catch (t: Throwable) {
                Log.e(TAG, "Error starting VPN", t)
                VpnLogBus.error("VPN", "Connection failed", t)
                clearSessionState()
                stopRuntime(closeInterface = true)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(lastStartId)
            } finally {
                _isStarting.value = false
                startJob = null
            }
        }
    }

    /**
     * Android 14 rejects a startForeground() whose type is not one the manifest
     * declares, and kills the process for it. There is no VPN foreground service
     * type, so :core:vpn declares specialUse and that is what has to be passed.
     */
    private fun startForegroundCompat(notification: Notification) {
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                ServiceCompat.startForeground(
                    this,
                    NotificationHelper.NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                )
            } else {
                startForeground(NotificationHelper.NOTIFICATION_ID, notification)
            }
        }.onFailure {
            VpnLogBus.error("VPN", "Could not enter the foreground: ${it.message}", it)
        }
    }

    /**
     * With POST_NOTIFICATIONS denied on Android 13+ the tunnel comes up but its
     * notification never appears, which looks exactly like a broken connection.
     * Publish that instead of leaving it silent.
     */
    private fun reportNotificationVisibility() {
        val blocked = !NotificationHelper.notificationsEnabled(this)
        if (blocked && !_notificationsBlocked.value) {
            VpnLogBus.warning(
                "VPN",
                "Notifications are turned off for UC ProVpn: the tunnel runs but its status " +
                    "notification stays hidden. Allow notifications in Android settings."
            )
        }
        _notificationsBlocked.value = blocked
    }

    /**
     * Starts the proxy core and, unless proxy-only mode is selected, the TUN/tun2socks bridge.
     * Used both for the initial connection and for re-establishing the runtime on a different
     * network.
     */
    private suspend fun bringUpRuntime(params: StartParams) = runtimeMutex.withLock {
        bringUpRuntimeLocked(params)
    }

    private suspend fun bringUpRuntimeLocked(params: StartParams) {
        val engineType = params.engineType
        val mtu = params.mtu
        val dnsMode = params.dnsMode
        val splitConfig = params.splitConfig
        // During an automatic underlay reconnect keep the old blocking TUN open
        // while core/hev are rebuilt. With no reader it drops traffic instead of
        // briefly leaking it outside the VPN.
        val blockingInterface = vpnInterface.takeIf { restartingForNetwork }
        stopRuntimeLocked(closeInterface = blockingInterface == null)
        // Capture the real path before Android publishes the replacement VPN.
        val connectivityManager = getSystemService(ConnectivityManager::class.java)
        val underlay = connectivityManager?.let(::currentUnderlyingNetwork)
        val physicalDnsServers = currentNetworkDnsServers(underlay)
        val dnsPatch = ManagedDnsConfigPatcher.refreshSystemDns(
            params.configJson,
            physicalDnsServers
        )
        if (dnsPatch.changed) {
            VpnLogBus.info(
                "DNS",
                "Physical resolver refreshed for the current underlying network"
            )
        }
        val runtimeParams = params.copy(configJson = dnsPatch.json)
        startForegroundCompat(NotificationHelper.buildConnectingNotification(this))
        // obfs2/obfs3 "Use proxy": the local transport must listen before the core
        // dials its loopback detour.
        startObfsRelay(runtimeParams)
        if (!params.proxyOnly) {
            enforcePrivateDnsPolicy(dnsMode)
        }

        VpnLogBus.info("CORE", "Starting proxy core")
        val localSocksPort = startCoreOnFreeLocalPort(runtimeParams)

        val socksCredentials = socksCredentialsOf(runtimeParams.configJson)
        activeSocksCredentials = socksCredentials
        if (!params.proxyOnly) {
            val builder = Builder()
                .setMtu(mtu)
                .addAddress(DEFAULT_IPV4_ADDRESS, DEFAULT_IPV4_PREFIX)
                .addAddress(DEFAULT_IPV6_ADDRESS, DEFAULT_IPV6_PREFIX)
                .addRoute("0.0.0.0", 0)
                .addRoute("::", 0)
                .setSession("UC ProVpn")
                .setBlocking(true)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Inherit metered/unmetered state from the real network instead of
                // making every Lumen connection metered on Android 10+.
                builder.setMetered(false)
            }
            // Do not call setUnderlyingNetworks() here. The core process is excluded from
            // the VPN and follows Android's default physical network; it does not bind its
            // sockets with Network.bindSocket(). Android specifies null (the Builder
            // default) for this case. Pinning one Network here prevents a replacement
            // Wi-Fi/mobile network from becoming the usable default until the VPN stops.
            val vpnDnsServers = if (dnsMode.lowercase() in setOf("android", "system")) {
                physicalDnsServers
            } else {
                listOf(INTERNAL_DNS_ADDRESS)
            }
            vpnDnsServers.forEach(builder::addDnsServer)
            // The core's outbound sockets must bypass this VPN to avoid a routing loop.
            // ALLOW_LIST caveats: our own package must never be allowed, and an
            // empty allow-list would make Android capture ALL apps.
            val effectiveSplit = SplitTunnelingManager.withoutOwnPackage(splitConfig, packageName)
            SplitTunnelingManager.requireSafeAllowList(effectiveSplit)
            val appliedSplit = SplitTunnelingManager.applySplitTunneling(builder, effectiveSplit)
            SplitTunnelingManager.requireSafeAllowList(effectiveSplit, appliedSplit)
            if (SplitTunnelingManager.requiresSelfDisallow(effectiveSplit.mode, appliedSplit)) {
                builder.addDisallowedApplication(packageName)
            }

            val pfd = checkNotNull(builder.establish()) { "Failed to establish VPN interface" }
            vpnInterface = pfd
            if (blockingInterface != null && blockingInterface !== pfd) {
                runCatching { blockingInterface.close() }
            }
            VpnLogBus.info("VPN", "TUN interface established; starting tun2socks")

            // The shipped libhev-socks5-tunnel only knows misc.log-level / misc.log-file:
            // a top-level `log:` section parses but is dropped, so the level never applied.
            // With Socks5 authorization on, the core rejects an anonymous client, so
            // the tunnel has to present the very credentials that are in the config.
            val hevAuthLines = socksCredentials?.let { (user, password) ->
                "  username: '$user'\n  password: '$password'\n"
            }.orEmpty()
            val hevConfig = File(cacheDir, "hev-tunnel.yaml").apply {
                writeText(
                    """tunnel:
  mtu: $mtu
socks5:
  port: $localSocksPort
  address: 127.0.0.1
  udp: 'udp'
${hevAuthLines}misc:
  log-level: info
  log-file: stderr
  task-stack-size: 20480
  connect-timeout: 5000
  read-write-timeout: 60000
"""
                )
            }
            tunnelStarted.set(false)
            VpnLogBus.info("TUN2SOCKS", "Starting hev-socks5-tunnel on fd=${pfd.fd}")
            try {
                // Current upstream JNI reports pthread creation and exposes worker
                // liveness. The old void ABI made a dead native worker look Connected.
                check(TProxyService.TProxyStartService(hevConfig.absolutePath, pfd.fd)) {
                    "hev-socks5-tunnel could not create its native worker"
                }
                tunnelStarted.set(true)
            } catch (t: Throwable) {
                tunnelStarted.set(false)
                runCatching { TProxyService.TProxyStopService() }
                throw IllegalStateException("hev-socks5-tunnel failed to start", t)
            }
            delay(TUN_STARTUP_GRACE_MS)
            check(tunnelStarted.get()) { "hev-socks5-tunnel failed to start" }
            check(TProxyService.TProxyIsRunning()) {
                "hev-socks5-tunnel native worker exited during startup"
            }
            checkNotNull(readHevTrafficCounters()) {
                "hev-socks5-tunnel did not expose a valid runtime status"
            }
        }
        check(engineManager.singboxEngine.isRunning) {
            "Proxy core stopped before the connection became ready"
        }
        val validateDataPath = getSharedPreferences(VpnStartIntentFactory.PREFS_NAME, MODE_PRIVATE)
            .getBoolean(PREF_VALIDATE_PROXY_DATA_PATH, false)
        if (validateDataPath) {
            verifyProxyDataPathWithRetries(localSocksPort)
            check(engineManager.singboxEngine.isRunning) {
                "Proxy core stopped after the connectivity check"
            }
        }
        // Commit the underlay only after the replacement runtime is actually healthy.
        // Recording it before startup made a failed attempt look complete, so later
        // callbacks for the same Wi-Fi/mobile network were ignored.
        if (underlay != null) lastUnderlyingNetwork = underlay
        _isRunning.value = true
        ensureSessionStarted()
        startTrafficStats()
        // The session start time and the connected title only exist now, so the
        // cached builder from the connecting stage has to go.
        NotificationHelper.invalidate()
        startForegroundCompat(NotificationHelper.buildNotification(this, isConnected = true))
        reportNotificationVisibility()
        notifyWidgets()
        observeEngineState()
        VpnLogBus.info(
            "VPN",
            if (params.proxyOnly) {
                "Connected (${engineType.name}) in proxy-only mode; local proxy is ready"
            } else {
                "Connected (${engineType.name}); traffic is handled by sing-box + tun2socks"
            }
        )
        Log.i(TAG, "VPN started with ${engineType.name}")
    }

    private fun currentNetworkDnsServers(preferredNetwork: Network? = null): List<String> {
        val manager = getSystemService(ConnectivityManager::class.java)
        val network = preferredNetwork
            ?: pendingUnderlyingNetwork?.takeIf { isUsableUnderlyingNetwork(manager, it) }
            ?: manager.activeNetwork?.takeIf { isUsableUnderlyingNetwork(manager, it) }
            ?: lastUnderlyingNetwork?.takeIf { isUsableUnderlyingNetwork(manager, it) }
        val addresses = network
            ?.let(manager::getLinkProperties)
            ?.dnsServers
            // Preserve `%wlan0`/`%rmnet...` on link-local IPv6 resolvers. Removing
            // the zone makes the same address unreachable on another interface.
            ?.mapNotNull { it.hostAddress }
            ?.distinct()
            .orEmpty()
        return addresses.ifEmpty { DEFAULT_DNS_SERVERS }
    }

    private fun enforcePrivateDnsPolicy(dnsMode: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P ||
            dnsMode.lowercase() !in setOf("automatic", "secure")) return
        val manager = getSystemService(ConnectivityManager::class.java)
        val strictHost = manager.activeNetwork
            ?.let(manager::getLinkProperties)
            ?.privateDnsServerName
            ?.trim()
            .orEmpty()
        check(strictHost.isEmpty()) {
            "Strict Private DNS ($strictHost) conflicts with managed VPN DNS. Select DNS Android or disable Private DNS."
        }
    }

    /**
     * Starts the core on a local SOCKS port that is genuinely free and returns it.
     *
     * The configured port stays the preferred one; it is only given up while the
     * previous session's core still holds it. Losing that race used to be fatal:
     * the core exits immediately with "bind: address already in use" and the app
     * then spent its whole readiness timeout waiting for a port nobody opened,
     * which is the slow, generic failure seen on reconnects and server switches.
     */
    private suspend fun startCoreOnFreeLocalPort(params: StartParams): Int {
        var lastError: Throwable? = null
        repeat(CORE_START_ATTEMPTS) { attempt ->
            val port = LocalSocksPort.resolve(params.localSocksPort)
            if (port != params.localSocksPort) {
                VpnLogBus.warning(
                    "CORE",
                    "Local SOCKS port ${params.localSocksPort} is taken; using $port for this session"
                )
            }
            // The optional local HTTP inbound races for its port exactly like the
            // SOCKS one, and losing it kills the core just as dead:
            // `start inbound/http[http-in]: listen tcp 127.0.0.1:10809: bind:
            // address already in use`. Its port never reaches us as a parameter,
            // so take it from the config we are about to start.
            var configJson = LocalSocksPort.applyToConfig(params.configJson, port)
            LocalSocksPort.portOf(configJson, LocalSocksPort.HTTP_INBOUND_TAG)?.let { wanted ->
                val httpPort = LocalSocksPort.resolve(wanted)
                if (httpPort != wanted) {
                    VpnLogBus.warning(
                        "CORE",
                        "Local HTTP port $wanted is taken; using $httpPort for this session"
                    )
                    configJson = LocalSocksPort.applyToConfig(
                        configJson,
                        httpPort,
                        LocalSocksPort.HTTP_INBOUND_TAG
                    )
                }
            }
            val result = runCatching {
                engineManager.startEngine(params.engineType, configJson, null)
                val state = engineManager.state.value
                check(state is EngineState.Running) {
                    (state as? EngineState.Error)?.message ?: "Engine failed to start"
                }
                waitForLocalSocks(port)
            }
            if (result.isSuccess) return port
            lastError = result.exceptionOrNull()
            if (!ProcessEngine.isAddressInUse(lastError?.message) ||
                attempt == CORE_START_ATTEMPTS - 1
            ) {
                throw lastError ?: IllegalStateException("Proxy core failed to start")
            }
            VpnLogBus.warning("CORE", "A local inbound port was still in use; retrying")
            runCatching { engineManager.stopEngine() }
            delay(CORE_START_RETRY_DELAY_MS)
        }
        throw lastError ?: IllegalStateException("Proxy core failed to start")
    }

    private suspend fun waitForLocalSocks(localSocksPort: Int) {
        repeat(SOCKS_READY_ATTEMPTS) { attempt ->
            val ready = runCatching {
                Socket().use { it.connect(InetSocketAddress("127.0.0.1", localSocksPort), 200) }
                true
            }.getOrDefault(false)
            if (ready) {
                VpnLogBus.info("CORE", "Local SOCKS5 is ready on 127.0.0.1:$localSocksPort")
                return
            }
            // A core that already died will never open the port, and burning the
            // rest of the timeout only makes the failure slower, not clearer.
            if (!engineManager.singboxEngine.isRunning) error(coreExitReason())
            if (attempt % 10 == 0) VpnLogBus.debug("CORE", "Waiting for local SOCKS5…")
            delay(100)
        }
        error("Proxy core did not open local SOCKS5 port $localSocksPort")
    }

    /**
     * The credentials the core's socks inbound expects, or null when Socks5
     * authorization is off. Reading them back from the config keeps the tunnel and
     * the probe in step with whatever the builder actually emitted.
     */
    private fun socksCredentialsOf(configJson: String): Pair<String, String>? {
        return try {
            val inbounds = org.json.JSONObject(configJson).optJSONArray("inbounds")
                ?: return null
            for (index in 0 until inbounds.length()) {
                val inbound = inbounds.optJSONObject(index) ?: continue
                if (inbound.optString("type") != "socks") continue
                val user = inbound.optJSONArray("users")?.optJSONObject(0) ?: continue
                val username = user.optString("username")
                if (username.isNotEmpty()) return username to user.optString("password")
            }
            null
        } catch (t: Throwable) {
            null
        }
    }

    /** The core's own last word; a bare exit code tells the user nothing. */
    private fun coreExitReason(): String {
        val fatal = engineManager.singboxEngine.lastFatalLine
        return if (fatal.isBlank()) {
            "core exited during startup"
        } else {
            "core exited during startup: $fatal"
        }
    }

    /**
     * A running process and an open local SOCKS port do not prove that traffic reaches the server.
     * Complete a real SOCKS5 CONNECT through the selected core before reporting Connected.
     */
    private fun verifyProxyDataPath(localSocksPort: Int, target: ProxyProbeTarget) {
        VpnLogBus.info(
            "VPN",
            "Verifying proxy data path via SOCKS5 → ${target.authority}"
        )
        Socket().use { socket ->
            socket.soTimeout = PROXY_PROBE_TIMEOUT_MS
            socket.connect(InetSocketAddress("127.0.0.1", localSocksPort), PROXY_PROBE_TIMEOUT_MS)
            val output = socket.getOutputStream()
            val input = socket.getInputStream()

            // Offer both methods: the inbound only accepts username/password once
            // Socks5 authorization is on, and only "no auth" while it is off.
            val credentials = activeSocksCredentials
            if (credentials == null) {
                output.write(byteArrayOf(0x05, 0x01, 0x00))
            } else {
                output.write(byteArrayOf(0x05, 0x02, 0x00, 0x02))
            }
            output.flush()
            val greeting = input.readExactly(2)
            check(greeting[0].toInt() == 0x05) { "SOCKS5 authentication was rejected" }
            when (greeting[1].toInt() and 0xff) {
                0x00 -> Unit
                0x02 -> {
                    val (username, password) = checkNotNull(credentials) {
                        "Local proxy asked for credentials that are not configured"
                    }
                    val userBytes = username.toByteArray(Charsets.UTF_8)
                    val passwordBytes = password.toByteArray(Charsets.UTF_8)
                    check(userBytes.size in 1..255 && passwordBytes.size in 0..255) {
                        "Socks5 credentials do not fit the SOCKS5 handshake"
                    }
                    output.write(byteArrayOf(0x01, userBytes.size.toByte()))
                    output.write(userBytes)
                    output.write(byteArrayOf(passwordBytes.size.toByte()))
                    output.write(passwordBytes)
                    output.flush()
                    val authReply = input.readExactly(2)
                    check(authReply[1].toInt() == 0x00) {
                        "Local proxy rejected the Socks5 login"
                    }
                }
                else -> error("SOCKS5 authentication was rejected")
            }

            val hostBytes = target.host.toByteArray(Charsets.US_ASCII)
            check(hostBytes.size in 1..255) { "Invalid proxy probe host" }
            output.write(byteArrayOf(0x05, 0x01, 0x00, 0x03, hostBytes.size.toByte()))
            output.write(hostBytes)
            output.write(byteArrayOf((target.port ushr 8).toByte(), target.port.toByte()))
            output.flush()
            val reply = input.readExactly(4)
            check(reply[0].toInt() == 0x05 && reply[1].toInt() == 0x00) {
                "Proxy CONNECT failed (SOCKS reply ${reply[1].toInt() and 0xff})"
            }
            val addressLength = when (reply[3].toInt() and 0xff) {
                0x01 -> 4
                0x04 -> 16
                0x03 -> input.readExactly(1)[0].toInt() and 0xff
                else -> error("Proxy returned an invalid SOCKS address type")
            }
            input.readExactly(addressLength + 2)

            // A successful SOCKS CONNECT only proves that the remote TCP socket
            // opened. Complete HTTP(S) and read a status so AUTO cannot be shown
            // as connected while its selected member drops all application data.
            if (target.tls) {
                val tls = (SSLSocketFactory.getDefault() as SSLSocketFactory)
                    .createSocket(socket, target.host, target.port, false) as SSLSocket
                tls.use { ssl ->
                    ssl.soTimeout = PROXY_PROBE_TIMEOUT_MS
                    ssl.startHandshake()
                    verifyHttpResponse(target, ssl.inputStream, ssl.outputStream)
                }
            } else {
                verifyHttpResponse(target, input, output)
            }
        }
        VpnLogBus.info("VPN", "Proxy HTTP data path verified via ${target.authority}")
    }

    private fun verifyHttpResponse(
        target: ProxyProbeTarget,
        input: InputStream,
        output: OutputStream
    ) {
        output.write(
            (
                "GET ${target.requestTarget} HTTP/1.1\r\n" +
                    "Host: ${target.authority}\r\n" +
                    "User-Agent: UcProVpn-Android\r\n" +
                    "Connection: close\r\n\r\n"
                ).toByteArray(Charsets.US_ASCII)
        )
        output.flush()
        val statusLine = input.bufferedReader(Charsets.US_ASCII).readLine().orEmpty()
        val status = statusLine.split(' ').getOrNull(1)?.toIntOrNull() ?: 0
        // Authentication/region errors still prove that bytes crossed the selected
        // proxy. Only a missing/invalid HTTP response means the path is dead.
        check(status in 200..499) {
            "Proxy HTTP probe failed (${statusLine.ifBlank { "no HTTP response" }})"
        }
    }

    private fun proxyProbeTargets(): List<ProxyProbeTarget> {
        val configured = getSharedPreferences(VpnStartIntentFactory.PREFS_NAME, MODE_PRIVATE)
            .getString(PREF_PING_URL, null)
            .orEmpty()
        return (listOf(configured) + DEFAULT_PROXY_PROBE_URLS)
            .mapNotNull(ProxyProbeTarget::parse)
            .distinct()
    }

    private fun InputStream.readExactly(count: Int): ByteArray {
        val bytes = ByteArray(count)
        var offset = 0
        while (offset < count) {
            val read = read(bytes, offset, count - offset)
            check(read >= 0) { "Unexpected end of SOCKS5 response" }
            offset += read
        }
        return bytes
    }

    /**
     * AWG/WireGuard has to complete a handshake before a single packet gets through, and a
     * freshly started core may still be resolving its endpoint. A single probe therefore
     * fails the whole connection "the first time" even though the tunnel is up a moment
     * later, which is exactly the flakiness seen on AWG servers.
     */
    private suspend fun verifyProxyDataPathWithRetries(localSocksPort: Int) {
        var lastError: Throwable? = null
        val targets = proxyProbeTargets()
        check(targets.isNotEmpty()) { "No valid HTTP proxy probe URL is configured" }
        repeat(PROXY_PROBE_ATTEMPTS) { attempt ->
            for (target in targets) {
                val result = runCatching { verifyProxyDataPath(localSocksPort, target) }
                if (result.isSuccess) return
                lastError = result.exceptionOrNull()
                VpnLogBus.warning(
                    "VPN",
                    "Proxy probe via ${target.authority} failed: ${lastError?.message}"
                )
            }
            VpnLogBus.warning(
                "VPN",
                "Proxy data-path attempt ${attempt + 1}/$PROXY_PROBE_ATTEMPTS failed"
            )
            if (attempt + 1 < PROXY_PROBE_ATTEMPTS) delay(PROXY_PROBE_RETRY_DELAY_MS)
        }
        throw lastError ?: IllegalStateException("Proxy data path could not be verified")
    }

    /**
     * The proxy core binds its outbound sockets to the network it started on. After a
     * Wi-Fi <-> mobile switch those sockets are dead and UDP based transports (AWG,
     * WireGuard) stop passing traffic without reporting any error, so the runtime is
     * rebuilt on the new network instead.
     */
    private fun registerNetworkMonitor() {
        if (networkCallback != null) return
        val manager = getSystemService(ConnectivityManager::class.java) ?: return
        lastUnderlyingNetwork = lastUnderlyingNetwork ?: manager.activeNetwork?.takeIf {
            isUsableUnderlyingNetwork(manager, it)
        }
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                onDefaultNetworkMayHaveChanged(network)
            }

            override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                if (UnderlyingNetworkPolicy.isReady(
                        hasInternet = capabilities.hasCapability(
                            NetworkCapabilities.NET_CAPABILITY_INTERNET
                        ),
                        isValidated = capabilities.hasCapability(
                            NetworkCapabilities.NET_CAPABILITY_VALIDATED
                        ),
                        isVpn = !capabilities.hasCapability(
                            NetworkCapabilities.NET_CAPABILITY_NOT_VPN
                        )
                    )
                ) {
                    onDefaultNetworkMayHaveChanged(network)
                }
            }

            override fun onLost(network: Network) {
                if (network == pendingUnderlyingNetwork) pendingUnderlyingNetwork = null
                if (network == lastUnderlyingNetwork) {
                    lastUnderlyingNetwork = null
                    VpnLogBus.info("VPN", "Default network lost; waiting for a new one")
                    onDefaultNetworkMayHaveChanged()
                }
            }
        }
        // Observe validated physical networks independently of the VPN network.
        // currentUnderlyingNetwork() still prefers Android's active default, so a
        // concurrently available cellular fallback cannot steal an active Wi-Fi path.
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()
        runCatching { manager.registerNetworkCallback(request, callback) }
            .onSuccess { networkCallback = callback }
            .onFailure { VpnLogBus.warning("VPN", "Network monitor unavailable: ${it.message}") }
    }

    private fun unregisterNetworkMonitor() {
        val manager = getSystemService(ConnectivityManager::class.java)
        networkCallback?.let { callback -> runCatching { manager?.unregisterNetworkCallback(callback) } }
        networkCallback = null
        lastUnderlyingNetwork = null
        pendingUnderlyingNetwork = null
        networkRestartPending = false
    }

    /**
     * Returns the physical network used by the app process, never the VPN network
     * created by this service.
     */
    private fun isUsableUnderlyingNetwork(
        manager: ConnectivityManager,
        network: Network
    ): Boolean {
        val capabilities = manager.getNetworkCapabilities(network) ?: return false
        return UnderlyingNetworkPolicy.isReady(
            hasInternet = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET),
            isValidated = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED),
            isVpn = !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
        )
    }

    private fun currentUnderlyingNetwork(
        manager: ConnectivityManager
    ): Network? {
        return UnderlyingNetworkPolicy.select(
            active = manager.activeNetwork,
            pending = pendingUnderlyingNetwork,
            previous = lastUnderlyingNetwork
        ) {
            isUsableUnderlyingNetwork(manager, it)
        }
    }

    private fun onDefaultNetworkMayHaveChanged(candidate: Network? = null) {
        if (activeParams == null) return
        if (candidate != null) {
            if (!restartingForNetwork && candidate == lastUnderlyingNetwork) {
                pendingUnderlyingNetwork = null
                return
            }
            pendingUnderlyingNetwork = candidate
        }
        if (restartingForNetwork) {
            networkRestartPending = true
            return
        }
        // Capabilities can change several times during one handover. Keep the first
        // settle timer and only replace its candidate; cancelling/restarting the delay
        // on every callback could postpone the reconnect indefinitely.
        if (restartJob?.isActive == true) return
        restartJob = serviceScope.launch {
            try {
                // Multiple onAvailable/onCapabilitiesChanged callbacks describe one
                // transition. Debounce them before deciding whether the route changed.
                delay(NETWORK_SETTLE_DELAY_MS)
                val manager = getSystemService(ConnectivityManager::class.java) ?: return@launch
                // Some devices publish onLost before the replacement default network is
                // queryable. Wait briefly instead of dropping the only reconnect request.
                var network: Network? = null
                for (attempt in 0 until NETWORK_RESOLVE_ATTEMPTS) {
                    network = currentUnderlyingNetwork(manager)
                    if (network != null) break
                    delay(NETWORK_RESOLVE_RETRY_DELAY_MS * (attempt + 1))
                }
                val target = network ?: run {
                    VpnLogBus.warning("VPN", "No usable underlying network after handover")
                    return@launch
                }
                if (target == lastUnderlyingNetwork) {
                    // A passive NetworkRequest also reports validated standby
                    // transports. If Android still considers the previous network
                    // active, this candidate was not a handover and must not cause a
                    // self-rescheduling reconnect loop.
                    pendingUnderlyingNetwork = null
                    return@launch
                }
                val params = activeParams ?: return@launch
                VpnLogBus.info("VPN", "Underlying network changed; re-establishing the tunnel once")
                restartingForNetwork = true
                _isStarting.value = true
                _isRunning.value = false
                notifyWidgets()
                var lastError: Throwable? = null
                repeat(NETWORK_RESTART_ATTEMPTS) { attempt ->
                    // bringUpRuntime reads this before Android publishes the new VPN.
                    pendingUnderlyingNetwork = target
                    val result = runCatching { bringUpRuntime(params) }
                    if (result.isSuccess) {
                        if (pendingUnderlyingNetwork == target) pendingUnderlyingNetwork = null
                        VpnLogBus.info("VPN", "Tunnel restored on the new network")
                        return@launch
                    }
                    lastError = result.exceptionOrNull()
                    VpnLogBus.warning(
                        "VPN",
                        "Reconnect ${attempt + 1}/$NETWORK_RESTART_ATTEMPTS failed: ${lastError?.message}"
                    )
                    delay(NETWORK_RESTART_RETRY_DELAY_MS * (attempt + 1))
                }
                VpnLogBus.error(
                    "VPN",
                    "Could not restore the tunnel after the network changed: ${lastError?.message}"
                )
                activeParams = null
                unregisterNetworkMonitor()
                clearSessionState()
                stopRuntime(closeInterface = true)
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf(lastStartId)
            } finally {
                restartingForNetwork = false
                _isStarting.value = false
                val shouldRecheck = networkRestartPending ||
                    (pendingUnderlyingNetwork != null &&
                        pendingUnderlyingNetwork != lastUnderlyingNetwork)
                networkRestartPending = false
                restartJob = null
                // A newer candidate may arrive while the settle job is active but before
                // runtime teardown begins. It updates pendingUnderlyingNetwork without
                // setting networkRestartPending, so compare both pieces of state.
                if (shouldRecheck && activeParams != null) {
                    onDefaultNetworkMayHaveChanged(pendingUnderlyingNetwork)
                }
            }
        }
    }

    private fun onCoreExit(name: String, code: Int) {
        // ProcessEngine clears its active process before every planned stop, so
        // this callback is unexpected even during a reconnect. While setup is
        // still synchronous, let bringUpRuntime surface/ retry the same failure.
        if (_isStarting.value && !_isRunning.value) {
            VpnLogBus.error("CORE", "$name stopped during connection setup (exit code $code)")
            return
        }
        if (!_isRunning.value && vpnInterface == null) {
            return
        }
        VpnLogBus.error("CORE", "$name stopped unexpectedly (exit code $code)")
        _isRunning.value = false
        activeParams = null
        unregisterNetworkMonitor()
        clearSessionState()
        serviceScope.launch {
            stopRuntime(closeInterface = true)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(lastStartId)
        }
    }

    private fun onTunnelFailure(message: String) {
        if (!_isRunning.value && vpnInterface == null) return
        VpnLogBus.error("TUN2SOCKS", message)
        _isRunning.value = false
        activeParams = null
        unregisterNetworkMonitor()
        clearSessionState()
        serviceScope.launch {
            stopRuntime(closeInterface = true)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf(lastStartId)
        }
    }

    private fun observeEngineState() {
        stateJob?.cancel()
        stateJob = serviceScope.launch {
            engineManager.state.collect { state ->
                when (state) {
                    // The notification is driven by the traffic tick, not by this
                    // flow: a StateFlow only emits on change, so with the speed
                    // readout off nothing ever re-rendered and a toggled setting
                    // never reached the shade. Cancelling it here was worse still —
                    // cancel() is a no-op on a foreground service notification, so
                    // "show notification = off" just froze it instead.
                    is EngineState.Running -> Unit
                    is EngineState.Error -> {
                        Log.e(TAG, "Engine error: ${state.message}")
                        VpnLogBus.error("CORE", state.message)
                    }
                    else -> Unit
                }
            }
        }
    }

    private fun ensureSessionStarted() {
        val prefs = getSharedPreferences("lumen_prefs", MODE_PRIVATE)
        if (prefs.getLong("session_started_at", 0L) <= 0L) {
            prefs.edit().putLong("session_started_at", System.currentTimeMillis()).apply()
            sessionUploaded = 0L
            sessionDownloaded = 0L
        }
    }

    private fun clearSessionState() {
        getSharedPreferences("lumen_prefs", MODE_PRIVATE)
            .edit()
            .remove("session_started_at")
            .apply()
        sessionUploaded = 0L
        sessionDownloaded = 0L
        _trafficStats.value = TrafficStats()
    }

    private fun readHevTrafficCounters(): TrafficCounters? =
        runCatching { countersFromHev(TProxyService.TProxyGetStats()) }
            .onFailure {
                VpnLogBus.warning("TUN2SOCKS", "Could not read native tunnel state: ${it.message}")
            }
            .getOrNull()

    private fun readUidTrafficCounters(uid: Int): TrafficCounters {
        val rx = AndroidTrafficStats.getUidRxBytes(uid).coerceAtLeast(0L)
        val tx = AndroidTrafficStats.getUidTxBytes(uid).coerceAtLeast(0L)
        return TrafficCounters(
            source = TrafficCounterSource.APP_UID,
            uploaded = tx,
            downloaded = rx
        )
    }

    /**
     * Read the actual TUN counters exported by bundled hev. Proxy-only mode has no
     * TUN, so it falls back to Android UID counters for the local proxy process.
     * UID counters include subscription/telemetry traffic and therefore are not the
     * primary speed source for a regular VPN session.
     */
    private fun startTrafficStats() {
        trafficStatsJob?.cancel()
        trafficStatsJob = serviceScope.launch {
            val uid = Process.myUid()
            val proxyOnly = activeParams?.proxyOnly == true
            var previous = if (proxyOnly) {
                readUidTrafficCounters(uid)
            } else {
                readHevTrafficCounters() ?: readUidTrafficCounters(uid)
            }
            var previousTime = SystemClock.elapsedRealtimeNanos()
            var nativeReadFailures = 0
            while (true) {
                delay(1_000)
                val nativeRunning = if (proxyOnly) {
                    true
                } else {
                    runCatching { TProxyService.TProxyIsRunning() }
                        .onFailure {
                            VpnLogBus.warning(
                                "TUN2SOCKS",
                                "Could not read native worker state: ${it.message}"
                            )
                        }
                        .getOrDefault(false)
                }
                if (tunnelStarted.get() && !nativeRunning) {
                    onTunnelFailure("hev-socks5-tunnel native worker exited")
                    return@launch
                }
                val now = SystemClock.elapsedRealtimeNanos()
                val nativeCounters = if (proxyOnly) null else readHevTrafficCounters()
                if (nativeCounters == null && tunnelStarted.get()) {
                    nativeReadFailures++
                    if (nativeReadFailures >= MAX_NATIVE_STATS_FAILURES) {
                        onTunnelFailure("hev-socks5-tunnel stopped responding")
                        return@launch
                    }
                } else {
                    nativeReadFailures = 0
                }
                val current = nativeCounters ?: readUidTrafficCounters(uid)
                val rate = trafficRate(previous, current, now - previousTime)
                previous = current
                previousTime = now
                // Totals are runtime state, not a display option. Keep counting
                // while the speed cards/notification are disabled.
                sessionUploaded += rate.uploadedDelta
                sessionDownloaded += rate.downloadedDelta

                val enabled = getSharedPreferences(VpnStartIntentFactory.PREFS_NAME, MODE_PRIVATE)
                    .getBoolean(NotificationHelper.PREF_SPEED_STATS, true)
                val stats = if (enabled) {
                    TrafficStats(
                        uploadSpeed = rate.uploadBytesPerSecond,
                        downloadSpeed = rate.downloadBytesPerSecond,
                        totalUploaded = sessionUploaded,
                        totalDownloaded = sessionDownloaded
                    )
                } else {
                    TrafficStats(
                        totalUploaded = sessionUploaded,
                        totalDownloaded = sessionDownloaded
                    )
                }
                _trafficStats.value = stats
                engineManager.updateTrafficStats(stats)
                // The only steady clock the notification has. updateNotification
                // re-posts solely when the rendered result changed, so this both
                // keeps the speeds current and lets a setting toggled in the app
                // take effect within a second without any churn in between.
                if (_isRunning.value) {
                    NotificationHelper.updateNotification(this@LumenVpnService, stats, true)
                }
            }
        }
    }

    private fun stopVpn() {
        // stopSelf() only stops when the id is the most recent one, so the teardown
        // must name the start it is ending. Reading lastStartId once the coroutine
        // runs would name the reconnect that arrived in the meantime and kill it.
        val stoppingStartId = lastStartId
        // A user initiated stop must not be undone by a pending network reconnect.
        unregisterNetworkMonitor()
        startJob?.cancel()
        startJob = null
        restartJob?.cancel()
        restartJob = null
        restartingForNetwork = false
        _isStarting.value = false
        activeParams = null
        clearSessionState()
        serviceScope.launch {
            stopRuntime(closeInterface = true)
            stopForeground(STOP_FOREGROUND_REMOVE)
            // stopForeground alone leaves the notification behind on some ROMs when
            // the service is not destroyed straight away.
            NotificationHelper.cancel(this@LumenVpnService)
            stopSelf(stoppingStartId)
        }
    }

    /**
     * "Pause": the same tunnel teardown as [stopVpn], but the notification survives
     * as a plain, dismissible one showing Reconnect instead of disappearing. Traffic
     * bypasses the tunnel immediately, same as a full disconnect — the difference is
     * only what happens to the notification, so the user can restart the same
     * server with one tap instead of reopening the app.
     */
    private fun pauseVpn() {
        val stoppingStartId = lastStartId
        unregisterNetworkMonitor()
        startJob?.cancel()
        startJob = null
        restartJob?.cancel()
        restartJob = null
        restartingForNetwork = false
        _isStarting.value = false
        activeParams = null
        clearSessionState()
        serviceScope.launch {
            stopRuntime(closeInterface = true)
            // DETACH (not REMOVE): keeps the existing notification on screen as a
            // normal, dismissible one so it can be updated to show Reconnect below.
            stopForeground(STOP_FOREGROUND_DETACH)
            NotificationHelper.postPaused(this@LumenVpnService)
            stopSelf(stoppingStartId)
        }
    }

    /**
     * Starts the loopback obfs2/obfs3 transport when the selected OpenVPN profile
     * routes through an obfsproxy bridge. Plain http/socks proxies need no relay:
     * the core dials them directly through its detour outbound.
     */
    private fun startObfsRelay(params: StartParams) {
        stopObfsRelay()
        if (params.obfsType.isBlank() || params.obfsHost.isBlank() || params.obfsPort !in 1..65535) return
        require(params.obfsType.lowercase() in setOf("obfs2", "obfs3")) {
            "Unsupported OpenVPN obfuscation transport: ${params.obfsType}"
        }
        val relay = ObfsRelay(
            localPort = OBFS_LOCAL_PORT,
            type = params.obfsType,
            bridgeHost = params.obfsHost,
            bridgePort = params.obfsPort,
            protect = { socket -> protect(socket) }
        )
        try {
            relay.start()
            obfsRelay = relay
            VpnLogBus.info("OBFS", "${params.obfsType} relay is ready on 127.0.0.1:$OBFS_LOCAL_PORT")
        } catch (t: Throwable) {
            runCatching { relay.stop() }
            throw IllegalStateException("Failed to start the ${params.obfsType} relay", t)
        }
    }

    private fun stopObfsRelay() {
        obfsRelay?.let { runCatching { it.stop() } }
        obfsRelay = null
    }

    private suspend fun stopRuntime(closeInterface: Boolean) = runtimeMutex.withLock {
        stopRuntimeLocked(closeInterface)
    }

    private suspend fun stopRuntimeLocked(closeInterface: Boolean) {
        stopObfsRelay()
        trafficStatsJob?.cancel()
        trafficStatsJob = null
        stateJob?.cancel()
        stateJob = null
        if (tunnelStarted.compareAndSet(true, false)) {
            VpnLogBus.info("TUN2SOCKS", "Stopping native tunnel")
            runCatching {
                check(TProxyService.TProxyStopService()) {
                    "native worker could not be joined"
                }
            }
                .onFailure { VpnLogBus.warning("TUN2SOCKS", "Stop failed: ${it.message}") }
        }
        runCatching { engineManager.stopEngine() }
            .onFailure { Log.w(TAG, "Failed to stop engine", it) }
        if (closeInterface) {
            runCatching { vpnInterface?.close() }
            vpnInterface = null
        }
        _isRunning.value = false
        notifyWidgets()
    }

    /**
     * Home screen widgets only refresh when they are told to. The broadcast has
     * to be explicit (setPackage), otherwise Android 8+ drops it before it ever
     * reaches the manifest-declared receiver.
     */
    private fun notifyWidgets() {
        runCatching {
            sendBroadcast(
                Intent(WIDGET_UPDATE_ACTION).setPackage(packageName)
            )
        }
    }

    override fun onDestroy() {
        stopObfsRelay()
        unregisterNetworkMonitor()
        restartJob?.cancel()
        restartJob = null
        startJob?.cancel()
        startJob = null
        restartingForNetwork = false
        _isStarting.value = false
        activeParams = null
        clearSessionState()
        trafficStatsJob?.cancel()
        trafficStatsJob = null
        stateJob?.cancel()
        if (tunnelStarted.compareAndSet(true, false)) {
            runCatching { TProxyService.TProxyStopService() }
        }
        // onDestroy runs on the main thread and a system initiated destroy (revoked
        // consent, another VPN app) can land while a start still holds the engine
        // mutex, so never wait for the shutdown here.
        val manager = engineManager
        thread(name = "lumen-engine-shutdown") {
            runBlocking { runCatching { manager.stopEngine() } }
        }
        runCatching { vpnInterface?.close() }
        vpnInterface = null
        _isRunning.value = false
        _notificationsBlocked.value = false
        NotificationHelper.cancel(this)
        notifyWidgets()
        serviceScope.cancel()
        super.onDestroy()
    }

    private fun logEngine(line: String) {
        Log.i(TAG, line)
        when {
            line.contains("fatal", ignoreCase = true) || line.contains("panic", ignoreCase = true) ->
                VpnLogBus.error("CORE", line)
            line.contains("warn", ignoreCase = true) || line.contains("error", ignoreCase = true) ->
                VpnLogBus.warning("CORE", line)
            else -> VpnLogBus.info("CORE", line)
        }
    }

    companion object {
        private const val TAG = "UcProVpnService"
        private const val LOCAL_SOCKS_PORT = 10808
        private const val PREF_VALIDATE_PROXY_DATA_PATH = "validate_proxy_data_path"
        private const val PREF_PING_URL = "ping_url"
        private const val PROXY_PROBE_TIMEOUT_MS = 4_000
        // AWG/WireGuard needs a handshake before the first probe can succeed.
        private const val PROXY_PROBE_ATTEMPTS = 3
        private const val PROXY_PROBE_RETRY_DELAY_MS = 1_200L
        private val DEFAULT_PROXY_PROBE_URLS = listOf(
            "https://cp.cloudflare.com/generate_204",
            "https://www.gstatic.com/generate_204"
        )
        // Losing the local port to a core that is still shutting down is retried,
        // never reported as a dead connection.
        private const val CORE_START_ATTEMPTS = 3
        private const val CORE_START_RETRY_DELAY_MS = 600L
        // Remote SRS rule-sets are initialized before the local inbound opens.
        private const val SOCKS_READY_ATTEMPTS = 200
        private const val TUN_STARTUP_GRACE_MS = 500L
        private const val MAX_NATIVE_STATS_FAILURES = 3
        // Reconnect behaviour after the default network changed.
        private const val NETWORK_SETTLE_DELAY_MS = 900L
        private const val NETWORK_RESOLVE_ATTEMPTS = 4
        private const val NETWORK_RESOLVE_RETRY_DELAY_MS = 350L
        private const val NETWORK_RESTART_ATTEMPTS = 3
        private const val NETWORK_RESTART_RETRY_DELAY_MS = 1_500L
        // Kept as a literal (and not a reference to the app module) because
        // :core:vpn must not depend on :app.
        const val WIDGET_UPDATE_ACTION = "com.ucprovpn.app.widget.ACTION_UPDATE_STATE"
        const val ACTION_START_VPN = "com.ucprovpn.core.vpn.START_VPN"
        const val ACTION_STOP_VPN = "com.ucprovpn.core.vpn.STOP_VPN"
        const val ACTION_PAUSE_VPN = "com.ucprovpn.core.vpn.PAUSE_VPN"
        const val EXTRA_ENGINE_TYPE = "extra_engine_type"
        const val EXTRA_CONFIG_JSON = "extra_config_json"
        const val EXTRA_CONFIG_PATH = "extra_config_path"
        const val EXTRA_SPLIT_MODE = "extra_split_mode"
        const val EXTRA_SPLIT_PACKAGES = "extra_split_packages"
        const val EXTRA_MTU = "extra_mtu"
        const val EXTRA_LOCAL_SOCKS_PORT = "extra_local_socks_port"
        const val EXTRA_PROXY_ONLY = "extra_proxy_only"
        const val EXTRA_DNS_MODE = "extra_dns_mode"
        const val EXTRA_RECONNECT_ON_NETWORK_CHANGE = "extra_reconnect_on_network_change"
        const val EXTRA_OBFS_TYPE = "extra_obfs_type"
        const val EXTRA_OBFS_HOST = "extra_obfs_host"
        const val EXTRA_OBFS_PORT = "extra_obfs_port"
        // Must match SingboxConfigBuilder.OBFS_LOCAL_PORT.
        const val OBFS_LOCAL_PORT = 10871
        const val DEFAULT_IPV4_ADDRESS = "172.19.0.1"
        const val DEFAULT_IPV4_PREFIX = 30
        const val DEFAULT_IPV6_ADDRESS = "fdfe:dcba:9876::1"
        const val DEFAULT_IPV6_PREFIX = 126
        const val DEFAULT_MTU = 1500
        const val INTERNAL_DNS_ADDRESS = "172.19.0.2"
        val DEFAULT_DNS_SERVERS = listOf("1.1.1.1", "8.8.8.8")
        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()
        private val _isStarting = MutableStateFlow(false)
        val isStarting: StateFlow<Boolean> = _isStarting.asStateFlow()
        private val _trafficStats = MutableStateFlow(TrafficStats())
        val trafficStats: StateFlow<TrafficStats> = _trafficStats.asStateFlow()
        private val _notificationsBlocked = MutableStateFlow(false)

        /**
         * True while the tunnel runs but Android will not show its notification,
         * which on 13+ is the ordinary outcome of denying POST_NOTIFICATIONS. The
         * service keeps working, so nothing else makes the state visible.
         */
        val notificationsBlocked: StateFlow<Boolean> = _notificationsBlocked.asStateFlow()
    }
}

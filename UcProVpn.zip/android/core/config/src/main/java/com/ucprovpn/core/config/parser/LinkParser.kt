package com.ucprovpn.core.config.parser

import com.ucprovpn.core.config.normalizer.OpenVpnConfigNormalizer
import com.ucprovpn.core.config.crypto.HappCrypt
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import org.yaml.snakeyaml.Yaml
import java.net.URI
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Base64
import java.util.regex.Pattern

open class LinkParseError(message: String, cause: Throwable? = null) : Exception(message, cause)

data class ParsedNode(
    var name: String,
    var scheme: String,
    var server: String,
    var port: Int,
    var link: String,
    var outbound: Map<String, Any?> = emptyMap(),
    var description: String = ""
)

object LinkParser {

    private val WHITESPACE_REGEX = Regex("\\s+")
    // Used to split glued or space separated links inside a single line.
    private val SCHEME_SPLIT_REGEX = Regex(
        "(?i)(vless|vmess|trojan|ss|ssr|hysteria2|hysteria|hy2|hy|tuic|wireguard|wg|awg|" +
            "amneziawg|warp|naive\\+https|naive\\+quic|naive|mierus|mieru|masque|socks5|socks|" +
            "https|http|happ|snell|juicity|anytls)://"
    )
    // The extended core types the AmneziaWG options: jc/jmin/jmax/s1..s4/itime are
    // integers, header-protection and packet definitions are strings, and the
    // remaining AWG 3.x timing/padding values are uint32 ranges.
    private val AMNEZIA_INT_KEYS = setOf("jc", "jmin", "jmax", "s1", "s2", "s3", "s4", "itime")
    private val AMNEZIA_RANGE_KEYS = setOf(
        "h1", "h2", "h3", "h4",
        "content_padding_addition", "rekey_after_time", "rekey_timeout",
        "reject_after_time", "keepalive_timeout", "max_handshake_attempts"
    )
    private val AMNEZIA_STR_KEYS = setOf(
        "i1", "i2", "i3", "i4", "i5", "j1", "j2", "j3",
        "header_protection_key"
    )
    private val AMNEZIA_JUNK_KEYS = AMNEZIA_INT_KEYS + AMNEZIA_RANGE_KEYS + AMNEZIA_STR_KEYS

    /** Maps .conf, URI and Clash spelling variants onto sing-box-extended JSON keys. */
    private fun canonicalAmneziaKey(rawKey: Any?): String? {
        val compact = rawKey?.toString()?.trim()?.lowercase()
            ?.replace("_", "")?.replace("-", "") ?: return null
        return AMNEZIA_JUNK_KEYS.firstOrNull { candidate ->
            candidate.replace("_", "") == compact
        }
    }

    private fun amneziaOptionsFrom(vararg maps: Map<*, *>): Map<String, Any?> {
        val values = linkedMapOf<String, Any?>()
        maps.forEach { map ->
            map.forEach { (rawKey, value) ->
                canonicalAmneziaKey(rawKey)?.let { key ->
                    amneziaValue(key, value)?.let { values[key] = it }
                }
            }
        }
        return values
    }

    // A happ crypt link may hide a subscription URL instead of a node; it has to
    // go through the subscription fetch (parity with desktop node_service).
    const val HAPP_SUBSCRIPTION_ERROR = "Happ link contains a subscription URL, add it as a subscription"

    const val MAX_IMPORT_BYTES = 8 * 1024 * 1024
    const val MAX_IMPORT_LINES = 20000
    const val MAX_IMPORT_NODES = 20000

    private val AUTO_GROUP_TYPES = setOf("urltest", "url-test", "selector", "select", "fallback", "load-balance", "auto")

    // Keys only a Clash/Mihomo proxy object uses; sing-box and Xray never spell a
    // field with a dash, so one of these marks a bare JSON proxy as Clash-shaped.
    private val CLASH_PROXY_MARKER_KEYS = setOf(
        "private-key", "public-key", "pre-shared-key", "allowed-ips", "persistent-keepalive",
        "amnezia-wg-option", "amnezia-options", "remote-dns-resolve", "skip-cert-verify",
        "client-fingerprint", "reality-opts", "ws-opts", "grpc-opts", "h2-opts", "http-opts",
        "obfs-opts", "plugin-opts", "udp-over-tcp", "congestion-controller", "ip-version",
        "auth-str", "hop-interval", "disable-mtu-discovery", "recv-window-conn", "dialer-proxy"
    )
    private val CLASH_SUPPORTED_PROXY_TYPES = setOf(
        "vless", "vmess", "trojan",
        "ss", "shadowsocks",
        "hysteria", "hy", "hysteria2", "hy2",
        "tuic", "naive", "mieru", "masque", "anytls", "snell",
        "wireguard", "wg", "awg", "amneziawg", "amnezia-wg",
        "socks", "socks5", "http", "https"
    )

    private val LOOPBACK_HOSTS = setOf("127.0.0.1", "localhost", "0.0.0.0", "::1")
    private val CLOUDFLARE_WARP_PEER_KEYS = setOf(
        "bmXOC+F1FxEMF9dyiK2H5/1SUtzH0JuVo51h2wPfgyo="
    )

    /** Packs a urltest/selector pool into one AUTO node (parity with desktop Lumen). */
    private fun autoNodeFromMembers(name: String, members: List<ParsedNode>): ParsedNode {
        // WARP generators often wrap one endpoint in a selector solely for
        // compatibility with Clash. It is not an automatic pool and desktop
        // Lumen exposes it as WARP, so keep the actual protocol on Android too.
        if (members.size == 1 && isWarpMember(members.first())) {
            val member = members.first()
            return member.copy(
                name = member.name.ifBlank { name.ifBlank { "WARP" } }
            )
        }
        val packed = members.map { member ->
            mapOf(
                "name" to member.name,
                "scheme" to member.scheme,
                "server" to member.server,
                "port" to member.port,
                "link" to member.link,
                "outbound" to member.outbound
            )
        }
        val packedOutbound = mutableMapOf<String, Any?>(
            "protocol" to "auto",
            "auto_members" to packed
        )
        warpPoolDisplayProtocol(members)?.let { displayProtocol ->
            // Keep urltest internally so every WARP endpoint remains usable, but
            // do not expose a Clash compatibility selector as a generic AUTO node.
            packedOutbound["warp"] = true
            packedOutbound["display_protocol"] = displayProtocol
        }
        return ParsedNode(
            name = name,
            scheme = "auto",
            server = "",
            port = 0,
            link = "auto",
            outbound = packedOutbound
        )
    }

    private fun warpPoolDisplayProtocol(members: List<ParsedNode>): String? {
        if (members.isEmpty() || members.any { !isWarpMember(it) }) return null
        return when {
            members.all { it.scheme.equals("masque", true) } -> "MASQUE/WARP"
            members.any {
                it.scheme.equals("awg", true) ||
                    it.outbound.toString().contains("amnezia", ignoreCase = true)
            } -> "AWG/WARP"
            members.all {
                it.scheme.equals("wireguard", true) ||
                    it.scheme.equals("wg", true) ||
                    it.scheme.equals("warp", true)
            } -> "WireGuard/WARP"
            else -> "WARP"
        }
    }

    private fun isWarpMember(node: ParsedNode): Boolean {
        if (node.scheme.equals("warp", true)) return true
        val haystack = buildString {
            append(node.name.lowercase())
            append(' ')
            append(node.server.lowercase())
            append(' ')
            append(node.link.lowercase())
            append(' ')
            append(node.outbound.toString().lowercase())
        }
        return "\"warp\":true" in haystack.replace(" ", "") ||
            "warp" in haystack ||
            "cloudflareclient.com" in haystack ||
            listOf(
                "162.159.192.", "162.159.193.", "162.159.198.", "188.114.",
                "2606:4700:110:", "2606:4700:d0:", "2606:4700:d1:"
            )
                .any { it in haystack }
    }

    private fun isCloudflareWarpProfile(
        addresses: List<String>,
        publicKey: String,
        server: String
    ): Boolean {
        if (publicKey.trim() in CLOUDFLARE_WARP_PEER_KEYS) return true
        val normalizedAddresses = addresses.map { it.trim().lowercase() }
        if (normalizedAddresses.any { it.startsWith("2606:4700:110:") }) return true
        val host = server.trim().lowercase()
        return normalizedAddresses.any { it.substringBefore('/') == "172.16.0.2" } &&
            listOf("162.159.192.", "162.159.193.", "162.159.198.", "188.114.")
                .any { prefix -> host.startsWith(prefix) }
    }

    /**
     * Panels ship a first "separator"/header profile that points nowhere
     * (127.0.0.1:1). Such entries must never become a server row.
     */
    private fun isPlaceholderNode(node: ParsedNode): Boolean {
        val host = node.server.trim().lowercase()
        if (host in LOOPBACK_HOSTS && node.port == 1) return true
        // Xray keeps the real address nested under settings.servers/vnext, so the
        // whole outbound has to be scanned.
        return hasPlaceholderTarget(node.outbound)
    }

    private fun hasPlaceholderTarget(value: Any?): Boolean = when (value) {
        is Map<*, *> -> {
            val entries = value.entries.associate {
                it.key?.toString()?.lowercase().orEmpty() to it.value
            }
            val separator = entries["password"]?.toString()?.trim()?.equals("separator", true) == true
            val host = listOf("address", "server", "host")
                .firstNotNullOfOrNull { entries[it]?.toString()?.trim()?.lowercase() }
            val port = listOf("port", "server_port")
                .firstNotNullOfOrNull { entries[it]?.toString()?.trim()?.toIntOrNull() }
            separator || (host in LOOPBACK_HOSTS && port == 1) ||
                value.values.any { nested ->
                    (nested is Map<*, *> || nested is List<*>) && hasPlaceholderTarget(nested)
                }
        }
        is List<*> -> value.any { hasPlaceholderTarget(it) }
        else -> false
    }

    /** Restores the servers packed into an AUTO node by [autoNodeFromMembers]. */
    fun autoMembers(outbound: Map<String, Any?>): List<ParsedNode> {
        val packed = outbound["auto_members"] as? List<*> ?: return emptyList()
        return packed.mapNotNull { item ->
            val map = item as? Map<*, *> ?: return@mapNotNull null
            @Suppress("UNCHECKED_CAST")
            val memberOutbound = (map["outbound"] as? Map<String, Any?>) ?: emptyMap()
            val port = (map["port"] as? Number)?.toInt() ?: map["port"]?.toString()?.toIntOrNull() ?: 0
            ParsedNode(
                name = map["name"]?.toString().orEmpty(),
                scheme = map["scheme"]?.toString().orEmpty(),
                server = map["server"]?.toString().orEmpty(),
                port = port,
                link = map["link"]?.toString().orEmpty(),
                outbound = memberOutbound
            )
        }
    }

    private fun parseLinksTextInternal(text: String, depth: Int = 0): Pair<List<ParsedNode>, List<String>> {
        if (depth > 16) return Pair(emptyList(), listOf("Subscription nesting exceeds 16 levels"))
        val bytes = text.toByteArray(Charsets.UTF_8)
        if (bytes.size > MAX_IMPORT_BYTES) {
            return Pair(emptyList(), listOf("Import data exceeds the $MAX_IMPORT_BYTES-byte limit"))
        }

        var stripped = text.trim().removePrefix("\uFEFF").trim()
        if (HappCrypt.isHappCryptLink(stripped)) {
            try {
                stripped = HappCrypt.decryptHappLink(stripped).trim()
            } catch (e: Exception) {
                return Pair(emptyList(), listOf("Happ crypt decryption failed: ${e.message}"))
            }
            if (isSubscriptionUrl(stripped)) {
                return Pair(emptyList(), listOf(HAPP_SUBSCRIPTION_ERROR))
            }
        }

        if (stripped.startsWith("{") || stripped.startsWith("[") || stripped.startsWith(34.toChar())) {
            try {
                return parseJsonNodesText(stripped, depth)
            } catch (e: Exception) {
                // If the top-level JSON parse failed and input starts with '{',
                // try NDJSON (newline-delimited JSON objects, one per line).
                if (stripped.startsWith("{")) {
                    val ndjson = tryParseJsonLines(stripped, depth)
                    if (ndjson != null) return ndjson
                }
                // Never scan JSON syntax as URI fragments: it corrupts display
                // names and credentials. WireGuard INI is the only '[' exception.
                if (!stripped.startsWith("[Interface]", ignoreCase = true)) {
                    return Pair(emptyList(), listOf("JSON error: ${e.message}"))
                }
            }
        }

        if (looksLikeClashYaml(stripped)) {
            try {
                return parseClashYamlNodesText(stripped)
            } catch (e: Exception) {
                return Pair(emptyList(), listOf("Clash YAML error: ${e.message}"))
            }
        }

        if (looksLikeOpenVpnConfig(stripped)) {
            try {
                val node = parseOpenVpnConfig(stripped)
                return Pair(listOf(node), emptyList())
            } catch (e: Exception) {
                return Pair(emptyList(), listOf("OpenVPN config error: ${e.message}"))
            }
        }

        val lowered = stripped.lowercase()
        if ("[interface]" in lowered && "[peer]" in lowered) {
            try {
                val node = parseWireGuardConfig(stripped)
                return Pair(listOf(node), emptyList())
            } catch (e: Exception) {
                return Pair(emptyList(), listOf("WireGuard config error: ${e.message}"))
            }
        }

        // Distinguish independently encoded records from a wrapped Base64 body.
        val encodedLines = stripped.lines().map(String::trim).filter(String::isNotEmpty)
        if (encodedLines.size in 2..MAX_IMPORT_LINES && encodedLines.all { isBase64Blob(it) }) {
            val decodedLines = encodedLines.map { runCatching { decodeB64(it).trim() }.getOrNull() }
            if (decodedLines.all { it != null && (SCHEME_SPLIT_REGEX.find(it)?.range?.first == 0 ||
                    (it.startsWith("{") && runCatching { parseCompleteJson(it) }.isSuccess)) }) {
                return parseLinksTextInternal(decodedLines.filterNotNull().joinToString("\n"), depth + 1)
            }
        }
        // Check if entire stripped string is a Base64 subscription
        if (isBase64Blob(stripped)) {
            try {
                val decoded = decodeB64(stripped).trim()
                if (decoded.isNotEmpty()) {
                    return parseLinksTextInternal(decoded, depth + 1)
                }
            } catch (e: Exception) {
                // Ignore base64 decoding failure, fall through to lines
            }
        }

        val lines = splitImportTokens(stripped)
        if (lines.size > MAX_IMPORT_LINES) {
            return Pair(emptyList(), listOf("Import contains more than $MAX_IMPORT_LINES non-empty lines"))
        }

        val nodes = mutableListOf<ParsedNode>()
        val errors = mutableListOf<String>()

        for ((idx, line) in lines.withIndex()) {
            try {
                var currentLine = line
                if (HappCrypt.isHappCryptLink(currentLine)) {
                    currentLine = HappCrypt.decryptHappLink(currentLine).trim()
                    if (isSubscriptionUrl(currentLine)) throw LinkParseError(HAPP_SUBSCRIPTION_ERROR)
                }
                if (currentLine.startsWith("{") || currentLine.startsWith("[") || currentLine.startsWith(34.toChar())) {
                    val (inner, innerErrors) = parseLinksTextInternal(currentLine, depth + 1)
                    nodes.addAll(inner)
                    errors.addAll(innerErrors.map { "Line ${idx + 1}: $it" })
                    continue
                }
                val node = parseSingle(currentLine)
                applyHappServerMetadata(node, currentLine)
                nodes.add(node)
            } catch (e: Exception) {
                // A single entry can itself be base64 (per-line encoded subscriptions).
                val nested = if (isBase64Blob(line)) {
                    runCatching { parseLinksTextInternal(decodeB64(line), depth + 1) }.getOrNull()
                } else null
                if (nested != null && nested.first.isNotEmpty()) {
                    nodes.addAll(nested.first)
                    errors.addAll(nested.second.map { "Line ${idx + 1}: $it" })
                } else {
                    errors.add("Line ${idx + 1}: ${e.message}")
                }
            }
        }

        if (nodes.isEmpty()) {
            // Last resort: the whole payload may be base64 that failed the strict
            // blob checks above (stray characters, percent-encoded padding).
            val candidate = runCatching {
                decodeB64(percentDecodeKeepPlus(stripped))
            }.getOrNull() ?: runCatching { decodeB64(stripped) }.getOrNull()
            if (!candidate.isNullOrBlank() && candidate.trim() != stripped) {
                val salvaged = runCatching { parseLinksTextInternal(candidate, depth + 1) }.getOrNull()
                if (salvaged != null && salvaged.first.isNotEmpty()) return salvaged
            }
        }

        return Pair(nodes, errors)
    }

    fun parseLinksText(text: String): Pair<List<ParsedNode>, List<String>> {
        val result = parseLinksTextInternal(text)
        return if (result.first.size > MAX_IMPORT_NODES) {
            Pair(emptyList(), listOf("Import contains more than $MAX_IMPORT_NODES nodes"))
        } else result
    }

    /**
     * Splits a payload into candidate entries: newline separated, but also comma,
     * whitespace and glued links such as "vless://a...vless://b...".
     */
    private fun splitImportTokens(text: String): List<String> {
        val result = mutableListOf<String>()
        for (rawLine in text.lines()) {
            var line = rawLine.trim().trim('\uFEFF').removeSurrounding("\"").trim()
            if (line.startsWith("- ")) line = line.removePrefix("- ").trim()
            if (line.isEmpty() || line.startsWith("//") || line.startsWith("#") || line.startsWith(";")) continue
            if (line.startsWith("{") || line.startsWith("[")) {
                result += line
                continue
            }
            val starts = SCHEME_SPLIT_REGEX.findAll(line).filter { match ->
                val start = match.range.first
                !match.value.startsWith("http", ignoreCase = true) || start == 0 ||
                    line[start - 1].isWhitespace() || line[start - 1] in ",;|"
            }.map { it.range.first }.toList()
            if (starts.size > 1) {
                for ((i, start) in starts.withIndex()) {
                    val end = if (i + 1 < starts.size) starts[i + 1] else line.length
                    line.substring(start, end).trim().trimEnd(',', ';', '|')
                        .takeIf { it.isNotEmpty() }?.let { result += it }
                }
            } else {
                result += line.trimEnd(',', ';', '|')
            }
        }
        return result
    }

    /** True when the payload is nothing but a single http(s) subscription URL. */
    fun isSubscriptionUrl(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.any { it.isWhitespace() }) return false
        val lowered = trimmed.lowercase()
        return lowered.startsWith("http://") || lowered.startsWith("https://")
    }

    fun parseSingle(raw: String): ParsedNode {
        val text = raw.trim()
        if (text.isEmpty()) {
            throw LinkParseError("Empty input")
        }

        if (HappCrypt.isHappCryptLink(text)) {
            val decrypted = HappCrypt.decryptHappLink(text).trim()
            if (isSubscriptionUrl(decrypted)) throw LinkParseError(HAPP_SUBSCRIPTION_ERROR)
            return parseSingle(decrypted)
        }

        if (text.startsWith("{")) {
            return parseJsonOutbound(text)
        }

        val scheme = try {
            val idx = text.indexOf("://")
            if (idx != -1) text.substring(0, idx).lowercase() else ""
        } catch (e: Exception) {
            ""
        }

        return when (scheme) {
            "vless" -> parseVless(text)
            "vmess" -> parseVmess(text)
            "trojan" -> parseTrojan(text)
            "ss" -> parseShadowsocks(text)
            "socks", "socks5" -> parseSocks(text)
            "http", "https" -> parseHttp(text)
            "wireguard", "wg", "awg", "amneziawg", "warp" -> parseWireGuardLink(text)
            "hysteria", "hy" -> parseHysteria1(text)
            "hysteria2", "hy2" -> parseHysteria2(text)
            "tuic" -> parseTuic(text)
            "naive", "naive+https", "naive+quic", "quic" -> parseNaiveLink(text, scheme)
            "mieru", "mierus" -> parseMieru(text)
            "masque" -> parseMasque(text)
            "anytls" -> parseAnyTls(text)
            else -> throw LinkParseError("Unsupported scheme: ${if (scheme.isEmpty()) "unknown" else scheme}")
        }
    }

    private fun safeCreateUri(link: String): URI {
        val raw = link.trim()
        val hashIdx = raw.indexOf('#')
        val linkWithoutFragment = if (hashIdx != -1) raw.substring(0, hashIdx) else raw
        return try {
            URI(linkWithoutFragment)
        } catch (e: Exception) {
            val safe = linkWithoutFragment.replace(" ", "%20")
            URI(safe)
        }
    }

    private fun extractFragment(link: String): String? {
        val idx = link.indexOf('#')
        return if (idx != -1) link.substring(idx + 1).trim() else null
    }

    private fun isBase64Blob(text: String): Boolean {
        val trimmed = text.trim()
        if (trimmed.startsWith("vless://") || trimmed.startsWith("vmess://") ||
            trimmed.startsWith("trojan://") || trimmed.startsWith("ss://") ||
            trimmed.startsWith("hy2://") || trimmed.startsWith("hysteria2://") ||
            trimmed.startsWith("tuic://") || trimmed.startsWith("happ://") ||
            trimmed.startsWith("{") || trimmed.startsWith("[") ||
            trimmed.lowercase().contains("[interface]")
        ) {
            return false
        }
        val clean = trimmed.filterNot { it.isWhitespace() }
        if (clean.length < 16) return false
        if (!clean.all { it.isLetterOrDigit() || it == '+' || it == '/' || it == '-' || it == '_' || it == '=' }) return false
        val decoded = try { decodeB64(clean).trim() } catch (e: Exception) { "" }
        return decoded.isNotEmpty() && (
            decoded.contains("://") || decoded.contains("\n") ||
            decoded.lowercase().contains("proxies:") || decoded.lowercase().contains("[interface]") ||
            decoded.startsWith("{") || decoded.startsWith("[")
        )
    }

    private fun decodeB64(data: String): String {
        var clean = data.trim().replace("-", "+").replace("_", "/")
        clean = clean.filterNot { it.isWhitespace() }
        val padLen = (4 - (clean.length % 4)) % 4
        clean += "=".repeat(padLen)
        val bytes = try {
            Base64.getDecoder().decode(clean)
        } catch (e: Exception) {
            Base64.getUrlDecoder().decode(clean)
        }
        return String(bytes, Charsets.UTF_8)
    }

    private fun decodeShadowsocksB64(data: String): String {
        var clean = percentDecodeKeepPlus(data).filterNot(Char::isWhitespace)
        if (clean.isEmpty() || clean.any { !it.isLetterOrDigit() && it !in "+/-_=" }) {
            throw LinkParseError("invalid shadowsocks base64 credentials")
        }
        clean = clean.replace('-', '+').replace('_', '/')
        clean += "=".repeat((4 - clean.length % 4) % 4)
        val bytes = runCatching { Base64.getDecoder().decode(clean) }
            .getOrElse { throw LinkParseError("invalid shadowsocks base64 credentials", it) }
        val decoded = runCatching {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes))
                .toString()
        }.getOrElse { throw LinkParseError("invalid shadowsocks base64 credentials", it) }
        if (decoded.any { it.code < 0x20 || it.code == 0x7f }) {
            throw LinkParseError("invalid shadowsocks credentials")
        }
        return decoded
    }

    private fun parseQueryParams(queryString: String?): Map<String, String> {
        if (queryString.isNullOrEmpty()) return emptyMap()
        val params = mutableMapOf<String, String>()
        val pairs = queryString.split("&")
        for (pair in pairs) {
            val idx = pair.indexOf("=")
            if (idx != -1) {
                val key = percentDecodeKeepPlus(pair.substring(0, idx)).lowercase()
                val value = percentDecodeKeepPlus(pair.substring(idx + 1))
                params[key] = value
            } else if (pair.isNotEmpty()) {
                params[percentDecodeKeepPlus(pair).lowercase()] = ""
            }
        }
        return params
    }

    private fun cleanName(name: String?, fallback: String): String {
        if (name.isNullOrBlank()) return fallback
        val decoded = percentDecodeKeepPlus(name.substringBefore("?")).trim()
        return decoded.ifEmpty { fallback }
    }

    // java.net.URI already percent-decodes getUserInfo(), so the raw component is
    // the only safe source: decoding twice corrupts '%' and '+' inside secrets.
    private fun userInfoOf(uri: URI): String? = uri.rawUserInfo?.let { percentDecodeKeepPlus(it) }

    private fun parseVless(link: String): ParsedNode {
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val userId = userInfoOf(uri) ?: throw LinkParseError("Invalid VLESS link: missing UUID")
        val server = uri.host ?: throw LinkParseError("Invalid VLESS link: missing host")
        val port = if (uri.port > 0) uri.port else 443

        val params = parseQueryParams(uri.rawQuery)
        val flow = params["flow"] ?: ""
        val encryption = params["encryption"] ?: "none"

        val user = mutableMapOf<String, Any?>("id" to userId, "encryption" to encryption)
        if (flow.isNotEmpty()) user["flow"] = flow

        val streamSettings = buildStreamSettings(params, defaultNetwork = "tcp", defaultSecurity = params["security"] ?: "none")
        val outbound = mutableMapOf<String, Any?>(
            "protocol" to "vless",
            "settings" to mapOf(
                "vnext" to listOf(
                    mapOf(
                        "address" to server,
                        "port" to port,
                        "users" to listOf(user)
                    )
                )
            ),
            "streamSettings" to streamSettings
        )

        if ((streamSettings["network"] as? String)?.lowercase() == "xhttp") {
            outbound["mux"] = mapOf("enabled" to false, "concurrency" to -1)
        }

        val name = cleanName(fragment, "vless-$server:$port")
        return ParsedNode(name = name, scheme = "vless", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseVmess(link: String): ParsedNode {
        val body = link.substringAfter("vmess://").trim()
        if (body.isEmpty()) throw LinkParseError("Empty VMess payload")

        val payloadJson = try {
            decodeB64(body)
        } catch (e: Exception) {
            throw LinkParseError("Invalid VMess base64 payload", e)
        }

        val json = try {
            JSONObject(payloadJson)
        } catch (e: Exception) {
            throw LinkParseError("Invalid VMess JSON payload", e)
        }

        val server = json.optString("add").ifEmpty { json.optString("server") }
        val port = json.optInt("port", 443)
        val id = json.optString("id")
        val aid = json.optInt("aid", 0)
        val scy = json.optString("scy", "auto").ifEmpty { "auto" }

        if (server.isEmpty() || id.isEmpty()) {
            throw LinkParseError("Invalid VMess JSON: missing add or id")
        }

        val params = mutableMapOf<String, String>()
        params["allowinsecure"] = json.optString("allowInsecure").ifBlank { json.optString("insecure") }
        params["type"] = json.optString("net", "tcp")
        params["security"] = json.optString("tls", "none")
        params["host"] = json.optString("host")
        params["path"] = json.optString("path")
        params["sni"] = json.optString("sni")
        params["alpn"] = json.optString("alpn")
        params["fp"] = json.optString("fp")
        params["pinsha256"] = json.optString("pinSHA256")
            .ifBlank { json.optString("certificate_public_key_sha256") }

        val user = mapOf("id" to id, "alterId" to aid, "security" to scy)
        val streamSettings = buildStreamSettings(params, defaultNetwork = "tcp", defaultSecurity = params["security"] ?: "none")

        val outbound = mapOf<String, Any?>(
            "protocol" to "vmess",
            "settings" to mapOf(
                "vnext" to listOf(
                    mapOf(
                        "address" to server,
                        "port" to port,
                        "users" to listOf(user)
                    )
                )
            ),
            "streamSettings" to streamSettings
        )

        val name = json.optString("ps").ifEmpty { "vmess-$server:$port" }
        return ParsedNode(name = name, scheme = "vmess", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseTrojan(link: String): ParsedNode {
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val password = userInfoOf(uri) ?: throw LinkParseError("Invalid Trojan link: missing password")
        val server = uri.host ?: throw LinkParseError("Invalid Trojan link: missing host")
        val port = if (uri.port > 0) uri.port else 443

        val params = parseQueryParams(uri.rawQuery)
        val streamSettings = buildStreamSettings(params, defaultNetwork = "tcp", defaultSecurity = params["security"] ?: "tls")

        val outbound = mapOf<String, Any?>(
            "protocol" to "trojan",
            "settings" to mapOf(
                "servers" to listOf(
                    mapOf(
                        "address" to server,
                        "port" to port,
                        "password" to password
                    )
                )
            ),
            "streamSettings" to streamSettings
        )

        val name = cleanName(fragment, "trojan-$server:$port")
        return ParsedNode(name = name, scheme = "trojan", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseShadowsocks(link: String): ParsedNode {
        val body = link.substringAfter("ss://").trim()
        val fragment = extractFragment(link)
        val location = body.substringBefore("#")
        // '?' is not in either Base64 alphabet, so it is always safe to separate
        // the query before decoding both SIP002 and legacy whole-location forms.
        val mainPart = location.substringBefore("?")
        val params = parseQueryParams(location.substringAfter("?", ""))
        val hasSip002Authority = mainPart.contains("@")

        val server: String
        val port: Int
        var method = ""
        var password = ""

        if (hasSip002Authority) {
            val userAndHost = mainPart
            val userStr = userAndHost.substringBeforeLast("@")
            val hostStr = userAndHost.substringAfterLast("@")

            // SIP002 puts a '/' between the authority and the plugin query and
            // allows IPv6 literals, so the authority needs a real splitter.
            val hostAndPort = splitHostPort(hostStr, 8388, "Shadowsocks")
            server = hostAndPort.first
            port = hostAndPort.second

            if (userStr.contains(":")) {
                method = percentDecodeKeepPlus(userStr.substringBefore(":"))
                password = percentDecodeKeepPlus(userStr.substringAfter(":"))
            } else {
                val decodedUser = decodeShadowsocksB64(userStr)
                if (!decodedUser.contains(":")) throw LinkParseError("invalid shadowsocks credentials")
                method = decodedUser.substringBefore(":")
                password = decodedUser.substringAfter(":")
            }
        } else {
            val decoded = decodeShadowsocksB64(mainPart)
            if (decoded.contains("@") && decoded.contains(":")) {
                val userStr = decoded.substringBeforeLast("@")
                val hostAndPort = splitHostPort(decoded.substringAfterLast("@"), 8388, "Shadowsocks")
                server = hostAndPort.first
                port = hostAndPort.second
                method = userStr.substringBefore(":")
                password = userStr.substringAfter(":", "")
            } else {
                throw LinkParseError("Invalid Shadowsocks link format")
            }
        }

        // The builder accepts an empty password only for the `none` method.
        if (method.isEmpty() || server.isEmpty() || (password.isEmpty() && method.lowercase() != "none")) {
            throw LinkParseError("invalid shadowsocks link")
        }

        val serverMap = mutableMapOf<String, Any?>(
            "address" to server,
            "port" to port,
            "method" to method,
            "password" to password
        )
        // SIP003: the plugin query packs "<name>;<opts>" into one value, while the
        // core wants the name and the options in separate keys.
        params["plugin"]?.takeIf { it.isNotEmpty() }?.let { raw ->
            val plugin = normalizeShadowsocksPluginName(raw.substringBefore(";"))
            serverMap["plugin"] = plugin
            val opts = (params["plugin_opts"] ?: params["plugin-opts"] ?: raw.substringAfter(";", ""))
            val normalizedOpts = if (plugin == "obfs-local") normalizeObfsPluginOptions(opts) else opts
            if (normalizedOpts.isNotEmpty()) serverMap["plugin_opts"] = normalizedOpts
        }

        val outbound = mapOf<String, Any?>(
            "protocol" to "shadowsocks",
            "settings" to mapOf("servers" to listOf(serverMap))
        )

        val name = cleanName(fragment, "ss-$server:$port")
        return ParsedNode(name = name, scheme = "ss", server = server, port = port, link = link, outbound = outbound)
    }

    private fun normalizeShadowsocksPluginName(value: String): String = when (value.trim().lowercase()) {
        "obfs", "simple-obfs" -> "obfs-local"
        else -> value.trim().lowercase()
    }

    private fun splitSip003(value: String, delimiter: Char): List<String> {
        val result = mutableListOf<String>()
        val current = StringBuilder()
        var escaped = false
        value.forEach { char ->
            if (char == delimiter && !escaped) {
                result += current.toString()
                current.clear()
            } else {
                current.append(char)
            }
            escaped = char == '\\' && !escaped
        }
        result += current.toString()
        return result
    }

    private fun normalizeObfsPluginOptions(value: String): String = splitSip003(value.trim(), ';')
        .filter(String::isNotEmpty)
        .joinToString(";") { item ->
            val parts = splitSip003(item, '=')
            val key = parts.first().trim()
            val mapped = when (key.lowercase()) {
                "mode" -> "obfs"
                "host" -> "obfs-host"
                else -> key
            }
            if (parts.size > 1) "$mapped=${parts.drop(1).joinToString("=")}" else mapped
        }

    private fun sip003OptionsFromMapping(value: Map<*, *>, obfs: Boolean): String {
        fun escape(component: Any?): String = component.toString()
            .replace("\\", "\\\\").replace(";", "\\;").replace("=", "\\=")
        return value.entries.joinToString(";") { (rawKey, rawValue) ->
            val key = if (obfs) {
                when (rawKey.toString().trim().lowercase()) {
                    "mode" -> "obfs"
                    "host" -> "obfs-host"
                    else -> rawKey.toString()
                }
            } else rawKey.toString()
            if (rawValue == true) escape(key) else "${escape(key)}=${escape(rawValue)}"
        }
    }

    private fun shadowsocksUserInfo(method: String, password: String): String =
        if (method.trim().lowercase().startsWith("2022-")) {
            "${percentEncode(method.trim())}:${percentEncode(password)}"
        } else {
            Base64.getUrlEncoder().withoutPadding()
                .encodeToString("${method.trim()}:$password".toByteArray(Charsets.UTF_8))
        }

    private fun percentEncode(value: String): String =
        java.net.URLEncoder.encode(value, "UTF-8").replace("+", "%20")

    private fun uriHost(value: String): String {
        val host = value.trim().removePrefix("[").removeSuffix("]")
        return if (host.contains(':')) "[$host]" else host
    }

    private fun parseHysteria1(link: String): ParsedNode {
        // Hysteria v1 is a distinct sing-box outbound type with auth_str,
        // up/down speeds and a plain-string obfs (parity with desktop Lumen).
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val params = parseQueryParams(uri.rawQuery)
        val server = uri.host ?: params["server"] ?: params["address"] ?: params["host"]
            ?: throw LinkParseError("Invalid Hysteria link: missing host")
        val port = if (uri.port > 0) uri.port else params["port"]?.toIntOrNull() ?: 443
        val auth = userInfoOf(uri)?.takeIf { it.isNotEmpty() }
            ?: params["auth"] ?: params["auth_str"] ?: params["authstr"] ?: params["password"] ?: ""
        if (auth.isEmpty()) throw LinkParseError("hysteria link must contain server and auth/password")

        val singbox = mutableMapOf<String, Any?>(
            "type" to "hysteria",
            "tag" to "proxy",
            "server" to server,
            "server_port" to port,
            "auth_str" to auth
        )
        params["protocol"]?.takeIf { it.isNotEmpty() }?.let { singbox["protocol"] = it }
        speedMbps(params["upmbps"] ?: params["up_mbps"] ?: params["up"])?.let { singbox["up_mbps"] = it }
        speedMbps(params["downmbps"] ?: params["down_mbps"] ?: params["down"])?.let { singbox["down_mbps"] = it }

        val tls = mutableMapOf<String, Any?>("enabled" to true)
        tls["server_name"] = params["sni"] ?: params["peer"] ?: params["server_name"] ?: params["servername"] ?: server
        if (tlsInsecure(params)) tls["insecure"] = true
        params["alpn"]?.takeIf { it.isNotEmpty() }?.let {
            tls["alpn"] = it.split(",").map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
        }
        certificatePublicKeyPins(params).takeIf { it.isNotEmpty() }?.let {
            tls["certificate_public_key_sha256"] = it
        }
        singbox["tls"] = tls

        hysteriaObfs(params)?.let { (obfsType, obfsPassword) ->
            // Hysteria v1 expects the obfuscation password as a plain string.
            singbox["obfs"] = obfsPassword.ifEmpty { obfsType }
        }

        val outbound = mapOf<String, Any?>(
            "protocol" to "hysteria",
            "singbox" to singbox
        )

        val name = cleanName(fragment, "hysteria-$server:$port")
        return ParsedNode(name = name, scheme = "hysteria", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseHysteria2(link: String): ParsedNode {
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val params = parseQueryParams(uri.rawQuery)
        val auth = userInfoOf(uri).orEmpty().ifEmpty {
            params["auth"] ?: params["auth_str"] ?: params["authstr"] ?: params["password"] ?: ""
        }
        val server = uri.host ?: throw LinkParseError("Invalid Hysteria2 link: missing host")
        val port = if (uri.port > 0) uri.port else 443

        val sni = params["sni"] ?: params["peer"] ?: params["server_name"] ?: params["servername"] ?: server
        val insecure = tlsInsecure(params)

        val tls = mutableMapOf<String, Any?>(
            "enabled" to true,
            "server_name" to sni,
            "insecure" to insecure
        )
        certificatePublicKeyPins(params).takeIf { it.isNotEmpty() }?.let {
            tls["certificate_public_key_sha256"] = it
        }
        val singbox = mutableMapOf<String, Any?>(
            "type" to "hysteria2",
            "server" to server,
            "server_port" to port,
            "password" to auth,
            "tls" to tls
        )

        hysteriaObfs(params)?.let { (obfsType, obfsPassword) ->
            val obfs = mutableMapOf<String, Any?>("type" to obfsType.ifEmpty { "salamander" })
            if (obfsPassword.isNotEmpty()) obfs["password"] = obfsPassword
            singbox["obfs"] = obfs
        }

        val outbound = mapOf<String, Any?>(
            "protocol" to "hysteria2",
            "singbox" to singbox
        )

        val name = cleanName(fragment, "hy2-$server:$port")
        return ParsedNode(name = name, scheme = "hysteria2", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseTuic(link: String): ParsedNode {
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val userInfo = userInfoOf(uri) ?: ""
        val uuid = userInfo.substringBefore(":")
        val password = userInfo.substringAfter(":", "")

        val server = uri.host ?: throw LinkParseError("Invalid TUIC link: missing host")
        val port = if (uri.port > 0) uri.port else 8443
        val params = parseQueryParams(uri.rawQuery)
        if (uuid.isEmpty()) throw LinkParseError("tuic link must contain server and uuid")

        val sni = params["sni"] ?: params["peer"] ?: params["server_name"] ?: params["servername"] ?: server
        val congestionControl = params["congestion_control"] ?: params["congestion"] ?: params["cc"] ?: "cubic"
        val udpRelayMode = params["udp_relay_mode"] ?: "native"
        val alpnStr = params["alpn"] ?: "h3"
        val alpn = alpnStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }

        val tls = mutableMapOf<String, Any?>(
            "enabled" to true,
            "server_name" to sni,
            "alpn" to alpn
        )
        if (tlsInsecure(params)) {
            tls["insecure"] = true
        }
        certificatePublicKeyPins(params).takeIf { it.isNotEmpty() }?.let {
            tls["certificate_public_key_sha256"] = it
        }

        val singbox = mutableMapOf<String, Any?>(
            "type" to "tuic",
            "server" to server,
            "server_port" to port,
            "uuid" to uuid,
            "password" to password,
            "congestion_control" to congestionControl,
            "udp_relay_mode" to udpRelayMode,
            "tls" to tls
        )
        if (toBool(params["zero_rtt_handshake"] ?: params["zero_rtt"] ?: params["reduce_rtt"])) {
            singbox["zero_rtt_handshake"] = true
        }

        val outbound = mapOf<String, Any?>(
            "protocol" to "tuic",
            "singbox" to singbox
        )

        val name = cleanName(fragment, "tuic-$server:$port")
        return ParsedNode(name = name, scheme = "tuic", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseAnyTls(link: String): ParsedNode {
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val params = parseQueryParams(uri.rawQuery)
        val password = (userInfoOf(uri) ?: "").ifEmpty { params["password"] ?: "" }
        val server = uri.host ?: throw LinkParseError("Invalid AnyTLS link: missing host")
        val port = if (uri.port > 0) uri.port else 443
        if (password.isEmpty()) throw LinkParseError("anytls link must contain server and password")

        val tls = mutableMapOf<String, Any?>(
            "enabled" to true,
            "server_name" to (params["sni"] ?: params["peer"] ?: params["server_name"] ?: params["servername"] ?: server)
        )
        if (tlsInsecure(params)) {
            tls["insecure"] = true
        }
        certificatePublicKeyPins(params).takeIf { it.isNotEmpty() }?.let {
            tls["certificate_public_key_sha256"] = it
        }
        params["alpn"]?.takeIf { it.isNotEmpty() }?.let {
            tls["alpn"] = it.split(",").map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
        }

        val singbox = mutableMapOf<String, Any?>(
            "type" to "anytls",
            "tag" to "proxy",
            "server" to server,
            "server_port" to port,
            "password" to password,
            "tls" to tls
        )
        (params["idle_session_check_interval"] ?: params["idle-session-check-interval"])?.takeIf { it.isNotEmpty() }?.let {
            singbox["idle_session_check_interval"] = it
        }
        (params["idle_session_timeout"] ?: params["idle-session-timeout"])?.takeIf { it.isNotEmpty() }?.let {
            singbox["idle_session_timeout"] = it
        }
        (params["min_idle_session"] ?: params["min-idle-session"])?.toIntOrNull()?.let {
            singbox["min_idle_session"] = it
        }

        val outbound = mapOf<String, Any?>("protocol" to "anytls", "singbox" to singbox)
        val name = cleanName(fragment, "anytls-$server:$port")
        return ParsedNode(name = name, scheme = "anytls", server = server, port = port, link = link, outbound = outbound)
    }

    /** Bandwidth values often carry a unit suffix ("200 Mbps"), as in Clash YAML. */
    private fun speedMbps(value: String?): Int? = value?.filter { it.isDigit() }?.toIntOrNull()

    /**
     * Shared hysteria v1/v2 obfuscation parameters (parity with desktop
     * _apply_hysteria_obfs): a link may carry only the password, only the type,
     * or disable obfuscation with `none`.
     */
    private fun hysteriaObfs(params: Map<String, String>): Pair<String, String>? {
        val obfsType = params["obfs"] ?: params["obfs_type"] ?: params["obfstype"] ?: ""
        val obfsPassword = params["obfs-password"] ?: params["obfs_password"] ?: params["obfspassword"]
            ?: params["obfs-pass"] ?: params["obfspass"] ?: ""
        if (obfsType.isEmpty() && obfsPassword.isEmpty()) return null
        if (obfsType.equals("none", ignoreCase = true)) return null
        return Pair(obfsType, obfsPassword)
    }

    // Conflicting aliases must not silently disable certificate verification.
    private fun tlsInsecure(params: Map<String, *>): Boolean {
        val supplied = listOf("insecure", "allowinsecure", "allow_insecure").mapNotNull { params[it] }
        return supplied.isNotEmpty() && supplied.all { toBool(it) }
    }

    private fun toBool(value: Any?): Boolean = when (value) {
        is Boolean -> value
        is Number -> value.toInt() != 0
        is String -> value.trim().lowercase() in setOf("1", "true", "yes", "on")
        else -> false
    }

    private fun clashStringList(value: Any?): List<String> = when (value) {
        is List<*> -> value.mapNotNull { it?.toString()?.trim() }.filter { it.isNotEmpty() }
        null -> emptyList()
        else -> value.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun clashCertificatePins(map: Map<String, Any?>): List<String> =
        clashStringList(
            map["certificate-public-key-sha256"]
                ?: map["certificate_public_key_sha256"]
                ?: map["pin-sha256"]
                ?: map["pinSHA256"]
        )

    private fun clashTransportParams(map: Map<String, Any?>, params: MutableMap<String, String>) {
        val network = (map["network"] ?: map["net"])?.toString()?.lowercase()
            ?.takeIf(String::isNotBlank) ?: params["type"] ?: "tcp"
        params["type"] = network

        when (network) {
            "ws" -> {
                val opts = map["ws-opts"] as? Map<*, *> ?: map["ws_opts"] as? Map<*, *>
                opts?.get("path")?.toString()?.let { params["path"] = it }
                val headers = opts?.get("headers") as? Map<*, *>
                headers?.entries?.firstOrNull { it.key?.toString()?.equals("host", true) == true }
                    ?.value?.toString()?.let { params["host"] = it }
            }
            "grpc", "gun" -> {
                val opts = map["grpc-opts"] as? Map<*, *> ?: map["grpc_opts"] as? Map<*, *>
                (opts?.get("grpc-service-name") ?: opts?.get("service-name") ?: opts?.get("service_name"))
                    ?.toString()?.let { params["servicename"] = it }
                (opts?.get("authority") ?: opts?.get("grpc-authority") ?: opts?.get("grpc_authority")
                    ?: map["grpc-authority"] ?: map["grpc_authority"])
                    ?.toString()?.let { params["authority"] = it }
            }
            "h2", "http" -> {
                val opts = (map["h2-opts"] as? Map<*, *>)
                    ?: (map["h2_opts"] as? Map<*, *>)
                    ?: (map["http-opts"] as? Map<*, *>)
                    ?: (map["http_opts"] as? Map<*, *>)
                val path = when (val raw = opts?.get("path")) {
                    is List<*> -> raw.firstOrNull()?.toString()
                    else -> raw?.toString()
                }
                path?.let { params["path"] = it }
                clashStringList(opts?.get("host")).takeIf { it.isNotEmpty() }?.let {
                    params["host"] = it.joinToString(",")
                }
            }
        }
    }

    /**
     * Keep every Clash transport option in the persisted Xray-shaped object.
     * SingboxConfigBuilder currently consumes the common subset; retaining the
     * rest prevents a save/reload from destroying it and lets newer builders use
     * the exact extended fields without a database migration.
     */
    private fun enrichClashStreamSettings(
        source: Map<String, Any?>,
        map: Map<String, Any?>
    ): Map<String, Any?> {
        val result = source.toMutableMap()
        when (source["network"]?.toString()?.lowercase()) {
            "ws" -> {
                val opts = map["ws-opts"] as? Map<*, *> ?: map["ws_opts"] as? Map<*, *>
                if (opts != null) {
                    @Suppress("UNCHECKED_CAST")
                    val ws = ((result["wsSettings"] as? Map<String, Any?>) ?: emptyMap()).toMutableMap()
                    (opts["headers"] as? Map<*, *>)?.let { ws["headers"] = it }
                    (opts["max-early-data"] ?: opts["max_early_data"] ?: map["max-early-data"])
                        ?.toString()?.toIntOrNull()?.let { ws["ed"] = it }
                    (opts["early-data-header-name"] ?: opts["early_data_header_name"])
                        ?.toString()?.takeIf(String::isNotBlank)?.let { ws["earlyDataHeaderName"] = it }
                    result["wsSettings"] = ws
                }
            }
            "grpc" -> {
                val opts = map["grpc-opts"] as? Map<*, *> ?: map["grpc_opts"] as? Map<*, *>
                if (opts != null) {
                    @Suppress("UNCHECKED_CAST")
                    val grpc = ((result["grpcSettings"] as? Map<String, Any?>) ?: emptyMap()).toMutableMap()
                    (opts["authority"] ?: opts["grpc-authority"] ?: opts["grpc_authority"]
                        ?: map["grpc-authority"] ?: map["grpc_authority"])
                        ?.toString()?.takeIf(String::isNotBlank)?.let { grpc["authority"] = it }
                    (opts["idle-timeout"] ?: opts["idle_timeout"])?.let { grpc["idleTimeout"] = it }
                    (opts["ping-timeout"] ?: opts["ping_timeout"])?.let { grpc["pingTimeout"] = it }
                    (opts["permit-without-stream"] ?: opts["permit_without_stream"])
                        ?.let { grpc["permitWithoutStream"] = toBool(it) }
                    result["grpcSettings"] = grpc
                }
            }
            "http", "h2" -> {
                val opts = (map["h2-opts"] as? Map<*, *>)
                    ?: (map["h2_opts"] as? Map<*, *>)
                    ?: (map["http-opts"] as? Map<*, *>)
                    ?: (map["http_opts"] as? Map<*, *>)
                if (opts != null) {
                    @Suppress("UNCHECKED_CAST")
                    val http = ((result["httpSettings"] as? Map<String, Any?>) ?: emptyMap()).toMutableMap()
                    (opts["headers"] as? Map<*, *>)?.let { http["headers"] = it }
                    opts["method"]?.toString()?.takeIf(String::isNotBlank)?.let { http["method"] = it }
                    result["httpSettings"] = http
                }
            }
            "quic" -> result["quicSettings"] = emptyMap<String, Any?>()
        }
        return result
    }

    private fun parseNaiveLink(link: String, sourceScheme: String = ""): ParsedNode {
        // NaiveProxy URI (parity with desktop Lumen): the explicit naive*
        // schemes are Lumen aliases; https/quic arrive from NaiveProxy JSON
        // configs via sourceScheme so plain https:// links stay HTTP proxies.
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val scheme = (sourceScheme.ifEmpty { uri.scheme ?: "" }).trim().lowercase()
        if (scheme !in setOf("naive", "naive+https", "naive+quic", "https", "quic")) {
            throw LinkParseError("unsupported NaiveProxy transport: ${scheme.ifEmpty { "unknown" }}")
        }
        val server = uri.host ?: throw LinkParseError("NaiveProxy URI must contain server and port")
        val port = if (uri.port > 0) uri.port else 443
        val params = parseQueryParams(uri.rawQuery)
        val userInfo = userInfoOf(uri) ?: ""
        val username = userInfo.substringBefore(":", userInfo)
        val password = if (userInfo.contains(":")) userInfo.substringAfter(":") else ""
        val serverName = params["sni"] ?: params["server_name"] ?: params["servername"] ?: server
        val isQuic = scheme in setOf("quic", "naive+quic") || toBool(params["quic"])

        val singbox = mutableMapOf<String, Any?>(
            "type" to "naive",
            "tag" to "proxy",
            "server" to server,
            "server_port" to port,
            "username" to username,
            "password" to password,
            "quic" to isQuic,
            "tls" to mapOf("enabled" to true, "server_name" to serverName)
        )
        (params["insecure_concurrency"] ?: params["insecure-concurrency"])?.toIntOrNull()?.let {
            singbox["insecure_concurrency"] = it
        }
        (params["quic_congestion_control"] ?: params["quic-congestion-control"])?.takeIf { it.isNotEmpty() }?.let {
            singbox["quic_congestion_control"] = it
        }
        (params["udp_over_tcp"] ?: params["udp-over-tcp"])?.takeIf { it.isNotEmpty() }?.let { raw ->
            val trimmedRaw = raw.trim()
            if (trimmedRaw.startsWith("{")) {
                try {
                    singbox["udp_over_tcp"] = jsonToMap(JSONObject(trimmedRaw))
                } catch (e: Exception) {
                    singbox["udp_over_tcp"] = toBool(trimmedRaw)
                }
            } else {
                singbox["udp_over_tcp"] = toBool(trimmedRaw)
            }
        }
        (params["extra_headers"] ?: params["extra-headers"])?.takeIf { it.isNotEmpty() }?.let { raw ->
            val headers = try {
                JSONObject(raw.trim())
            } catch (e: Exception) {
                throw LinkParseError("NaiveProxy extra_headers must be a JSON object")
            }
            singbox["extra_headers"] = jsonToMap(headers)
        }

        val outbound = mapOf<String, Any?>("protocol" to "naive", "singbox" to singbox)
        val name = cleanName(fragment, "naive-$server:$port")
        return ParsedNode(name = name, scheme = "naive", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseMieru(link: String): ParsedNode {
        val uri = safeCreateUri(link)
        val fragment = extractFragment(link)
        val params = parseQueryParams(uri.rawQuery)
        val server = uri.host ?: params["server"] ?: params["address"] ?: params["host"] ?: ""
        val scalarPort = if (uri.port > 0) {
            uri.port
        } else {
            (params["port"] ?: params["server_port"])?.toIntOrNull()
        }
        val serverPorts = (params["server_ports"] ?: params["server-ports"] ?: params["ports"])
            ?.split(",")
            ?.map(String::trim)
            ?.filter(String::isNotEmpty)
            .orEmpty()
        // Room keeps one integer for display/filtering, while the exact extended
        // outbound retains the complete range list. Use the first range boundary
        // as a representative instead of rejecting a valid range-only profile.
        val port = scalarPort ?: representativePort(serverPorts) ?: 0
        val userInfo = userInfoOf(uri) ?: ""
        val username = userInfo.substringBefore(":", userInfo).ifEmpty { params["username"] ?: params["user"] ?: "" }
        val password = (if (userInfo.contains(":")) userInfo.substringAfter(":") else "")
            .ifEmpty { params["password"] ?: params["pass"] ?: "" }
        if (server.isEmpty() || username.isEmpty() || password.isEmpty() || (scalarPort == null && serverPorts.isEmpty())) {
            throw LinkParseError("mieru link must contain server, port/server_ports, username and password")
        }

        val singbox = mutableMapOf<String, Any?>(
            "type" to "mieru",
            "tag" to "proxy",
            "server" to server,
            "transport" to ((params["transport"]?.takeIf { it.isNotEmpty() } ?: "TCP").uppercase()),
            "username" to username,
            "password" to password
        )
        scalarPort?.takeIf { it in 1..65535 }?.let { singbox["server_port"] = it }
        if (serverPorts.isNotEmpty()) singbox["server_ports"] = serverPorts
        (params["multiplexing"] ?: params["mux"])?.takeIf { it.isNotEmpty() }?.let { singbox["multiplexing"] = it }
        (params["traffic_pattern"] ?: params["trafficpattern"])?.takeIf { it.isNotEmpty() }?.let {
            singbox["traffic_pattern"] = it
        }

        val outbound = mapOf<String, Any?>("protocol" to "mieru", "singbox" to singbox)
        val name = cleanName(fragment, "mieru-$server:${if (port > 0) port.toString() else "range"}")
        return ParsedNode(name = name, scheme = "mieru", server = server, port = port, link = link, outbound = outbound)
    }

    private fun representativePort(ranges: List<String>): Int? =
        ranges.asSequence()
            .mapNotNull { range ->
                range.substringBefore('-').trim().toIntOrNull()?.takeIf { it in 1..65535 }
            }
            .firstOrNull()

    private fun clashSpeedMbps(value: Any?): Int? = speedMbps(value?.toString())

    private fun durationSeconds(value: Any?): String {
        val text = value?.toString()?.trim().orEmpty()
        return if (text.toDoubleOrNull() != null) "${text}s" else text
    }

    private fun parseMasque(link: String): ParsedNode {
        // masque://<auth_token>@<profile_id>?... — parsed manually because the
        // auth token may contain base64 characters java.net.URI rejects.
        val trimmed = link.trim()
        val schemeSep = trimmed.indexOf("://")
        if (schemeSep <= 0) throw LinkParseError("Invalid MASQUE URL")
        val fragmentIdx = trimmed.indexOf('#')
        val withoutFragment = if (fragmentIdx != -1) trimmed.substring(0, fragmentIdx) else trimmed
        val afterScheme = withoutFragment.substring(schemeSep + 3)
        val queryIdx = afterScheme.indexOf('?')
        val authority = (if (queryIdx != -1) afterScheme.substring(0, queryIdx) else afterScheme)
        val rawQuery = if (queryIdx != -1) afterScheme.substring(queryIdx + 1) else null
        val params = parseQueryParams(rawQuery)

        val atIdx = authority.lastIndexOf('@')
        val authToken = (if (atIdx > 0) percentDecodeKeepPlus(authority.substring(0, atIdx)) else "")
            .ifEmpty { params["auth_token"] ?: params["token"] ?: "" }
        val profileId = percentDecodeKeepPlus((if (atIdx >= 0) authority.substring(atIdx + 1) else authority).substringBefore('/').trim())
            .ifEmpty { params["id"] ?: params["profile_id"] ?: "" }

        val profile = mutableMapOf<String, Any?>("detour" to "direct")
        if (profileId.isNotEmpty()) profile["id"] = profileId
        if (authToken.isNotEmpty()) profile["auth_token"] = authToken

        val singbox = mutableMapOf<String, Any?>(
            "type" to "masque",
            "tag" to "proxy",
            "system" to toBool(params["system"]),
            "name" to (params["name"]?.takeIf { it.isNotEmpty() } ?: "masque0"),
            "use_http2" to (toBool(params["use_http2"]) || toBool(params["http2"])),
            "use_ipv6" to (toBool(params["use_ipv6"]) || toBool(params["ipv6"])),
            "profile" to profile,
            "udp_timeout" to ((params["udp_timeout"] ?: params["udptimeout"])?.takeIf { it.isNotEmpty() } ?: "5m0s"),
            "udp_keepalive_period" to ((params["udp_keepalive_period"] ?: params["udpkeepaliveperiod"])?.takeIf { it.isNotEmpty() } ?: "30s"),
            "reconnect_delay" to ((params["reconnect_delay"] ?: params["reconnectdelay"])?.takeIf { it.isNotEmpty() } ?: "5s"),
            "congestion_controller" to ((params["congestion_controller"] ?: params["congestioncontroller"])?.takeIf { it.isNotEmpty() } ?: "bbr")
        )
        (params["allowed_ips"] ?: params["allowedips"])?.takeIf { it.isNotEmpty() }?.let {
            singbox["allowed_ips"] = it.split(",").map { s -> s.trim() }.filter { s -> s.isNotEmpty() }
        }
        val serverName = params["sni"] ?: params["server_name"] ?: params["servername"] ?: ""
        val insecure = params["insecure"] ?: params["allowinsecure"] ?: params["allow_insecure"] ?: ""
        if (serverName.isNotEmpty() || insecure.isNotEmpty()) {
            val tls = mutableMapOf<String, Any?>()
            if (serverName.isNotEmpty()) tls["server_name"] = serverName
            if (insecure.isNotEmpty()) tls["insecure"] = tlsInsecure(params)
            singbox["tls"] = tls
        }

        val outbound = mapOf<String, Any?>("protocol" to "masque", "singbox" to singbox)
        val fragment = if (fragmentIdx != -1) trimmed.substring(fragmentIdx + 1) else null
        val name = cleanName(fragment, "MASQUE")
        return ParsedNode(name = name, scheme = "masque", server = profileId, port = 0, link = link, outbound = outbound)
    }

    private fun parseSocks(link: String): ParsedNode {
        val uri = try { URI(link) } catch (e: Exception) { throw LinkParseError("Invalid SOCKS URL: ${e.message}") }
        val server = uri.host ?: throw LinkParseError("Invalid SOCKS link: missing host")
        val port = if (uri.port > 0) uri.port else 1080
        val userInfo = userInfoOf(uri) ?: ""

        val serverMap = mutableMapOf<String, Any?>("address" to server, "port" to port)
        if (userInfo.contains(":")) {
            val user = mutableMapOf<String, Any?>(
                "user" to userInfo.substringBefore(":"),
                "pass" to userInfo.substringAfter(":")
            )
            serverMap["users"] = listOf(user)
        }

        val outbound = mapOf<String, Any?>(
            "protocol" to "socks",
            "settings" to mapOf("servers" to listOf(serverMap))
        )
        val name = cleanName(uri.rawFragment, "socks-$server:$port")
        return ParsedNode(name = name, scheme = "socks", server = server, port = port, link = link, outbound = outbound)
    }

    private fun parseHttp(link: String): ParsedNode {
        val uri = try { URI(link) } catch (e: Exception) { throw LinkParseError("Invalid HTTP URL: ${e.message}") }
        val server = uri.host ?: throw LinkParseError("Invalid HTTP link: missing host")
        val port = if (uri.port > 0) uri.port else 8080
        val userInfo = userInfoOf(uri) ?: ""

        val serverMap = mutableMapOf<String, Any?>("address" to server, "port" to port)
        if (userInfo.contains(":")) {
            val user = mutableMapOf<String, Any?>(
                "user" to userInfo.substringBefore(":"),
                "pass" to userInfo.substringAfter(":")
            )
            serverMap["users"] = listOf(user)
        }

        val outbound = mutableMapOf<String, Any?>(
            "protocol" to "http",
            "settings" to mapOf("servers" to listOf(serverMap))
        )
        if (uri.scheme.equals("https", ignoreCase = true)) {
            outbound["tls"] = mapOf("enabled" to true, "server_name" to server)
        }
        val name = cleanName(uri.rawFragment, "http-$server:$port")
        return ParsedNode(name = name, scheme = "http", server = server, port = port, link = link, outbound = outbound)
    }

    /**
     * Splits an authority into host and port. Handles IPv6 literals and the
     * trailing '/' SIP002 puts before the plugin query; an explicit port that is
     * not a valid 1..65535 number is an error instead of a silent default.
     */
    private fun splitHostPort(hostPort: String, defaultPort: Int, label: String): Pair<String, Int> {
        val trimmed = hostPort.trim()
        val host: String
        val portToken: String
        if (trimmed.startsWith("[")) {
            val close = trimmed.indexOf(']')
            if (close <= 0) throw LinkParseError("Invalid $label link: missing host")
            host = trimmed.substring(1, close)
            val rest = trimmed.substring(close + 1).substringBefore('/')
            if (rest.isNotEmpty() && !rest.startsWith(":")) {
                throw LinkParseError("Invalid $label link: invalid host or port")
            }
            portToken = if (rest.startsWith(":")) rest.substring(1) else ""
        } else {
            val authority = trimmed.substringBefore('/')
            if (authority.count { it == ':' } > 1) {
                throw LinkParseError("Invalid $label link: IPv6 hosts must be enclosed in brackets")
            }
            val colonIdx = authority.lastIndexOf(':')
            if (colonIdx > 0) {
                host = authority.substring(0, colonIdx)
                portToken = authority.substring(colonIdx + 1)
            } else {
                host = authority
                portToken = ""
            }
        }
        if (host.isBlank()) throw LinkParseError("Invalid $label link: missing host")
        if (portToken.isEmpty()) return Pair(host, defaultPort)
        val port = portToken.toIntOrNull()?.takeIf { it in 1..65535 }
            ?: throw LinkParseError("Invalid $label link: invalid port `$portToken`")
        return Pair(host, port)
    }

    // Percent-decodes a string WITHOUT treating '+' as a space (base64 keys contain '+').
    private fun percentDecodeKeepPlus(str: String): String {
        if (!str.contains('%')) return str
        return try {
            URLDecoder.decode(str.replace("+", "%2B"), "UTF-8")
        } catch (e: Exception) {
            str
        }
    }

    /** Coerces one AmneziaWG option to the type the extended core expects. */
    private fun amneziaValue(key: String, value: Any?): Any? {
        val text = value?.toString()?.trim() ?: return null
        if (text.isEmpty()) return null
        return when (key) {
            // i1..i5/j1..j3 are packet definitions, and a uint32 range accepts the
            // string form too, so h1..h4 never risk an Int overflow.
            in AMNEZIA_STR_KEYS, in AMNEZIA_RANGE_KEYS -> text
            else -> text.toIntOrNull() ?: text
        }
    }

    // wg-quick/AmneziaWG exports keep the profile name in a leading comment
    // ("# Name = AWG 🇳🇱 Titan AWG 2.0"), the only label such a file carries.
    private val WG_CONF_NAME_REGEX = Regex("^[#;]\\s*(?:name|title)\\s*[:=]\\s*(.+)$", RegexOption.IGNORE_CASE)

    /** Clash keeps the AmneziaWG knobs in a nested block; providers vary on its spelling. */
    private fun clashAmneziaOptions(map: Map<String, Any?>): Map<*, *> =
        (map["amnezia-wg-option"] ?: map["amnezia_wg_option"] ?: map["amnezia"] ?: map["amnezia-options"])
            as? Map<*, *> ?: emptyMap<String, Any?>()

    private fun parseWireGuardLink(link: String): ParsedNode {
        // Parsed manually: WireGuard/AWG private keys are base64 and may contain
        // '/', '+' and '=' which java.net.URI rejects or corrupts in the userinfo
        // part (this caused "missing private key" for some AWG servers).
        val trimmed = link.trim()
        val schemeSep = trimmed.indexOf("://")
        if (schemeSep <= 0) throw LinkParseError("Invalid WireGuard URL")
        val fragmentIdx = trimmed.indexOf('#')
        val withoutFragment = if (fragmentIdx != -1) trimmed.substring(0, fragmentIdx) else trimmed
        val afterScheme = withoutFragment.substring(schemeSep + 3)
        val queryIdx = afterScheme.indexOf('?')
        val authority = (if (queryIdx != -1) afterScheme.substring(0, queryIdx) else afterScheme).substringBefore('/')
        val rawQuery = if (queryIdx != -1) afterScheme.substring(queryIdx + 1) else null

        val params = mutableMapOf<String, String>()
        rawQuery?.split("&")?.forEach { pair ->
            val eq = pair.indexOf('=')
            if (eq > 0) {
                params[percentDecodeKeepPlus(pair.substring(0, eq)).lowercase()] = percentDecodeKeepPlus(pair.substring(eq + 1))
            }
        }

        val atIdx = authority.lastIndexOf('@')
        var privateKey = if (atIdx > 0) percentDecodeKeepPlus(authority.substring(0, atIdx)) else ""
        if (privateKey.isBlank()) {
            privateKey = params["privatekey"] ?: params["private_key"] ?: params["private-key"]
                ?: params["secretkey"] ?: params["secret_key"] ?: params["secret-key"] ?: params["sk"] ?: ""
        }

        val hostPort = if (atIdx >= 0) authority.substring(atIdx + 1) else authority
        val (server, port) = splitHostPort(hostPort, 51820, "WireGuard")

        val publicKey = params["publickey"] ?: params["public_key"] ?: params["public-key"] ?: params["pk"] ?: ""
        val addressStr = params["ip"] ?: params["address"] ?: ""
        val address = addressStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (privateKey.isBlank() || publicKey.isBlank() || address.isEmpty()) {
            throw LinkParseError("wireguard link must contain a private key, a peer public key and an interface address")
        }

        val amneziaMap = amneziaOptionsFrom(params)
        val isAwg = link.lowercase().startsWith("awg://") || link.lowercase().startsWith("amneziawg://") || amneziaMap.isNotEmpty()

        // Optional peer/interface parameters: dropping them silently broke
        // split-tunnel AllowedIPs, PSK peers and Warp-like reserved bytes.
        val allowedIps = (params["allowedips"] ?: params["allowed_ips"] ?: params["allowed-ips"] ?: "")
            .split(",").map { it.trim() }.filter { it.isNotEmpty() }
            .ifEmpty { listOf("0.0.0.0/0", "::/0") }
        val preSharedKey = (params["presharedkey"] ?: params["pre_shared_key"] ?: params["pre-shared-key"] ?: params["psk"] ?: "").trim()
        val keepalive = (params["persistentkeepalive"] ?: params["persistent_keepalive"] ?: params["keepalive"])?.trim()?.toIntOrNull()
        val reservedParam = (params["reserved"] ?: "").trim()
        val mtuParam = params["mtu"]?.trim()?.toIntOrNull()
        val dnsServers = (params["dns"] ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }

        val peer = mutableMapOf<String, Any?>(
            "public_key" to publicKey,
            "server" to server,
            "server_port" to port,
            "allowed_ips" to allowedIps
        )
        if (preSharedKey.isNotEmpty()) peer["pre_shared_key"] = preSharedKey
        if (keepalive != null && keepalive > 0) peer["persistent_keepalive_interval"] = keepalive
        if (reservedParam.isNotEmpty()) peer["reserved"] = reservedParam

        val singbox = mutableMapOf<String, Any?>(
            "type" to if (isAwg) "awg" else "wireguard",
            "server" to server,
            "server_port" to port,
            "private_key" to privateKey,
            "address" to address,
            "peers" to listOf(peer)
        )
        if (mtuParam != null && mtuParam > 0) singbox["mtu"] = mtuParam
        if (amneziaMap.isNotEmpty()) {
            singbox["amnezia"] = amneziaMap
        }

        val outbound = mutableMapOf<String, Any?>(
            "protocol" to if (isAwg) "awg" else "wireguard",
            "singbox" to singbox
        )
        if (dnsServers.isNotEmpty()) outbound["_dns"] = dnsServers
        val scheme = if (isAwg) "awg" else "wireguard"
        val fragment = if (fragmentIdx != -1) trimmed.substring(fragmentIdx + 1) else null
        // Some providers label the endpoint with a query parameter instead of a
        // fragment; either way the full provider name must survive the import.
        val label = fragment?.takeIf { it.isNotBlank() } ?: params["name"] ?: params["remarks"]
        val name = cleanName(label, if (isAwg) "awg-$server:$port" else "wg-$server:$port")
        return ParsedNode(name = name, scheme = scheme, server = server, port = port, link = link, outbound = outbound)
    }

    fun parseWireGuardConfig(text: String): ParsedNode {
        var privateKey = ""
        val addressList = mutableListOf<String>()
        var publicKey = ""
        var endpointHost = ""
        var endpointPort = 51820
        var currentSection = ""
        // [Interface]/[Peer] extras that used to be dropped by this parser.
        var mtu = 0
        val dnsList = mutableListOf<String>()
        var preSharedKey = ""
        var keepalive = 0
        var reserved = ""
        val allowedIpsList = mutableListOf<String>()
        // The provider name is the only human readable label a .conf carries.
        var profileName = ""

        val amneziaMap = mutableMapOf<String, Any?>()

        for (rawLine in text.lines()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue
            if (line.startsWith("#") || line.startsWith(";")) {
                if (profileName.isEmpty()) {
                    WG_CONF_NAME_REGEX.find(line)?.groupValues?.get(1)?.trim()
                        ?.takeIf { it.isNotEmpty() }?.let { profileName = it }
                }
                continue
            }
            if (line.startsWith("[") && line.endsWith("]")) {
                currentSection = line.substring(1, line.length - 1).trim().lowercase()
                continue
            }

            val parts = line.split("=", limit = 2)
            if (parts.size != 2) continue
            val key = parts[0].trim().lowercase()
            val value = parts[1].trim()

            if (currentSection == "interface") {
                when (key) {
                    "privatekey" -> privateKey = value
                    "address" -> addressList.addAll(value.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                    "mtu" -> mtu = value.toIntOrNull() ?: 0
                    "dns" -> dnsList.addAll(value.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                    "name" -> if (value.isNotEmpty()) profileName = value
                    else -> canonicalAmneziaKey(key)?.let { canonical ->
                        amneziaValue(canonical, value)?.let { amneziaMap[canonical] = it }
                    }
                }
            } else if (currentSection == "peer") {
                when (key) {
                    "publickey" -> publicKey = value
                    "presharedkey" -> preSharedKey = value
                    "persistentkeepalive" -> keepalive = value.toIntOrNull() ?: 0
                    "reserved" -> reserved = value
                    "allowedips" -> allowedIpsList.addAll(value.split(",").map { it.trim() }.filter { it.isNotEmpty() })
                    "endpoint" -> {
                        val hostPort = value.split(":")
                        if (hostPort.size >= 2) {
                            endpointHost = hostPort.dropLast(1).joinToString(":")
                            endpointPort = hostPort.last().toIntOrNull() ?: 51820
                        } else {
                            endpointHost = value
                        }
                    }
                }
            }
        }

        if (endpointHost.isEmpty()) {
            throw LinkParseError("WireGuard config missing Endpoint in [Peer]")
        }

        val isAwg = amneziaMap.isNotEmpty()
        val isWarp = isCloudflareWarpProfile(addressList, publicKey, endpointHost)
        val scheme = if (isAwg) "awg" else "wireguard"
        val peer = mutableMapOf<String, Any?>(
            "public_key" to publicKey,
            "server" to endpointHost,
            "server_port" to endpointPort,
            "allowed_ips" to allowedIpsList.ifEmpty { listOf("0.0.0.0/0", "::/0") }
        )
        if (preSharedKey.isNotEmpty()) peer["pre_shared_key"] = preSharedKey
        if (keepalive > 0) peer["persistent_keepalive_interval"] = keepalive
        if (reserved.isNotEmpty()) peer["reserved"] = reserved

        val singbox = mutableMapOf<String, Any?>(
            "type" to scheme,
            "server" to endpointHost,
            "server_port" to endpointPort,
            "private_key" to privateKey,
            "address" to addressList,
            "peers" to listOf(peer)
        )
        if (mtu > 0) singbox["mtu"] = mtu

        if (amneziaMap.isNotEmpty()) {
            singbox["amnezia"] = amneziaMap
        }

        val outbound = mutableMapOf<String, Any?>(
            "protocol" to scheme,
            "singbox" to singbox
        )
        if (dnsList.isNotEmpty()) outbound["_dns"] = dnsList
        if (isWarp) {
            outbound["warp"] = true
            outbound["display_protocol"] = if (isAwg) "AWG/WARP" else "WireGuard/WARP"
        }

        val name = when {
            // A provider name always wins: only a nameless config may fall back to
            // the technical label the UI later replaces with a location.
            profileName.isNotEmpty() -> profileName
            isWarp -> "WARP"
            isAwg -> "AmneziaWG-$endpointHost"
            else -> "WireGuard-$endpointHost"
        }
        return ParsedNode(name = name, scheme = scheme, server = endpointHost, port = endpointPort, link = text, outbound = outbound)
    }

    private val OPENVPN_INLINE_BLOCK_REGEX = Regex(
        "(?ims)^[ \\t]*<(ca|cert|key|tls-auth|tls-crypt|tls-crypt-v2|auth-user-pass|askpass)>[ \\t]*\\r?\\n(.*?)^[ \\t]*</\\1>[ \\t]*$"
    )
    private val OPENVPN_CONNECTION_BLOCK_REGEX = Regex(
        "(?ims)^[ \\t]*<connection>[ \\t]*\\r?\\n(.*?)^[ \\t]*</connection>[ \\t]*$"
    )
    // `askpass` is supported as long as the passphrase itself is inline: an
    // encrypted <key> is useless without it and many providers ship one.
    private val OPENVPN_UNSAFE_DIRECTIVES = setOf(
        "http-proxy-user-pass", "pkcs12", "secret"
    )

    /**
     * Passphrase of an encrypted private key. It arrives either as an inline
     * `<askpass>` block or as the `# lumen-key-password <pass>` comment the node
     * editor writes, so a profile stays portable for other clients.
     */
    private fun openVpnKeyPassword(text: String, inline: Map<String, String>): String {
        val inlinePass = (inline["askpass"] ?: "").lines()
            .map { it.trim() }
            .firstOrNull { it.isNotEmpty() }
            .orEmpty()
        if (inlinePass.isNotEmpty()) return inlinePass
        return text.lines()
            .map { it.trim() }
            .lastOrNull { it.startsWith("# lumen-key-password ") }
            ?.removePrefix("# lumen-key-password ")
            ?.trim()
            .orEmpty()
    }

    /** "Use proxy" values Lumen understands; obfs variants are terminated in-app. */
    private val OPENVPN_OBFS_PROXIES = setOf("obfs3", "obfs2", "obfs2-legacy")

    /**
     * Reads the "Use proxy" setting of an OpenVPN profile: the standard
     * `http-proxy` / `socks-proxy` directives plus the Lumen comments
     * `# lumen-proxy <obfs> <host> <port>` and `# lumen-proxy-auth <user> <pass>`.
     */
    private fun parseOpenVpnProxy(
        text: String,
        byKey: Map<String, List<List<String>>>
    ): Map<String, Any?>? {
        fun comment(prefix: String): List<String> = text.lines()
            .map { it.trim() }
            .lastOrNull { it.startsWith("# $prefix ") }
            ?.removePrefix("# $prefix ")
            ?.split(Regex("\\s+"))
            ?.filter { it.isNotEmpty() }
            .orEmpty()

        val obfs = comment("lumen-proxy")
        val auth = comment("lumen-proxy-auth")
        val http = byKey["http-proxy"]?.lastOrNull().orEmpty()
        val socks = byKey["socks-proxy"]?.lastOrNull().orEmpty()
        val type = when {
            obfs.firstOrNull() in OPENVPN_OBFS_PROXIES -> obfs[0]
            http.isNotEmpty() -> "http"
            socks.isNotEmpty() -> "socks"
            else -> return null
        }
        val endpoint = when (type) {
            "http" -> http
            "socks" -> socks
            else -> obfs.drop(1)
        }
        val host = endpoint.getOrNull(0)?.trim().orEmpty()
        if (host.isEmpty()) throw LinkParseError("OpenVPN proxy `$type` is missing a server address")
        val port = endpoint.getOrNull(1)?.trim()?.toIntOrNull()?.takeIf { it in 1..65535 }
            ?: throw LinkParseError("invalid OpenVPN proxy port for `$type`")
        if (type in setOf("http", "socks") && endpoint.size > 2) {
            throw LinkParseError(
                "OpenVPN `$type-proxy` credential files are not supported on Android; " +
                    "enter proxy credentials in the node editor"
            )
        }
        return buildMap {
            put("type", type)
            put("server", host)
            put("server_port", port)
            auth.getOrNull(0)?.let { put("username", it) }
            auth.getOrNull(1)?.let { put("password", it) }
        }
    }

    /**
     * True when the profile logs the user in instead of relying on certificates
     * alone. `auth-user-pass` arrives either as a bare directive or as an inline
     * `<auth-user-pass>` block, and the inline blocks are stripped before the
     * directives are tokenized, so both spellings have to be looked for.
     * Certificate-only profiles carry neither and need no credentials.
     */
    fun openVpnRequiresUserAuth(text: String): Boolean {
        var inlineAuth = false
        val directivesText = OPENVPN_INLINE_BLOCK_REGEX.replace(text) { match ->
            val name = match.groupValues[1].lowercase()
            if (name == "auth-user-pass") inlineAuth = true
            ""
        }
        if (inlineAuth) return true
        val directives = directivesText.lines().mapNotNull { rawLine ->
            val line = rawLine.trim()
            if (line.isEmpty() || line.startsWith("#") || line.startsWith(";")) return@mapNotNull null
            runCatching { tokenizeOpenVpnLine(line) }.getOrNull()
                ?.firstOrNull()?.trimStart('-')?.trim()?.lowercase()
        }.toSet()
        // Some servers deliberately do not request a client certificate or username.
        // Only an explicit auth-user-pass directive proves that credentials are needed.
        return "auth-user-pass" in directives
    }

    // Full structured port of the desktop openvpn_import.py: the extended
    // sing-box core rejects the old {"type":"openvpn","config_str":...} shape,
    // so the profile must be decomposed into native outbound fields.
    fun parseOpenVpnConfig(text: String): ParsedNode {
        if (!looksLikeOpenVpnConfig(text)) {
            throw LinkParseError("not an OpenVPN client profile")
        }

        // Windows-exported profiles use CRLF. Carriage returns survive inside the
        // inline <ca>/<tls-crypt> bodies and reach the core as part of the PEM text,
        // where they break certificate and static-key decoding.
        val normalizedText = text.replace("\r\n", "\n").replace("\r", "\n")

        val inline = mutableMapOf<String, String>()
        var directivesText = OPENVPN_INLINE_BLOCK_REGEX.replace(normalizedText) { match ->
            val tag = match.groupValues[1].lowercase()
            val body = match.groupValues[2].trim('\r', '\n')
            inline[tag] = if (body.isEmpty()) "" else body + "\n"
            ""
        }

        val connectionBodies = mutableListOf<String>()
        directivesText = OPENVPN_CONNECTION_BLOCK_REGEX.replace(directivesText) { match ->
            connectionBodies += match.groupValues[1]
            ""
        }
        val byKey = parseOpenVpnDirectives(directivesText)
        val connectionMaps = connectionBodies.map(::parseOpenVpnDirectives)

        for (key in OPENVPN_UNSAFE_DIRECTIVES) {
            if (key in byKey || connectionMaps.any { key in it }) {
                throw LinkParseError("OpenVPN directive `$key` is not supported by sing-box extended")
            }
        }
        val dev = openVpnLastArg(byKey, "dev").lowercase()
        if (dev.startsWith("tap")) throw LinkParseError("OpenVPN TAP profiles are not supported; a TUN profile is required")
        // Same rule as the desktop client, which imports these profiles fine: a bare
        // `comp-lzo` / `compress` only asks for the compression framing byte, which the
        // core negotiates away, so it is accepted. Only an explicit algorithm the core
        // cannot decompress (lzo, lz4, ...) is rejected.
        for (key in listOf("compress", "comp-lzo")) {
            val value = openVpnLastArg(byKey, key).lowercase()
            if (value.isNotEmpty() && value !in setOf("no", "disable", "stub", "stub-v2")) {
                throw LinkParseError("OpenVPN compression `$value` is not supported")
            }
        }

        val globalProto = normalizeOpenVpnProto(openVpnLastArg(byKey, "proto").ifEmpty { "udp" })
        val remotes = mutableListOf<Pair<String, Map<String, Any?>>>()
        fun appendRemotes(source: Map<String, MutableList<List<String>>>, defaultProto: String) {
            val localProto = normalizeOpenVpnProto(openVpnLastArg(source, "proto").ifEmpty { defaultProto })
            for (values in source["remote"] ?: emptyList()) {
                if (values.isEmpty()) continue
                val server = values[0].trim()
                if (server.isEmpty()) continue
                val portText = values.getOrNull(1)?.trim() ?: "1194"
                val port = portText.toIntOrNull()?.takeIf { it in 1..65535 }
                    ?: throw LinkParseError("invalid OpenVPN remote port `$portText`")
                val remoteProto = values.getOrNull(2)?.let { normalizeOpenVpnProto(it) } ?: localProto
                remotes.add(remoteProto to mapOf(
                    "server" to server,
                    "server_port" to port,
                    "network" to remoteProto
                ))
            }
        }
        appendRemotes(byKey, globalProto)
        connectionMaps.forEach { appendRemotes(it, globalProto) }
        if (remotes.isEmpty()) throw LinkParseError("OpenVPN profile does not contain a usable `remote` server")
        val proto = remotes.first().first
        val servers = remotes.map { it.second }

        val native = mutableMapOf<String, Any?>(
            "type" to "openvpn",
            "tag" to "proxy",
            "system" to false,
            "name" to "openvpn0",
            "servers" to servers,
            "proto" to proto
        )
        if ("remote-random" in byKey) native["remote_random"] = true

        // "Use proxy": http-proxy/socks-proxy are standard directives, obfs2/obfs3
        // travel in a Lumen comment. The builder turns this into a detour outbound
        // and strips the key, so the core never sees it.
        parseOpenVpnProxy(text, byKey)?.let { native["lumen_proxy"] = it }

        val cipher = selectOpenVpnCipher(byKey)
        if (cipher.isNotEmpty()) native["cipher"] = cipher
        val auth = openVpnLastArg(byKey, "auth")
        if (auth.isNotEmpty() && auth.lowercase() != "none") {
            OpenVpnConfigNormalizer.normalizeAuthDigest(auth)?.let { native["auth"] = it }
        }
        for ((directive, nativeKey) in listOf("mssfix" to "mss_fix", "fragment" to "fragment")) {
            val value = openVpnLastArg(byKey, directive)
            if (value.isNotEmpty()) {
                val parsed = value.toIntOrNull()?.takeIf { it > 0 || (directive == "mssfix" && it == 0) }
                    ?: throw LinkParseError("invalid OpenVPN `$directive` value `$value`")
                if (directive == "mssfix" && parsed == 0) native["mss_fix_disabled"] = true
                else native[nativeKey] = parsed
            }
        }
        val explicitExitNotify = openVpnLastArg(byKey, "explicit-exit-notify")
            .ifEmpty { if ("explicit-exit-notify" in byKey) "1" else "" }
        if (explicitExitNotify.isNotEmpty()) {
            native["explicit_exit_notify"] = explicitExitNotify.toIntOrNull()?.takeIf { it >= 0 }
                ?: throw LinkParseError("invalid OpenVPN `explicit-exit-notify` value `$explicitExitNotify`")
        }

        val credentials = inline["auth-user-pass"] ?: ""
        if (credentials.isEmpty() && openVpnLastValues(byKey, "auth-user-pass").isNotEmpty()) {
            throw LinkParseError("OpenVPN `auth-user-pass` file references are not supported on Android; embed the credentials inline")
        }
        if (credentials.isNotEmpty()) {
            val credLines = credentials.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (credLines.isNotEmpty()) native["username"] = credLines[0]
            if (credLines.size > 1) native["password"] = credLines[1]
        }

        // An encrypted <key> is unusable without its passphrase. `askpass <file>`
        // cannot be read on Android, so the value has to travel inside the profile.
        val keyPassword = openVpnKeyPassword(text, inline)
        if (keyPassword.isEmpty() && openVpnLastValues(byKey, "askpass").isNotEmpty()) {
            throw LinkParseError(
                "OpenVPN `askpass` file references are not supported on Android; " +
                    "enter the private key password in the node editor"
            )
        }
        if (keyPassword.isNotEmpty()) native["key_password"] = keyPassword

        for ((directive, nativeKey) in listOf("tls-auth" to "tls_auth", "tls-crypt" to "tls_crypt", "tls-crypt-v2" to "tls_crypt")) {
            val content = inline[directive] ?: ""
            val values = openVpnLastValues(byKey, directive)
            if (content.isEmpty() && values.isNotEmpty()) {
                throw LinkParseError("OpenVPN `$directive` file references are not supported on Android; embed the key inline")
            }
            if (content.isNotEmpty()) {
                native[nativeKey] = content
                if (directive == "tls-crypt-v2") native["tls_crypt_v2"] = true
            }
            if (directive == "tls-auth" && values.size > 1) native["key_direction"] = openVpnKeyDirection(values[1])
            if (directive == "tls-auth" && content.isNotEmpty() && values.size <= 1) {
                // The core's zero value means direction 0, not bidirectional.
                native.putIfAbsent("key_direction", -1)
            }
        }
        val direction = openVpnLastArg(byKey, "key-direction")
        if (direction.isNotEmpty()) native["key_direction"] = openVpnKeyDirection(direction)

        for ((directive, nativeKey) in listOf("connect-retry" to "reconnect_delay", "ping" to "ping_interval", "ping-restart" to "ping_restart")) {
            val value = openVpnLastArg(byKey, directive)
            if (value.isNotEmpty()) native[nativeKey] = openVpnDurationSeconds(value, directive)
        }
        // `keepalive N M` is the shorthand most providers ship instead of the pair above.
        openVpnLastValues(byKey, "keepalive").let { values ->
            values.getOrNull(0)?.takeIf { it.isNotBlank() }?.let {
                native.putIfAbsent("ping_interval", openVpnDurationSeconds(it, "keepalive"))
            }
            values.getOrNull(1)?.takeIf { it.isNotBlank() }?.let {
                native.putIfAbsent("ping_restart", openVpnDurationSeconds(it, "keepalive"))
            }
        }
        // No implicit timers beyond what the profile states: the desktop client that
        // runs these same profiles successfully leaves them unset, and a forced
        // `ping_restart` tears down a healthy tunnel whenever the peer stays quiet.

        val tls = mutableMapOf<String, Any?>()
        for ((directive, nativeKey) in listOf("ca" to "ca", "cert" to "certificate", "key" to "key")) {
            val content = inline[directive] ?: ""
            val values = openVpnLastValues(byKey, directive)
            if (content.isEmpty() && values.isNotEmpty()) {
                throw LinkParseError("OpenVPN `$directive` file references are not supported on Android; embed the certificate inline")
            }
            if (content.isNotEmpty()) tls[nativeKey] = content
        }
        // The shipped extended core configures Go's TLS <=1.2 CipherSuites. OpenVPN's
        // `tls-ciphersuites` controls TLS 1.3 and cannot be represented by that field.
        val tlsCiphers = OpenVpnConfigNormalizer.normalizeTlsCipherSuites(
            openVpnLastArg(byKey, "tls-cipher")
        )
        if (tlsCiphers.isNotEmpty()) tls["cipher_suites"] = tlsCiphers
        val verifyValues = openVpnLastValues(byKey, "verify-x509-name")
        if (verifyValues.isNotEmpty()) {
            tls["verify_x509_name"] = verifyValues[0]
            if (verifyValues.size > 1) tls["verify_x509_name_mode"] = openVpnVerifyNameMode(verifyValues[1])
        }
        val remoteCertificateTls = openVpnLastArg(byKey, "remote-cert-tls").lowercase()
        if (remoteCertificateTls in setOf("server", "client")) {
            tls["remote_certificate_tls"] = remoteCertificateTls
        }
        if ((tls["ca"] as? String).isNullOrEmpty()) {
            throw LinkParseError("OpenVPN profile does not contain a CA certificate supported by this core")
        }
        native["tls"] = tls

        val dnsServers = mutableListOf<String>()
        for (values in byKey["dhcp-option"] ?: emptyList()) {
            if (values.size >= 2 && values[0].trim().uppercase() in setOf("DNS", "DNS6")) {
                val address = values[1].trim()
                if (address.isNotEmpty() && address !in dnsServers) dnsServers.add(address)
            }
        }

        val outbound = mutableMapOf<String, Any?>(
            "protocol" to "openvpn",
            "singbox" to native
        )
        if (dnsServers.isNotEmpty()) outbound["_dns"] = dnsServers

        val firstServer = servers[0]["server"].toString()
        val firstPort = (servers[0]["server_port"] as Number).toInt()
        return ParsedNode(
            name = "OpenVPN-$firstServer",
            scheme = "openvpn",
            server = firstServer,
            port = firstPort,
            link = text,
            outbound = outbound
        )
    }

    private fun parseOpenVpnDirectives(text: String): MutableMap<String, MutableList<List<String>>> {
        val byKey = mutableMapOf<String, MutableList<List<String>>>()
        for (rawLine in text.lines()) {
            val strippedLine = rawLine.trim()
            if (strippedLine.isEmpty() || strippedLine.startsWith("#") || strippedLine.startsWith(";")) continue
            val tokens = tokenizeOpenVpnLine(strippedLine)
            if (tokens.isEmpty()) continue
            val key = tokens[0].trimStart('-').trim().lowercase()
            if (key.isEmpty()) continue
            byKey.getOrPut(key) { mutableListOf() }.add(tokens.drop(1))
        }
        return byKey
    }

    private fun tokenizeOpenVpnLine(line: String): List<String> {
        val tokens = mutableListOf<String>()
        val current = StringBuilder()
        var quote: Char? = null
        var hasToken = false
        var i = 0
        while (i < line.length) {
            val c = line[i]
            when {
                quote != null -> if (c == quote) quote = null else current.append(c)
                c == '"' || c == '\'' -> { quote = c; hasToken = true }
                c.isWhitespace() -> {
                    if (hasToken || current.isNotEmpty()) {
                        tokens.add(current.toString()); current.setLength(0); hasToken = false
                    }
                }
                c == '\\' && i + 1 < line.length -> { current.append(line[i + 1]); i++ }
                else -> current.append(c)
            }
            i++
        }
        if (quote != null) throw LinkParseError("OpenVPN line has an unterminated quote: $line")
        if (hasToken || current.isNotEmpty()) tokens.add(current.toString())
        return tokens
    }

    private fun openVpnLastValues(byKey: Map<String, MutableList<List<String>>>, key: String): List<String> =
        byKey[key]?.lastOrNull() ?: emptyList()

    private fun openVpnLastArg(byKey: Map<String, MutableList<List<String>>>, key: String): String =
        openVpnLastValues(byKey, key).firstOrNull()?.trim() ?: ""

    private fun normalizeOpenVpnProto(value: String): String {
        val proto = value.trim().lowercase().ifEmpty { "udp" }
        if (proto in setOf("udp", "udp4", "udp6")) return "udp"
        if (proto in setOf("tcp", "tcp-client", "tcp4", "tcp4-client", "tcp6", "tcp6-client")) return "tcp"
        throw LinkParseError("unsupported OpenVPN transport `$value`")
    }

    private fun selectOpenVpnCipher(byKey: Map<String, MutableList<List<String>>>): String {
        // Prefer the negotiated modern list. `cipher` and data-ciphers-fallback are
        // legacy fallbacks and must not override a compatible data-ciphers choice.
        for (directive in listOf("data-ciphers", "ncp-ciphers", "cipher", "data-ciphers-fallback")) {
            val value = openVpnLastArg(byKey, directive)
            if (value.isEmpty()) continue
            for (candidate in value.split(":")) {
                OpenVpnConfigNormalizer.normalizeDataCipher(candidate)?.let { return it }
            }
        }
        return ""
    }

    private fun openVpnKeyDirection(value: String): Int {
        val normalized = value.trim().lowercase()
        return when (normalized) {
            "0" -> 0
            "1" -> 1
            "bidirectional", "bi", "-1" -> -1
            else -> throw LinkParseError("invalid OpenVPN key-direction `$value`")
        }
    }

    private fun openVpnDurationSeconds(value: String, directive: String): String {
        val seconds = value.trim().toIntOrNull()
            ?: throw LinkParseError("invalid OpenVPN `$directive` value `$value`")
        if (seconds < 0) throw LinkParseError("invalid OpenVPN `$directive` value `$value`")
        return "${seconds}s"
    }

    private fun openVpnVerifyNameMode(value: String): String {
        val normalized = value.trim().lowercase()
        return when (normalized) {
            "name", "name-prefix", "name-suffix" -> normalized
            "subject" -> throw LinkParseError(
                "OpenVPN verify-x509-name mode `subject` is not supported by the bundled core"
            )
            else -> throw LinkParseError("invalid OpenVPN verify-x509-name mode `$value`")
        }
    }

    private fun looksLikeOpenVpnConfig(text: String): Boolean {
        val lowered = text.lowercase()
        if (!Regex("(?m)^\\s*(?:--)?remote\\s+\\S+").containsMatchIn(lowered)) return false
        return Regex("(?m)^\\s*(?:--)?client\\s*$").containsMatchIn(lowered) ||
            Regex("(?m)^\\s*(?:--)?tls-client\\s*$").containsMatchIn(lowered) ||
            lowered.contains("<ca>")
    }

    private fun looksLikeClashYaml(text: String): Boolean {
        val lowered = text.lowercase()
        return lowered.contains("proxies:") || lowered.contains("proxy-providers:") ||
                lowered.contains("proxy-groups:") || lowered.contains("outbounds:") || lowered.contains("outbound:") ||
                lowered.contains("payload:") || lowered.contains("- name:") || lowered.contains("- type:") ||
                (lowered.contains("mode:") && lowered.contains("rules:"))
    }

    private fun sanitizeYamlText(text: String): String {
        var cleaned = text.replace("\t", "  ")
        cleaned = cleaned.lines()
            .filterNot { it.trimStart().startsWith("%") }
            .joinToString("\n")
        // Strip custom Mihomo / Clash tags like !vless, !select, !<tag> that break SnakeYAML
        cleaned = cleaned.replace(Regex("(?<=\\s|^|\\[|\\{)!(<[^>]+>|[A-Za-z0-9_.-]+)"), "")
        return cleaned
    }

    private fun extractProxyMaps(data: Any?): List<Map<String, Any?>> {
        val result = mutableListOf<Map<String, Any?>>()

        fun processMap(map: Map<*, *>) {
            val type = map["type"]?.toString()
            val server = map["server"]?.toString() ?: map["address"]?.toString() ?: map["host"]?.toString()
            // WARP MASQUE entries may be profile-only, so they have no server field.
            val serverless = type?.lowercase() == "masque"
            if (!type.isNullOrBlank() && (!server.isNullOrBlank() || serverless)) {
                val stringKeyMap = map.entries.associate { (it.key?.toString() ?: "") to it.value }
                result.add(stringKeyMap)
                return
            }

            val keysToCheck = listOf("proxies", "payload", "outbounds", "outbound")
            for (key in keysToCheck) {
                val list = map[key] as? List<*>
                list?.forEach { item ->
                    if (item is Map<*, *>) {
                        processMap(item)
                    }
                }
            }

            val providers = map["proxy-providers"] as? Map<*, *>
            providers?.values?.forEach { provider ->
                if (provider is Map<*, *>) {
                    processMap(provider)
                }
            }
        }

        when (data) {
            is Map<*, *> -> processMap(data)
            is List<*> -> data.forEach { item ->
                if (item is Map<*, *>) processMap(item)
            }
        }

        return result
    }

    private fun parseClashYamlNodesText(text: String): Pair<List<ParsedNode>, List<String>> {
        val nodes = mutableListOf<ParsedNode>()
        val errors = mutableListOf<String>()

        val sanitized = sanitizeYamlText(text)
        val yaml = Yaml()
        val data = try {
            yaml.load<Any>(sanitized)
        } catch (e: Exception) {
            throw LinkParseError("Invalid Clash YAML structure: ${e.message}")
        }

        val proxyMaps = extractProxyMaps(data)
        if (proxyMaps.isEmpty()) {
            return Pair(emptyList(), listOf("No proxies found in Clash YAML"))
        }

        for ((idx, map) in proxyMaps.withIndex()) {
            try {
                val node = parseClashProxyMap(map)
                nodes.add(node)
            } catch (e: Exception) {
                errors.add("Proxy ${idx + 1}: ${e.message}")
            }
        }

        // Clash/Mihomo proxy-groups are client-side selectors over the physical entries in
        // `proxies`; they are not portable proxy servers and must never become Lumen AUTO
        // nodes. In particular, subscriptions commonly contain one all-proxy `select` group
        // and one `url-test` group, which previously hid every real server behind fake AUTO
        // rows. Explicit Xray/sing-box balancers are handled by their native JSON parsers.
        return Pair(nodes, errors)
    }

    fun parseClashProxyMap(map: Map<String, Any?>): ParsedNode {
        val name = map["name"]?.toString()?.ifBlank { "Proxy" } ?: "Proxy"
        val rawType = map["type"]?.toString()?.trim()?.lowercase()
            ?.takeIf(String::isNotEmpty) ?: throw LinkParseError("Missing proxy type")
        if (rawType !in CLASH_SUPPORTED_PROXY_TYPES) {
            throw LinkParseError(
                "Unsupported Clash proxy type `$rawType`; it cannot be translated safely for sing-box-extended"
            )
        }
        // WARP-generator MASQUE entries may be profile-only (no server field).
        val serverOrNull = map["server"]?.toString() ?: map["address"]?.toString() ?: map["host"]?.toString()
        if (serverOrNull == null && rawType != "masque") throw LinkParseError("Missing proxy server")
        val server = serverOrNull ?: ""
        val scalarPort = (map["port"] ?: map["server_port"])?.toString()?.toIntOrNull()
        val rangePorts = clashStringList(map["server-ports"] ?: map["server_ports"] ?: map["ports"])
        val port = scalarPort ?: representativePort(rangePorts) ?: 443

        // `reserved` is a plain WireGuard/WARP field, not an AmneziaWG obfuscation
        // parameter, so it must not promote the entry to AWG. Clash keeps the real
        // obfuscation knobs in the nested `amnezia-wg-option` block.
        val hasAmneziaParams = amneziaOptionsFrom(map, clashAmneziaOptions(map)).isNotEmpty()
        val scheme = if (rawType == "awg" || rawType == "amneziawg" || rawType == "amnezia-wg" || (rawType in setOf("wg", "wireguard") && hasAmneziaParams)) "awg" else when (rawType) {
            "shadowsocks" -> "ss"
            "hy2" -> "hysteria2"
            "hy" -> "hysteria"
            "wg" -> "wireguard"
            "socks5" -> "socks"
            "https" -> "http"
            else -> rawType
        }

        val outbound = mutableMapOf<String, Any?>(
            "protocol" to scheme,
            "clash" to map
        )

        val link = buildClashUriLink(name, scheme, server, port, map, outbound)

        return ParsedNode(
            name = name,
            scheme = scheme,
            server = server,
            port = port,
            link = link,
            outbound = outbound
        )
    }

    private fun buildClashUriLink(
        name: String,
        scheme: String,
        server: String,
        port: Int,
        map: Map<String, Any?>,
        outbound: MutableMap<String, Any?>
    ): String {
        return try {
            val encodedName = java.net.URLEncoder.encode(name, "UTF-8").replace("+", "%20")
            val rawType = map["type"]?.toString()?.trim()?.lowercase().orEmpty()
            when (scheme) {
                "vless" -> {
                    val uuid = map["uuid"]?.toString() ?: map["id"]?.toString() ?: ""
                    val flow = map["flow"]?.toString() ?: ""
                    // map["type"] is the Clash proxy type ("vless"), never a transport.
                    val net = map["network"]?.toString() ?: "tcp"
                    val tls = map["tls"] == true || map["tls"]?.toString() == "true"
                    val sni = map["servername"]?.toString() ?: map["sni"]?.toString() ?: server
                    val realityOpts = map["reality-opts"] as? Map<*, *>
                    val wsOpts = map["ws-opts"] as? Map<*, *>
                    val grpcOpts = map["grpc-opts"] as? Map<*, *>
                    val fp = map["client-fingerprint"]?.toString() ?: map["fp"]?.toString() ?: ""
                    val security = if (realityOpts != null) "reality" else if (tls) "tls" else "none"

                    val params = mutableMapOf<String, String>()
                    params["type"] = net
                    params["security"] = security
                    if (sni.isNotEmpty()) params["sni"] = sni
                    if (fp.isNotEmpty()) params["fp"] = fp
                    if (flow.isNotEmpty()) params["flow"] = flow
                    clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                        params["pinsha256"] = it.joinToString(",")
                    }
                    if (toBool(map["skip-cert-verify"]) || toBool(map["insecure"])) {
                        params["allowinsecure"] = "1"
                    }
                    clashTransportParams(map, params)

                    if (wsOpts != null) {
                        wsOpts["path"]?.toString()?.let { params["path"] = it }
                        (wsOpts["headers"] as? Map<*, *>)?.get("Host")?.toString()?.let { params["host"] = it }
                    }
                    if (grpcOpts != null) {
                        grpcOpts["grpc-service-name"]?.toString()?.let { params["servicename"] = it }
                    }
                    if (realityOpts != null) {
                        realityOpts["public-key"]?.toString()?.let { params["pbk"] = it }
                        realityOpts["short-id"]?.toString()?.let { params["sid"] = it }
                    }

                    val user = mutableMapOf<String, Any?>("id" to uuid, "encryption" to "none")
                    if (flow.isNotEmpty()) user["flow"] = flow
                    val streamSettings = enrichClashStreamSettings(
                        buildStreamSettings(params, defaultNetwork = "tcp", defaultSecurity = security),
                        map
                    )

                    outbound["settings"] = mapOf("vnext" to listOf(mapOf("address" to server, "port" to port, "users" to listOf(user))))
                    outbound["streamSettings"] = streamSettings

                    val q = params.entries.joinToString("&") { "${it.key}=${java.net.URLEncoder.encode(it.value, "UTF-8")}" }
                    "vless://$uuid@$server:$port?$q#$encodedName"
                }
                "vmess" -> {
                    val uuid = map["uuid"]?.toString() ?: ""
                    val alterId = (map["alterId"] as? Number)?.toInt() ?: 0
                    val cipher = map["cipher"]?.toString() ?: map["security"]?.toString() ?: "auto"
                    val net = map["network"]?.toString() ?: "tcp"
                    val tls = if (map["tls"] == true || map["tls"]?.toString() == "true") "tls" else "none"
                    val sni = map["servername"]?.toString() ?: map["sni"]?.toString() ?: ""
                    val user = mapOf("id" to uuid, "alterId" to alterId, "security" to cipher)
                    val params = mutableMapOf("type" to net, "security" to tls, "sni" to sni)
                    map["client-fingerprint"]?.toString()?.takeIf(String::isNotEmpty)?.let { params["fp"] = it }
                    map["alpn"]?.let { params["alpn"] = clashStringList(it).joinToString(",") }
                    clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                        params["pinsha256"] = it.joinToString(",")
                    }
                    if (toBool(map["skip-cert-verify"]) || toBool(map["insecure"])) {
                        params["allowinsecure"] = "1"
                    }
                    clashTransportParams(map, params)
                    val streamSettings = enrichClashStreamSettings(
                        buildStreamSettings(params, defaultNetwork = "tcp", defaultSecurity = tls),
                        map
                    )

                    outbound["settings"] = mapOf("vnext" to listOf(mapOf("address" to server, "port" to port, "users" to listOf(user))))
                    outbound["streamSettings"] = streamSettings

                    val json = JSONObject(mapOf(
                        "v" to "2", "ps" to name, "add" to server, "port" to port, "id" to uuid,
                        "aid" to alterId, "scy" to cipher, "net" to net, "type" to "none",
                        "host" to (params["host"] ?: ""), "path" to (
                            params["path"] ?: params["servicename"] ?: ""
                        ), "tls" to tls, "sni" to sni,
                        "alpn" to (params["alpn"] ?: ""), "fp" to (params["fp"] ?: ""),
                        "pinSHA256" to (params["pinsha256"] ?: "")
                    )).toString()
                    "vmess://${Base64.getEncoder().encodeToString(json.toByteArray(Charsets.UTF_8))}"
                }
                "trojan" -> {
                    val password = map["password"]?.toString() ?: ""
                    val sni = map["servername"]?.toString() ?: map["sni"]?.toString() ?: server
                    val net = map["network"]?.toString() ?: "tcp"
                    val params = mutableMapOf("type" to net, "security" to "tls", "sni" to sni)
                    map["client-fingerprint"]?.toString()?.takeIf(String::isNotEmpty)?.let { params["fp"] = it }
                    map["alpn"]?.let { params["alpn"] = clashStringList(it).joinToString(",") }
                    clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                        params["pinsha256"] = it.joinToString(",")
                    }
                    if (toBool(map["skip-cert-verify"]) || toBool(map["insecure"])) {
                        params["allowinsecure"] = "1"
                    }
                    clashTransportParams(map, params)
                    val streamSettings = enrichClashStreamSettings(
                        buildStreamSettings(params, defaultNetwork = "tcp", defaultSecurity = "tls"),
                        map
                    )

                    outbound["settings"] = mapOf("servers" to listOf(mapOf("address" to server, "port" to port, "password" to password)))
                    outbound["streamSettings"] = streamSettings

                    val query = params.entries.joinToString("&") {
                        "${it.key}=${java.net.URLEncoder.encode(it.value, "UTF-8")}"
                    }
                    "trojan://$password@$server:$port?$query#$encodedName"
                }
                "ss" -> {
                    val method = map["cipher"]?.toString() ?: map["method"]?.toString() ?: "aes-256-gcm"
                    val password = map["password"]?.toString() ?: ""

                    val serverMap = mutableMapOf<String, Any?>(
                        "address" to server,
                        "port" to port,
                        "method" to method,
                        "password" to password
                    )
                    val plugin = normalizeShadowsocksPluginName(map["plugin"]?.toString().orEmpty())
                    val pluginOpts = (map["plugin-opts"] ?: map["plugin_opts"])?.let { raw ->
                        when (raw) {
                            is Map<*, *> -> sip003OptionsFromMapping(raw, plugin == "obfs-local")
                            else -> if (plugin == "obfs-local") normalizeObfsPluginOptions(raw.toString()) else raw.toString()
                        }
                    }.orEmpty()
                    if (plugin.isNotEmpty()) serverMap["plugin"] = plugin
                    if (pluginOpts.isNotEmpty()) serverMap["plugin_opts"] = pluginOpts
                    outbound["settings"] = mapOf("servers" to listOf(serverMap))

                    val userInfo = shadowsocksUserInfo(method, password)
                    val pluginQuery = if (plugin.isEmpty()) {
                        ""
                    } else {
                        val pluginValue = listOf(plugin, pluginOpts).filter(String::isNotEmpty).joinToString(";")
                        "/?plugin=${java.net.URLEncoder.encode(pluginValue, "UTF-8")}"
                    }
                    "ss://$userInfo@${uriHost(server)}:$port$pluginQuery#$encodedName"
                }
                "hysteria2" -> {
                    val password = map["password"]?.toString() ?: map["auth"]?.toString() ?: ""
                    val sni = map["servername"]?.toString() ?: map["sni"]?.toString() ?: server
                    val insecure = map["skip-cert-verify"] == true || map["insecure"] == true
                    val obfs = map["obfs"]?.toString() ?: ""
                    val obfsPassword = map["obfs-password"]?.toString() ?: ""

                    val tlsMap = mutableMapOf<String, Any?>(
                        "enabled" to true,
                        "server_name" to sni,
                        "insecure" to insecure
                    )
                    clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                        tlsMap["certificate_public_key_sha256"] = it
                    }
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "hysteria2",
                        "server" to server,
                        "server_port" to port,
                        "password" to password,
                        "tls" to tlsMap
                    )
                    if (obfs.isNotEmpty()) singbox["obfs"] = mapOf("type" to obfs, "password" to obfsPassword)
                    clashSpeedMbps(map["up"] ?: map["up-mbps"] ?: map["up_mbps"])?.let { singbox["up_mbps"] = it }
                    clashSpeedMbps(map["down"] ?: map["down-mbps"] ?: map["down_mbps"])?.let { singbox["down_mbps"] = it }
                    val ports = clashStringList(map["ports"] ?: map["server-ports"] ?: map["server_ports"])
                    if (ports.isNotEmpty()) singbox["server_ports"] = ports
                    (map["hop-interval"] ?: map["hop_interval"])?.let {
                        singbox["hop_interval"] = durationSeconds(it)
                    }
                    outbound["singbox"] = singbox

                    val params = mutableListOf(
                        "sni=${java.net.URLEncoder.encode(sni, "UTF-8")}",
                        "insecure=${if (insecure) 1 else 0}"
                    )
                    if (obfs.isNotEmpty()) params += "obfs=${java.net.URLEncoder.encode(obfs, "UTF-8")}"
                    if (obfsPassword.isNotEmpty()) {
                        params += "obfs-password=${java.net.URLEncoder.encode(obfsPassword, "UTF-8")}"
                    }
                    "hy2://$password@$server:$port?${params.joinToString("&")}#$encodedName"
                }
                "hysteria" -> {
                    // Hysteria v1 (parity with desktop _clash_to_singbox_outbound).
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "hysteria",
                        "tag" to "proxy",
                        "server" to server,
                        "server_port" to port
                    )
                    val authStr = (map["auth-str"] ?: map["auth_str"] ?: map["auth"] ?: map["password"])?.toString() ?: ""
                    if (authStr.isNotEmpty()) singbox["auth_str"] = authStr
                    clashSpeedMbps(map["up"] ?: map["up-speed"] ?: map["up_mbps"])?.let { singbox["up_mbps"] = it }
                    clashSpeedMbps(map["down"] ?: map["down-speed"] ?: map["down_mbps"])?.let { singbox["down_mbps"] = it }
                    map["protocol"]?.toString()?.takeIf { it.isNotBlank() && it.lowercase() != "hysteria" }?.let { singbox["protocol"] = it }
                    map["obfs"]?.toString()?.takeIf { it.isNotBlank() }?.let { singbox["obfs"] = it }
                    clashStringList(map["ports"] ?: map["server-ports"] ?: map["server_ports"])
                        .takeIf { it.isNotEmpty() }?.let { singbox["server_ports"] = it }
                    (map["hop-interval"] ?: map["hop_interval"])?.let {
                        singbox["hop_interval"] = durationSeconds(it)
                    }
                    (map["recv-window-conn"] ?: map["recv_window_conn"])?.toString()?.toLongOrNull()
                        ?.let { singbox["recv_window_conn"] = it }
                    (map["recv-window"] ?: map["recv_window"])?.toString()?.toLongOrNull()
                        ?.let { singbox["recv_window"] = it }
                    if (toBool(map["disable-mtu-discovery"] ?: map["disable_mtu_discovery"])) {
                        singbox["disable_mtu_discovery"] = true
                    }
                    val tls = mutableMapOf<String, Any?>("enabled" to true)
                    tls["server_name"] = (map["servername"] ?: map["sni"])?.toString()?.takeIf { it.isNotBlank() } ?: server
                    if (toBool(map["skip-cert-verify"])) tls["insecure"] = true
                    val alpnValue = map["alpn"]
                    val alpnList = when (alpnValue) {
                        is List<*> -> alpnValue.mapNotNull { it?.toString()?.trim() }.filter { it.isNotEmpty() }
                        null -> emptyList()
                        else -> alpnValue.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
                    }
                    if (alpnList.isNotEmpty()) tls["alpn"] = alpnList
                    clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                        tls["certificate_public_key_sha256"] = it
                    }
                    singbox["tls"] = tls
                    outbound["singbox"] = singbox
                    toJsonString(singbox)
                }
                "naive" -> {
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "naive",
                        "tag" to "proxy",
                        "server" to server,
                        "server_port" to port,
                        "username" to (map["username"]?.toString() ?: ""),
                        "password" to (map["password"]?.toString() ?: ""),
                        "quic" to toBool(map["quic"])
                    )
                    val tls = mutableMapOf<String, Any?>("enabled" to true)
                    // Cronet cannot skip certificate verification, so no insecure here.
                    tls["server_name"] = (map["servername"] ?: map["sni"])?.toString()?.takeIf { it.isNotBlank() } ?: server
                    singbox["tls"] = tls
                    ((map["insecure-concurrency"] ?: map["insecure_concurrency"]))?.toString()?.toIntOrNull()?.let {
                        singbox["insecure_concurrency"] = it
                    }
                    (map["quic-congestion-control"] ?: map["quic_congestion_control"])?.toString()?.takeIf { it.isNotBlank() }?.let {
                        singbox["quic_congestion_control"] = it
                    }
                    val uot = map["udp-over-tcp"] ?: map["udp_over_tcp"]
                    if (uot is Boolean || uot is Map<*, *>) singbox["udp_over_tcp"] = uot
                    val extraHeaders = map["extra-headers"] ?: map["extra_headers"]
                    if (extraHeaders is Map<*, *>) singbox["extra_headers"] = extraHeaders
                    outbound["singbox"] = singbox
                    toJsonString(singbox)
                }
                "mieru" -> {
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "mieru",
                        "tag" to "proxy",
                        "server" to server,
                        "transport" to ((map["transport"]?.toString()?.takeIf { it.isNotBlank() } ?: "TCP").uppercase()),
                        "username" to (map["username"]?.toString() ?: ""),
                        "password" to (map["password"]?.toString() ?: "")
                    )
                    (map["port"] ?: map["server_port"])?.toString()?.toIntOrNull()
                        ?.takeIf { it in 1..65535 }?.let { singbox["server_port"] = it }
                    map["multiplexing"]?.toString()?.takeIf { it.isNotBlank() }?.let { singbox["multiplexing"] = it }
                    val serverPorts = clashStringList(map["server-ports"] ?: map["server_ports"] ?: map["ports"])
                    if (serverPorts.isNotEmpty()) singbox["server_ports"] = serverPorts
                    (map["traffic-pattern"] ?: map["traffic_pattern"])?.toString()
                        ?.takeIf(String::isNotBlank)?.let { singbox["traffic_pattern"] = it }
                    outbound["singbox"] = singbox
                    toJsonString(singbox)
                }
                "masque" -> {
                    // Port of the desktop _parse_clash_masque_payload (WARP generators).
                    val network = map["network"]?.toString()?.lowercase() ?: ""
                    val profile = mutableMapOf<String, Any?>("detour" to "direct")
                    (map["profile-id"] ?: map["profile_id"])?.toString()?.takeIf { it.isNotBlank() }?.let { profile["id"] = it }
                    (map["auth-token"] ?: map["auth_token"])?.toString()?.takeIf { it.isNotBlank() }?.let { profile["auth_token"] = it }
                    (map["masque-private-key"] ?: map["masque_private_key"])?.toString()?.takeIf { it.isNotBlank() }?.let { profile["private_key"] = it }
                    val privateKey = (map["private-key"] ?: map["private_key"])?.toString()?.trim() ?: ""
                    val publicKey = (map["public-key"] ?: map["public_key"])?.toString()?.trim() ?: ""
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "masque",
                        "tag" to "proxy",
                        "system" to false,
                        "name" to "masque0",
                        "use_http2" to (network == "h2" || network == "http2"),
                        "use_ipv6" to toBool(map["use-ipv6"] ?: map["use_ipv6"]),
                        "profile" to profile,
                        "udp_timeout" to "5m0s",
                        "udp_keepalive_period" to "30s",
                        "reconnect_delay" to "5s",
                        "congestion_controller" to "bbr"
                    )
                    if (privateKey.isNotEmpty() || publicKey.isNotEmpty()) {
                        // Clash/Mihomo exports a concrete endpoint and key pair here,
                        // but this bundled sing-box MASQUE implementation manages its
                        // Cloudflare profile itself. Keep these fields only as WARP
                        // classification hints; emitting them makes config decoding fail.
                        if (privateKey.isEmpty() || publicKey.isEmpty() || server.isEmpty()) {
                            throw LinkParseError("direct MASQUE proxy must contain server, private-key and public-key")
                        }
                        val address = clashStringList(map["ip"] ?: map["address"]).toMutableList()
                        for (item in clashStringList(map["ipv6"])) if (item !in address) address.add(item)
                        if (address.isEmpty()) throw LinkParseError("direct MASQUE proxy must contain ip, ipv6 or address")
                        if (isCloudflareWarpProfile(address, publicKey, server)) {
                            outbound["warp"] = true
                            outbound["display_protocol"] = "MASQUE/WARP"
                        }
                    } else if (profile["id"] == null && profile["auth_token"] == null && profile["private_key"] == null) {
                        throw LinkParseError("MASQUE proxy must contain profile-id/auth-token or private-key/public-key")
                    }
                    val allowedIps = clashStringList(map["allowed-ips"] ?: map["allowed_ips"])
                    if (allowedIps.isNotEmpty()) singbox["allowed_ips"] = allowedIps
                    (map["sni"] ?: map["servername"])?.toString()?.takeIf { it.isNotBlank() }?.let {
                        singbox["tls"] = mapOf("server_name" to it)
                    }
                    outbound["singbox"] = singbox
                    toJsonString(singbox)
                }
                "tuic" -> {
                    val uuid = map["uuid"]?.toString() ?: ""
                    val password = map["password"]?.toString() ?: ""
                    val sni = map["servername"]?.toString() ?: map["sni"]?.toString() ?: server
                    val cc = map["congestion-controller"]?.toString() ?: map["congestion_control"]?.toString() ?: "bbr"
                    val alpnStr = (map["alpn"] as? List<*>)?.joinToString(",") ?: map["alpn"]?.toString() ?: "h3"

                    val singbox = mapOf<String, Any?>(
                        "type" to "tuic",
                        "server" to server,
                        "server_port" to port,
                        "uuid" to uuid,
                        "password" to password,
                        "congestion_control" to cc,
                        "tls" to mapOf("enabled" to true, "server_name" to sni, "alpn" to alpnStr.split(","))
                    )
                    outbound["singbox"] = singbox

                    "tuic://$uuid:$password@$server:$port?sni=${java.net.URLEncoder.encode(sni, "UTF-8")}&congestion_control=$cc#$encodedName"
                }
                "wireguard", "awg" -> {
                    val privateKey = map["private-key"]?.toString() ?: map["private_key"]?.toString()
                        ?: map["privateKey"]?.toString() ?: map["secret-key"]?.toString() ?: map["secret_key"]?.toString() ?: ""
                    val publicKey = map["public-key"]?.toString() ?: map["public_key"]?.toString() ?: ""
                    val ipStr = (map["ip"] as? List<*>)?.joinToString(",") ?: map["ip"]?.toString() ?: map["address"]?.toString() ?: ""
                    val ips = ipStr.split(",").map { it.trim() }.filter { it.isNotEmpty() }

                    val amneziaOpts = clashAmneziaOptions(map)

                    val amneziaMap = amneziaOptionsFrom(map, amneziaOpts)
                    val isAwg = scheme == "awg" || amneziaMap.isNotEmpty()
                    val actualScheme = if (isAwg) "awg" else "wireguard"

                    // Peer/interface extras Clash spells with dashes; dropping them
                    // silently broke split-tunnel AllowedIPs, MTU and keepalive.
                    val allowedIps = clashStringList(map["allowed-ips"] ?: map["allowed_ips"] ?: map["allowedips"])
                        .ifEmpty { listOf("0.0.0.0/0", "::/0") }
                    val preSharedKey = (map["pre-shared-key"] ?: map["pre_shared_key"] ?: map["preshared-key"])
                        ?.toString()?.trim().orEmpty()
                    val keepalive = (map["persistent-keepalive"] ?: map["persistent_keepalive"] ?: map["keepalive"])
                        ?.toString()?.trim()?.toIntOrNull()
                    val mtu = map["mtu"]?.toString()?.trim()?.toIntOrNull()
                    val dnsServers = clashStringList(map["dns"])

                    val peer = mutableMapOf<String, Any?>(
                        "public_key" to publicKey,
                        "server" to server,
                        "server_port" to port,
                        "allowed_ips" to allowedIps
                    )
                    if (preSharedKey.isNotEmpty()) peer["pre_shared_key"] = preSharedKey
                    if (keepalive != null && keepalive > 0) peer["persistent_keepalive_interval"] = keepalive

                    val singbox = mutableMapOf<String, Any?>(
                        "type" to actualScheme,
                        "server" to server,
                        "server_port" to port,
                        "private_key" to privateKey,
                        "address" to ips,
                        "peers" to listOf(peer)
                    )
                    if (mtu != null && mtu > 0) singbox["mtu"] = mtu
                    if (amneziaMap.isNotEmpty()) {
                        singbox["amnezia"] = amneziaMap
                    }
                    if (map["reserved"] != null) {
                        singbox["reserved"] = map["reserved"]
                    }
                    outbound["protocol"] = actualScheme
                    outbound["singbox"] = singbox
                    if (dnsServers.isNotEmpty()) outbound["_dns"] = dnsServers

                    val amneziaQuery = StringBuilder()
                    // AWG 2.0 packet definitions carry spaces and angle brackets, so
                    // they only survive the link as percent-encoded values. The space
                    // must be %20: the reader keeps '+' literal (base64 keys need it),
                    // so a form-encoded space would turn "<b 0x..>" into "<b+0x..>".
                    for ((junkKey, junkVal) in amneziaMap) {
                        amneziaQuery.append("&").append(junkKey).append("=")
                            .append(java.net.URLEncoder.encode(junkVal.toString(), "UTF-8").replace("+", "%20"))
                    }
                    if (allowedIps != listOf("0.0.0.0/0", "::/0")) {
                        amneziaQuery.append("&allowedips=")
                            .append(java.net.URLEncoder.encode(allowedIps.joinToString(","), "UTF-8"))
                    }
                    if (preSharedKey.isNotEmpty()) {
                        amneziaQuery.append("&presharedkey=")
                            .append(java.net.URLEncoder.encode(preSharedKey, "UTF-8"))
                    }
                    if (keepalive != null && keepalive > 0) amneziaQuery.append("&persistentkeepalive=").append(keepalive)
                    if (mtu != null && mtu > 0) amneziaQuery.append("&mtu=").append(mtu)
                    if (dnsServers.isNotEmpty()) {
                        amneziaQuery.append("&dns=")
                            .append(java.net.URLEncoder.encode(dnsServers.joinToString(","), "UTF-8"))
                    }
                    // The reserved bytes belong in the link too, otherwise a WARP
                    // entry does not survive a round trip through its own URI.
                    val reserved = clashStringList(map["reserved"]).joinToString(",")
                    if (reserved.isNotEmpty()) {
                        amneziaQuery.append("&reserved=").append(java.net.URLEncoder.encode(reserved, "UTF-8"))
                    }
                    if (ips.isNotEmpty()) {
                        amneziaQuery.append("&ip=").append(java.net.URLEncoder.encode(ips.joinToString(","), "UTF-8"))
                    }
                    "${if (isAwg) "awg" else "wg"}://${java.net.URLEncoder.encode(privateKey, "UTF-8")}@$server:$port?publickey=${java.net.URLEncoder.encode(publicKey, "UTF-8")}$amneziaQuery#$encodedName"
                }
                "socks" -> {
                    val user = map["username"]?.toString() ?: ""
                    val pass = map["password"]?.toString() ?: ""
                    val serverMap = mutableMapOf<String, Any?>("address" to server, "port" to port)
                    if (user.isNotEmpty()) serverMap["users"] = listOf(mapOf("user" to user, "pass" to pass))
                    outbound["settings"] = mapOf("servers" to listOf(serverMap))

                    val auth = if (user.isNotEmpty()) "$user:$pass@" else ""
                    "socks5://$auth$server:$port#$encodedName"
                }
                "http" -> {
                    val user = map["username"]?.toString() ?: ""
                    val pass = map["password"]?.toString() ?: ""
                    val serverMap = mutableMapOf<String, Any?>("address" to server, "port" to port)
                    if (user.isNotEmpty()) serverMap["users"] = listOf(mapOf("user" to user, "pass" to pass))
                    outbound["settings"] = mapOf("servers" to listOf(serverMap))

                    val auth = if (user.isNotEmpty()) "$user:$pass@" else ""
                    val secure = rawType == "https" || toBool(map["tls"])
                    if (secure) {
                        val tls = mutableMapOf<String, Any?>(
                            "enabled" to true,
                            "server_name" to (
                                map["servername"]?.toString()
                                    ?: map["sni"]?.toString()
                                    ?: server
                            )
                        )
                        if (toBool(map["skip-cert-verify"] ?: map["insecure"])) tls["insecure"] = true
                        clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                            tls["certificate_public_key_sha256"] = it
                        }
                        outbound["tls"] = tls
                    }
                    "${if (secure) "https" else "http"}://$auth$server:$port#$encodedName"
                }
                "anytls" -> {
                    val password = map["password"]?.toString().orEmpty()
                    if (password.isEmpty()) throw LinkParseError("AnyTLS proxy is missing password")
                    val tls = mutableMapOf<String, Any?>(
                        "enabled" to true,
                        "server_name" to (
                            map["servername"]?.toString()
                                ?: map["sni"]?.toString()
                                ?: server
                        )
                    )
                    if (toBool(map["skip-cert-verify"] ?: map["insecure"])) tls["insecure"] = true
                    clashStringList(map["alpn"]).takeIf { it.isNotEmpty() }?.let { tls["alpn"] = it }
                    clashCertificatePins(map).takeIf { it.isNotEmpty() }?.let {
                        tls["certificate_public_key_sha256"] = it
                    }
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "anytls",
                        "server" to server,
                        "server_port" to port,
                        "password" to password,
                        "tls" to tls
                    )
                    (map["idle-session-check-interval"] ?: map["idle_session_check_interval"])
                        ?.let { singbox["idle_session_check_interval"] = durationSeconds(it) }
                    (map["idle-session-timeout"] ?: map["idle_session_timeout"])
                        ?.let { singbox["idle_session_timeout"] = durationSeconds(it) }
                    (map["min-idle-session"] ?: map["min_idle_session"])?.toString()?.toIntOrNull()
                        ?.let { singbox["min_idle_session"] = it }
                    outbound["singbox"] = singbox
                    toJsonString(singbox)
                }
                "snell" -> {
                    val psk = (map["psk"] ?: map["password"])?.toString().orEmpty()
                    if (psk.isEmpty()) throw LinkParseError("Snell proxy is missing psk")
                    val singbox = mutableMapOf<String, Any?>(
                        "type" to "snell",
                        "server" to server,
                        "server_port" to port,
                        "psk" to psk
                    )
                    map["version"]?.toString()?.toIntOrNull()?.let { singbox["version"] = it }
                    if (toBool(map["reuse"])) singbox["reuse"] = true
                    val obfsOpts = map["obfs-opts"] as? Map<*, *> ?: map["obfs_opts"] as? Map<*, *>
                    if (obfsOpts != null) {
                        val obfs = mutableMapOf<String, Any?>()
                        obfsOpts["mode"]?.toString()?.takeIf(String::isNotBlank)?.let { obfs["mode"] = it }
                        obfsOpts["host"]?.toString()?.takeIf(String::isNotBlank)?.let { obfs["host"] = it }
                        if (obfs.isNotEmpty()) singbox["obfs"] = obfs
                    }
                    outbound["singbox"] = singbox
                    toJsonString(singbox)
                }
                else -> {
                    throw LinkParseError("Unsupported Clash proxy type `$rawType`")
                }
            }
        } catch (e: LinkParseError) {
            // Validation failures must reach the caller: only the link string may
            // safely fall back to raw JSON, never a half-populated outbound.
            throw e
        } catch (_: Exception) {
            toJsonString(map)
        }
    }

    private fun parseJsonNodesText(text: String, depth: Int = 0): Pair<List<ParsedNode>, List<String>> {
        if (depth > 16) throw LinkParseError("JSON subscription nesting exceeds 16 levels")
        val root = parseCompleteJson(text)
        if (root is String) return parseLinksTextInternal(root, depth + 1)
        val nodes = mutableListOf<ParsedNode>()
        val errors = mutableListOf<String>()

        if (text.startsWith("[")) {
            val array = root as JSONArray
            for (i in 0 until array.length()) {
                // One bad entry must not abort a whole array of configs.
                try {
                    when (val item = array.get(i)) {
                        is JSONObject ->
                            // Panels ship arrays of whole client configs, not bare outbounds.
                            if (item.has("outbounds") || item.has("endpoints") || item.has("proxies") || item.has("inbounds")) {
                                val (inner, innerErrors) = parseJsonNodesText(item.toString(), depth + 1)
                                val label = listOf("remarks", "profile_title", "name", "tag")
                                    .firstNotNullOfOrNull { key -> item.optString(key).takeIf { it.isNotBlank() } }
                                    .orEmpty()
                                // Drop separator/placeholder profiles shipped by panels.
                                val usable = inner.filterNot { isPlaceholderNode(it) }
                                nodes += when {
                                    usable.isEmpty() -> emptyList()
                                    label.isEmpty() -> usable
                                    else -> usable.map { node ->
                                        val suffix = node.name.takeIf { it.isNotBlank() && it != label }
                                        node.copy(name = if (suffix == null) label else "$label · $suffix")
                                    }
                                }
                                errors += innerErrors.map { "Config ${i + 1}: $it" }
                            } else {
                                val (inner, innerErrors) = parseJsonNodesText(item.toString(), depth + 1)
                                nodes.addAll(inner)
                                errors.addAll(innerErrors)
                            }
                        is String -> {
                            val (inner, innerErrors) = parseLinksTextInternal(item, depth + 1)
                            nodes.addAll(inner)
                            errors.addAll(innerErrors)
                        }
                        is JSONArray -> {
                            val (inner, innerErrors) = parseJsonNodesText(item.toString(), depth + 1)
                            nodes.addAll(inner)
                            errors.addAll(innerErrors)
                        }
                        else -> errors.add("Item ${i + 1}: unsupported JSON value")
                    }
                } catch (e: Exception) {
                    errors.add("Item ${i + 1}: ${e.message}")
                }
            }
        } else if (text.startsWith("{")) {
            val json = root as JSONObject
            val containerKeys = listOf("outbounds", "endpoints", "proxies", "nodes", "configs", "links", "subs", "items")
            if ((json.has("type") || json.has("protocol")) && containerKeys.none { json.has(it) }) {
                return Pair(listOf(parseJsonItem(json)), emptyList())
            }
            if (containerKeys.none { json.has(it) } && !json.has("servers")) {
                val nested: Any? = json.optJSONObject("outbound")
                    ?: listOf("link", "uri", "url", "config", "data", "content")
                        .firstNotNullOfOrNull { key -> json.opt(key)?.takeIf { it is String || it is JSONObject || it is JSONArray } }
                if (nested != null) {
                    val (inner, innerErrors) = if (nested is String) parseLinksTextInternal(nested, depth + 1)
                        else parseJsonNodesText(nested.toString(), depth + 1)
                    val label = listOf("name", "remarks", "profile_title")
                        .firstNotNullOfOrNull { json.optString(it).takeIf(String::isNotBlank) }
                    return Pair(if (label == null) inner else inner.map { it.copy(name = label) }, innerErrors)
                }
            }
            if (json.has("proxy") && !json.has("type") && !json.has("protocol") &&
                !json.has("outbounds") && !json.has("endpoints") && !json.has("proxies")
            ) {
                // NaiveProxy config.json: {"listen": ..., "proxy": "https://user:pass@host"}
                val rawProxy = json.get("proxy")
                val proxyList = if (rawProxy is JSONArray) {
                    (0 until rawProxy.length()).map { rawProxy.get(it).toString() }
                } else {
                    listOf(rawProxy.toString())
                }
                for ((i, rawUri) in proxyList.withIndex()) {
                    val uriText = rawUri.trim()
                    if (uriText.isEmpty()) continue
                    val sepIdx = uriText.indexOf("://")
                    val proxyScheme = if (sepIdx > 0) uriText.substring(0, sepIdx).lowercase() else ""
                    if (proxyScheme != "https" && proxyScheme != "quic") {
                        errors.add("NaiveProxy proxy ${i + 1}: unsupported transport `${proxyScheme.ifEmpty { "unknown" }}`")
                        continue
                    }
                    try {
                        nodes.add(parseNaiveLink(uriText, proxyScheme))
                    } catch (e: Exception) {
                        errors.add("NaiveProxy proxy ${i + 1}: ${e.message}")
                    }
                }
                return Pair(nodes, errors)
            }
            val skipProtocols = setOf("freedom", "blackhole", "dns", "direct", "block", "selector", "urltest", "url-test", "loopback")
            var handled = false
            val nodesByTag = mutableMapOf<String, ParsedNode>()
            val nativeItemsByTag = linkedMapOf<String, Pair<String, Map<String, Any?>>>()
            val autoGroupDefs = mutableListOf<Pair<String, List<String>>>()
            for (arrayKey in listOf("outbounds", "endpoints")) {
                if (!json.has(arrayKey)) continue
                handled = true
                val outbounds = json.optJSONArray(arrayKey) ?: continue
                for (i in 0 until outbounds.length()) {
                    // Outbound arrays may also hold plain links or nested strings.
                    val raw = outbounds.get(i)
                    if (raw is String) {
                        runCatching { nodes.add(parseSingle(raw)) }
                            .onFailure { errors.add("Outbound ${i + 1}: ${it.message}") }
                        continue
                    }
                    val item = raw as? JSONObject ?: continue
                    val itemTag = item.optString("tag").trim()
                    if (itemTag.isNotEmpty()) {
                        nativeItemsByTag.putIfAbsent(itemTag, arrayKey to jsonToMap(item))
                    }
                    val protocol = item.optString("protocol", item.optString("type"))
                    if (protocol.lowercase() in skipProtocols) {
                        // Every urltest/selector group is imported as one AUTO node
                        // instead of loose servers.
                        if (protocol.lowercase() in AUTO_GROUP_TYPES) {
                            val memberTagList = mutableListOf<String>()
                            item.optJSONArray("outbounds")?.let { memberTags ->
                                for (m in 0 until memberTags.length()) {
                                    val memberTag = memberTags.optString(m).trim()
                                    if (memberTag.isNotEmpty()) memberTagList.add(memberTag)
                                }
                            }
                            if (memberTagList.isNotEmpty()) {
                                autoGroupDefs.add(item.optString("tag").trim() to memberTagList)
                            }
                        }
                        continue
                    }
                    if (protocol.isEmpty() && item.optString("server").isEmpty()) continue
                    try {
                        val parsedItem = parseJsonItem(item)
                        nodes.add(parsedItem)
                        if (itemTag.isNotEmpty()) nodesByTag[itemTag] = parsedItem
                    } catch (e: Exception) {
                        errors.add("Outbound ${i + 1}: ${e.message}")
                    }
                }
            }
            for (arrayKey in listOf("proxies", "servers", "nodes", "configs", "links", "subs", "items")) {
                if (!json.has(arrayKey)) continue
                val nested = json.get(arrayKey)
                if (nested !is JSONArray && nested !is JSONObject && nested !is String) {
                    errors.add("$arrayKey: unsupported JSON container")
                    continue
                }
                handled = true
                try {
                    val (inner, innerErrors) = if (nested is String) parseLinksTextInternal(nested, depth + 1)
                        else parseJsonNodesText(nested.toString(), depth + 1)
                    nodes.addAll(inner)
                    errors.addAll(innerErrors.map { "$arrayKey: $it" })
                } catch (e: Exception) {
                    errors.add("$arrayKey: ${e.message}")
                }
            }
            attachSingboxDependencies(nodesByTag, nativeItemsByTag)
            // Xray represents an explicit automatic pool through routing balancers.
            // A selector is a tag prefix, so resolve it only after every outbound is parsed.
            json.optJSONObject("routing")?.optJSONArray("balancers")?.let { balancers ->
                for (i in 0 until balancers.length()) {
                    val balancer = balancers.optJSONObject(i) ?: continue
                    val selectors = mutableListOf<String>()
                    balancer.optJSONArray("selector")?.let { array ->
                        for (j in 0 until array.length()) {
                            array.optString(j).trim().takeIf(String::isNotEmpty)?.let(selectors::add)
                        }
                    }
                    if (selectors.isEmpty()) continue
                    val matchingTags = nodesByTag.keys.filter { tag ->
                        selectors.any { selector -> tag == selector || tag.startsWith(selector) }
                    }
                    if (matchingTags.isNotEmpty()) {
                        autoGroupDefs.add(balancer.optString("tag").trim() to matchingTags)
                    }
                }
            }
            if (autoGroupDefs.isNotEmpty()) {
                val profileLabel = listOf("remarks", "profile_title", "profileTitle")
                    .firstNotNullOfOrNull { key -> json.optString(key).takeIf { it.isNotBlank() } }
                val autoNodes = mutableListOf<ParsedNode>()
                val consumed = mutableListOf<ParsedNode>()
                for ((groupTag, memberTags) in autoGroupDefs) {
                    val members = memberTags.mapNotNull { nodesByTag[it] }.distinct()
                    if (members.isEmpty()) continue
                    val label = if (autoGroupDefs.size == 1) {
                        profileLabel ?: groupTag.ifEmpty { "AUTO" }
                    } else {
                        groupTag.ifEmpty { "AUTO" }
                    }
                    autoNodes.add(autoNodeFromMembers(label, members))
                    consumed.addAll(members)
                }
                if (autoNodes.isNotEmpty()) {
                    // Pool members live inside the AUTO node, never as separate servers.
                    val remaining = nodes.filterNot { node -> consumed.any { it === node } }
                    return Pair(autoNodes + remaining, errors)
                }
            }
            if (!handled) {
                nodes.add(parseJsonItem(json))
            }
        }

        // Fall back to the other formats instead of reporting an empty import.
        if (nodes.isEmpty()) throw LinkParseError("No servers found in JSON payload")

        return Pair(nodes, errors)
    }

    private fun attachSingboxDependencies(
        nodesByTag: Map<String, ParsedNode>,
        nativeItemsByTag: Map<String, Pair<String, Map<String, Any?>>>
    ) {
        for ((rootTag, node) in nodesByTag) {
            val orderedTags = mutableListOf<String>()
            val added = mutableSetOf<String>()
            val visiting = mutableSetOf<String>()

            fun visit(tag: String) {
                if (tag == rootTag || tag in added || !visiting.add(tag)) return
                val raw = nativeItemsByTag[tag]?.second
                if (raw == null) {
                    visiting.remove(tag)
                    return
                }
                nativeDependencyReferences(raw).forEach(::visit)
                visiting.remove(tag)
                if (added.add(tag)) orderedTags.add(tag)
            }

            nativeItemsByTag[rootTag]?.second
                ?.let(::nativeDependencyReferences)
                ?.forEach(::visit)

            if (orderedTags.isEmpty()) continue
            val dependencies = linkedMapOf<String, Any?>(
                "outbounds" to orderedTags.mapNotNull { tag ->
                    nativeItemsByTag[tag]?.takeIf { it.first == "outbounds" }?.second
                },
                "endpoints" to orderedTags.mapNotNull { tag ->
                    nativeItemsByTag[tag]?.takeIf { it.first == "endpoints" }?.second
                }
            )
            node.outbound = node.outbound.toMutableMap().apply {
                this["_singbox_dependencies"] = dependencies
            }
        }
    }

    private fun nativeDependencyReferences(value: Any?): List<String> {
        val references = linkedSetOf<String>()

        fun collect(current: Any?) {
            when (current) {
                is Map<*, *> -> current.forEach { (rawKey, child) ->
                    when (rawKey?.toString()?.lowercase()) {
                        "detour", "default" ->
                            child?.toString()?.trim()?.takeIf(String::isNotEmpty)?.let(references::add)
                        "outbounds" -> when (child) {
                            is Iterable<*> -> child.forEach { item ->
                                item?.toString()?.trim()?.takeIf(String::isNotEmpty)?.let(references::add)
                            }
                            is Array<*> -> child.forEach { item ->
                                item?.toString()?.trim()?.takeIf(String::isNotEmpty)?.let(references::add)
                            }
                        }
                        else -> collect(child)
                    }
                }
                is Iterable<*> -> current.forEach(::collect)
                is Array<*> -> current.forEach(::collect)
            }
        }

        collect(value)
        return references.toList()
    }

    /**
     * NDJSON: each line is a self-contained JSON object (one outbound per line).
     * Used by some export tools and panel APIs.
     * Returns null if the text does not look like NDJSON (prevents false positives).
     */
    private fun parseCompleteJson(text: String): Any {
        val tokener = JSONTokener(text)
        val value = tokener.nextValue()
        if (tokener.nextClean().code != 0) throw LinkParseError("Trailing data after JSON document")
        return value
    }

    private fun tryParseJsonLines(text: String, depth: Int = 0): Pair<List<ParsedNode>, List<String>>? {
        val lines = text.lines().map(String::trim).filter(String::isNotEmpty)
        if (lines.size !in 2..MAX_IMPORT_LINES) return null
        if (lines.any { !it.startsWith("{") || !it.endsWith("}") }) return null
        if (lines.any { runCatching { parseCompleteJson(it) }.getOrNull() !is JSONObject }) return null
        val nodes = mutableListOf<ParsedNode>()
        val errors = mutableListOf<String>()
        lines.forEachIndexed { index, line ->
            try {
                val (inner, innerErrors) = parseJsonNodesText(line, depth + 1)
                nodes.addAll(inner)
                errors.addAll(innerErrors.map { "NDJSON line ${index + 1}: $it" })
            } catch (e: Exception) {
                errors.add("NDJSON line ${index + 1}: ${e.message}")
            }
        }
        return Pair(nodes, errors)
    }

    // Config arrays mix sing-box/v2ray outbounds with Clash-style proxy maps.
    private fun parseJsonItem(item: JSONObject): ParsedNode = try {
        parseJsonObjectOutbound(item)
    } catch (e: Exception) {
        try {
            parseClashProxyMap(jsonToMap(item))
        } catch (_: Exception) {
            throw e
        }
    }

    private fun parseJsonOutbound(text: String): ParsedNode {
        val json = JSONObject(text)
        return parseJsonObjectOutbound(json)
    }

    /**
     * A Clash/Mihomo proxy is a plain JSON object with a "type" too, so the native
     * sing-box pass-through would swallow one and emit dashed keys the core rejects
     * (and lose the port, which Clash calls "port" and sing-box "server_port").
     * The dashed spellings are the reliable discriminator; a proxy pasted on its
     * own may carry none of them, and is then recognised by the Clash spelling of
     * the port (parity with desktop _is_clash_proxy_payload).
     */
    private fun isClashProxyJson(json: JSONObject): Boolean {
        if (json.optString("type").isBlank()) return false
        if (json.has("protocol") || json.has("settings") || json.has("streamSettings")) return false
        if (json.keys().asSequence().any { it.lowercase() in CLASH_PROXY_MARKER_KEYS }) return true
        return json.has("server") && json.has("port") && !json.has("server_port")
    }

    fun parseJsonObjectOutbound(json: JSONObject): ParsedNode {
        if (isClashProxyJson(json)) return parseClashProxyMap(jsonToMap(json))

        val typeValue = json.optString("type")
        val protocolValue = json.optString("protocol")
        if (typeValue.isBlank() && protocolValue.isBlank()) {
            if (isSip008ShadowsocksServer(json)) {
                val server = json.optString("server").trim()
                val rawPort = json.opt("server_port")
                val port = when (rawPort) {
                    is Number -> rawPort.toInt()
                    is String -> rawPort.trim().toIntOrNull()
                    else -> null
                }
                val method = json.optString("method").trim()
                val password = json.optString("password")
                if (
                    server.isEmpty()
                    || port == null
                    || port !in 1..65535
                    || method.isEmpty()
                    || (password.isEmpty() && !method.equals("none", ignoreCase = true))
                ) {
                    throw LinkParseError("SIP008 Shadowsocks server has invalid required fields")
                }
                val plugin = normalizeShadowsocksPluginName(json.optString("plugin"))
                val native = mutableMapOf<String, Any?>(
                    "type" to "shadowsocks",
                    "server" to server,
                    "server_port" to port,
                    "method" to method,
                    "password" to password
                )
                if (plugin.isNotEmpty()) {
                    native["plugin"] = plugin
                    val rawOptions = json.optString("plugin_opts")
                    val options = if (plugin == "obfs-local") normalizeObfsPluginOptions(rawOptions) else rawOptions
                    if (options.isNotEmpty()) native["plugin_opts"] = options
                }
                val name = json.optString("remarks").ifEmpty {
                    json.optString("name", "ss-$server:$port")
                }
                return ParsedNode(
                    name = name,
                    scheme = "ss",
                    server = server,
                    port = port,
                    link = json.toString(),
                    outbound = mapOf("protocol" to "shadowsocks", "singbox" to native)
                )
            }
            if (json.has("add") && json.has("id") && json.has("port")) {
                return parseVmess("vmess://" + Base64.getEncoder().encodeToString(json.toString().toByteArray(Charsets.UTF_8)))
            }
            throw LinkParseError("JSON object has no supported protocol or node container")
        }

        if (protocolValue.isEmpty() && typeValue.isNotEmpty()) {
            // Native sing-box outbound/endpoint object: wrap it as a singbox
            // pass-through, matching the desktop _native_singbox_outbound path.
            val native = jsonToMap(json).toMutableMap()
            var protocol = typeValue.lowercase()
            when (protocol) {
                "hy" -> { protocol = "hysteria"; native["type"] = "hysteria" }
                "hy2" -> { protocol = "hysteria2"; native["type"] = "hysteria2" }
                "openvpn", "openvpn-client" -> {
                    native["system"] = false
                    native["name"] = native["name"]?.toString()?.takeIf { it.isNotBlank() } ?: "openvpn0"
                    protocol = "openvpn"
                }
            }
            if (protocol == "wireguard" && native["amnezia"] is Map<*, *>) protocol = "awg"

            var server = native["server"]?.toString() ?: ""
            var port = (native["server_port"] as? Number)?.toInt()
                ?: native["server_port"]?.toString()?.toIntOrNull() ?: 0
            if (protocol == "masque" && server.isEmpty()) {
                server = ((native["profile"] as? Map<*, *>)?.get("id"))?.toString() ?: ""
            }
            if (protocol == "openvpn") {
                val firstServer = (native["servers"] as? List<*>)?.firstOrNull() as? Map<*, *>
                if (server.isEmpty()) server = firstServer?.get("server")?.toString() ?: ""
                if (port <= 0) {
                    port = (firstServer?.get("server_port") as? Number)?.toInt()
                        ?: firstServer?.get("server_port")?.toString()?.toIntOrNull() ?: 0
                }
            }
            if (protocol in setOf("wireguard", "awg", "warp") && server.isEmpty()) {
                val peer = (native["peers"] as? List<*>)?.firstOrNull() as? Map<*, *>
                server = peer?.get("address")?.toString() ?: peer?.get("server")?.toString() ?: ""
                if (port <= 0) {
                    port = (peer?.get("port") as? Number)?.toInt()
                        ?: (peer?.get("server_port") as? Number)?.toInt() ?: 0
                }
            }

            val name = json.optString("tag").ifEmpty { json.optString("name", "$protocol-node") }
            val outbound = mapOf<String, Any?>("protocol" to protocol, "singbox" to native)
            return ParsedNode(name = name, scheme = protocol, server = server, port = port, link = json.toString(), outbound = outbound)
        }

        val protocol = protocolValue.ifEmpty { json.optString("type", "unknown") }
        val name = json.optString("tag").ifEmpty { json.optString("name", "$protocol-node") }
        var server = json.optString("server").ifEmpty { json.optString("address") }
        var port = json.optInt("port", json.optInt("server_port", 443))

        val settings = json.optJSONObject("settings")
        when (protocol.lowercase()) {
            "vless", "vmess" -> {
                val vnext = settings?.optJSONArray("vnext")
                if (vnext != null && vnext.length() > 0) {
                    val target = vnext.optJSONObject(0)
                    if (target != null) {
                        server = target.optString("address", target.optString("server"))
                        port = target.optInt("port", target.optInt("server_port", 443))
                    }
                }
            }
            "trojan", "shadowsocks", "ss", "socks", "http" -> {
                val servers = settings?.optJSONArray("servers")
                if (servers != null && servers.length() > 0) {
                    val target = servers.optJSONObject(0)
                    if (target != null) {
                        server = target.optString("address", target.optString("server"))
                        port = target.optInt("port", target.optInt("server_port", 443))
                    }
                }
            }
            "hysteria", "hysteria2", "tuic", "mieru", "naive" -> {
                if (settings != null) {
                    server = settings.optString("address", settings.optString("server", server))
                    port = settings.optInt("port", settings.optInt("server_port", port))
                }
            }
        }

        val map = jsonToMap(json)
        return ParsedNode(name = name, scheme = protocol, server = server, port = port, link = json.toString(), outbound = map)
    }

    private fun isSip008ShadowsocksServer(json: JSONObject): Boolean =
        listOf("server", "server_port", "method", "password").all(json::has)

    fun jsonToMap(json: JSONObject): Map<String, Any?> {
        val map = mutableMapOf<String, Any?>()
        val keys = json.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val value = json.get(key)
            map[key] = when (value) {
                is JSONObject -> jsonToMap(value)
                is JSONArray -> jsonToList(value)
                JSONObject.NULL -> null
                else -> value
            }
        }
        return map
    }

    fun jsonToList(array: JSONArray): List<Any?> {
        val list = mutableListOf<Any?>()
        for (i in 0 until array.length()) {
            val value = array.get(i)
            list.add(
                when (value) {
                    is JSONObject -> jsonToMap(value)
                    is JSONArray -> jsonToList(value)
                    JSONObject.NULL -> null
                    else -> value
                }
            )
        }
        return list
    }

    fun toJsonString(value: Any?): String {
        return when (val safe = toJsonSafe(value)) {
            is JSONObject -> safe.toString()
            is JSONArray -> safe.toString()
            null -> ""
            else -> safe.toString()
        }
    }

    fun toJsonSafe(value: Any?): Any? {
        if (value == null) return null
        return when (value) {
            is Number -> {
                val d = value.toDouble()
                if (d.isInfinite() || d.isNaN()) null else value
            }
            is Map<*, *> -> {
                val jsonObj = JSONObject()
                for ((k, v) in value) {
                    if (k != null) {
                        val safeV = toJsonSafe(v)
                        if (safeV != null && safeV != JSONObject.NULL) {
                            jsonObj.put(k.toString(), safeV)
                        }
                    }
                }
                jsonObj
            }
            is List<*> -> {
                val jsonArr = JSONArray()
                for (item in value) {
                    val safeItem = toJsonSafe(item)
                    if (safeItem != null && safeItem != JSONObject.NULL) {
                        jsonArr.put(safeItem)
                    }
                }
                jsonArr
            }
            is Array<*> -> {
                val jsonArr = JSONArray()
                for (item in value) {
                    val safeItem = toJsonSafe(item)
                    if (safeItem != null && safeItem != JSONObject.NULL) {
                        jsonArr.put(safeItem)
                    }
                }
                jsonArr
            }
            is String -> {
                if (value.equals("Infinity", ignoreCase = true) || value.equals("-Infinity", ignoreCase = true) || value.equals("NaN", ignoreCase = true)) {
                    null
                } else value
            }
            is Boolean -> value
            else -> value.toString()
        }
    }

    private fun buildStreamSettings(params: Map<String, String>, defaultNetwork: String, defaultSecurity: String): Map<String, Any?> {
        val rawNetwork = (params["type"] ?: params["net"] ?: defaultNetwork).lowercase()
        val network = when (rawNetwork) {
            "", "raw", "none" -> "tcp"
            "mkcp" -> "kcp"
            "gun" -> "grpc"
            "splithttp" -> "xhttp"
            else -> rawNetwork
        }
        var security = (params["security"] ?: defaultSecurity).lowercase()
        if (security == "none" && params["tls"] == "tls") security = "tls"

        val stream = mutableMapOf<String, Any?>(
            "network" to network,
            "security" to security
        )

        val host = params["host"] ?: ""
        val path = params["path"] ?: ""

        when (network) {
            "ws" -> {
                val ws = mutableMapOf<String, Any?>()
                if (path.isNotEmpty()) ws["path"] = path
                if (host.isNotEmpty()) ws["headers"] = mapOf("Host" to host)
                stream["wsSettings"] = ws
            }
            "grpc" -> {
                val grpc = mutableMapOf<String, Any?>()
                params["servicename"]?.let { if (it.isNotEmpty()) grpc["serviceName"] = it }
                params["authority"]?.let { if (it.isNotEmpty()) grpc["authority"] = it }
                stream["grpcSettings"] = grpc
            }
            "xhttp" -> {
                val xhttp = mutableMapOf<String, Any?>()
                if (path.isNotEmpty()) xhttp["path"] = path
                if (host.isNotEmpty()) xhttp["host"] = host
                params["mode"]?.let { if (it.isNotEmpty()) xhttp["mode"] = it }
                stream["xhttpSettings"] = xhttp
            }
            "http", "h2" -> {
                val http = mutableMapOf<String, Any?>()
                if (host.isNotEmpty()) http["host"] = host.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                if (path.isNotEmpty()) http["path"] = path
                stream["httpSettings"] = http
            }
            "httpupgrade" -> {
                val httpUpgrade = mutableMapOf<String, Any?>()
                if (path.isNotEmpty()) httpUpgrade["path"] = path
                if (host.isNotEmpty()) httpUpgrade["host"] = host
                stream["httpupgradeSettings"] = httpUpgrade
            }
            "kcp" -> {
                val kcp = mutableMapOf<String, Any?>(
                    "header" to mapOf("type" to ((params["headertype"] ?: params["header_type"])?.takeIf { it.isNotEmpty() } ?: "none"))
                )
                for ((key, snakeKey) in listOf(
                    "mtu" to "mtu", "tti" to "tti",
                    "uplinkCapacity" to "uplink_capacity", "downlinkCapacity" to "downlink_capacity",
                    "readBufferSize" to "read_buffer_size", "writeBufferSize" to "write_buffer_size"
                )) {
                    (params[key.lowercase()] ?: params[snakeKey])?.takeIf { it.isNotEmpty() }?.let {
                        kcp[key] = it.toIntOrNull() ?: it
                    }
                }
                params["seed"]?.takeIf { it.isNotEmpty() }?.let { kcp["seed"] = it }
                params["congestion"]?.takeIf { it.isNotEmpty() }?.let { kcp["congestion"] = toBool(it) }
                stream["kcpSettings"] = kcp
            }
            // The bundled sing-box-extended is built with with_quic. Its V2Ray
            // QUIC transport has an intentionally empty option object and requires
            // TLS; keeping the explicit network lets the runtime builder emit
            // `transport: {type: "quic"}` rather than rejecting a valid profile.
            "quic" -> {
                if (security != "tls") {
                    throw LinkParseError("V2Ray quic requires TLS in sing-box-extended")
                }
                stream["quicSettings"] = emptyMap<String, Any?>()
            }
            "tcp" -> Unit
            else -> throw LinkParseError("unsupported transport `$rawNetwork`")
        }

        if (security == "tls") {
            val tls = mutableMapOf<String, Any?>()
            params["sni"]?.let { if (it.isNotEmpty()) tls["serverName"] = it }
            params["alpn"]?.let { if (it.isNotEmpty()) tls["alpn"] = it.split(",").map { s -> s.trim() } }
            params["fp"]?.let { if (it.isNotEmpty()) tls["fingerprint"] = it }
            certificatePublicKeyPins(params).takeIf { it.isNotEmpty() }?.let {
                tls["certificatePublicKeySha256"] = it
            }
            if (tlsInsecure(params)) {
                tls["allowInsecure"] = true
            }
            stream["tlsSettings"] = tls
        } else if (security == "reality") {
            val reality = mutableMapOf<String, Any?>()
            params["sni"]?.let { if (it.isNotEmpty()) reality["serverName"] = it }
            params["fp"]?.let { if (it.isNotEmpty()) reality["fingerprint"] = it }
            params["pbk"]?.let { if (it.isNotEmpty()) reality["publicKey"] = it }
            params["sid"]?.let { if (it.isNotEmpty()) reality["shortId"] = it }
            params["spx"]?.let { if (it.isNotEmpty()) reality["spiderX"] = it }
            reality["show"] = false
            stream["realitySettings"] = reality
        }

        return stream
    }

    /**
     * Common share-link spellings for sing-box's SPKI pin. Values are kept as
     * strings here and normalized/validated by the config builder immediately
     * before they are emitted to the core.
     */
    private fun certificatePublicKeyPins(params: Map<String, String>): List<String> {
        val raw = params["pinsha256"]
            ?: params["certificate_public_key_sha256"]
            ?: params["certificate-public-key-sha256"]
            ?: params["certsha256"]
            ?: return emptyList()
        return raw.split(',').map(String::trim).filter(String::isNotEmpty)
    }

    private fun applyHappServerMetadata(node: ParsedNode, raw: String) {
        val text = raw.trim()
        val fragment = try { URI(text).rawFragment } catch (e: Exception) { null } ?: return
        if (fragment.contains("?")) {
            val queryText = fragment.substringAfter("?")
            val params = parseQueryParams(queryText)
            val desc = params["serverdescription"]
            if (!desc.isNullOrEmpty()) {
                val decoded = try { decodeB64(desc) } catch (e: Exception) { desc }
                node.description = decoded.take(30)
            }
            val title = fragment.substringBefore("?").trim()
            if (title.isNotEmpty()) {
                node.name = cleanName(title, node.name)
            }
        }
    }
}
